// Backups UI (BUNDLE007)
// Create/list/download/restore project backups

const BK$ = (id) => document.getElementById(id);

function bkStatus(t){ const el = BK$('bkStatus'); if(el) el.textContent = t; }
function bkOut(obj){ const el = BK$('bkOut'); if(!el) return; el.textContent = (typeof obj === 'string') ? obj : JSON.stringify(obj, null, 2); }

async function bkFetchJson(url, opts){
  const r = await fetch(url, Object.assign({ cache:'no-store' }, opts||{}));
  const ct = (r.headers.get('content-type')||'');
  let body = null;
  if(ct.includes('application/json')) body = await r.json();
  else body = await r.text();
  if(!r.ok){
    const msg = (body && body.error) ? body.error : (typeof body === 'string' ? body : `${url} -> ${r.status}`);
    throw new Error(msg);
  }
  return body;
}

async function bkLoadProjects(){
  const sel = BK$('bkProject');
  if(!sel) return;
  sel.innerHTML = '';
  try{
    const j = await bkFetchJson('/api/projects/list');
    const arr = (j && j.projects) ? j.projects : (Array.isArray(j) ? j : []);
    const cur = (j && j.current) ? j.current : '';

    const seen = new Set();
    for(const p of arr){
      const id = (p && (p.id || p.project || p.name)) ? String(p.id || p.project || p.name) : String(p);
      if(!id || seen.has(id)) continue;
      seen.add(id);
      const opt = document.createElement('option');
      opt.value = id;
      opt.textContent = id;
      sel.appendChild(opt);
    }
    if(!seen.size){
      const opt = document.createElement('option');
      opt.value='default'; opt.textContent='default';
      sel.appendChild(opt);
    }
    if(cur && seen.has(cur)) sel.value = cur;
  }catch{
    const opt = document.createElement('option');
    opt.value='default'; opt.textContent='default';
    sel.appendChild(opt);
  }
}

function bkRender(backups){
  const host = BK$('bkList');
  if(!host) return;
  host.innerHTML = '';

  const wrap = document.createElement('div');
  wrap.className = 'tableWrap';

  const table = document.createElement('table');
  table.className = 'tbl';
  table.style.width = '100%';

  const thead = document.createElement('thead');
  thead.innerHTML = '<tr><th>Name</th><th style="width:120px">Size</th><th style="width:180px">Modified</th><th style="width:240px">Actions</th></tr>';
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  const list = Array.isArray(backups) ? backups : [];
  if(!list.length){
    const tr = document.createElement('tr');
    tr.innerHTML = '<td colspan="4" class="small" style="opacity:.8">No backups found.</td>';
    tbody.appendChild(tr);
  }else{
    for(const b of list){
      const name = String(b.name || '');
      const size = (b.size ?? '');
      const mtime = b.mtime ? new Date((Number(b.mtime)||0)*1000).toLocaleString() : '';

      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${name}</td><td>${size}</td><td>${mtime}</td>`;

      const tdA = document.createElement('td');
      tdA.style.display='flex';
      tdA.style.gap='8px';

      const project = BK$('bkProject')?.value || 'default';

      const dl = document.createElement('a');
      dl.className = 'btn ghost';
      dl.textContent = 'Download';
      dl.href = `/api/backups/download?project=${encodeURIComponent(project)}&name=${encodeURIComponent(name)}`;
      dl.style.textDecoration='none';
      dl.style.padding='6px 10px';

      const inspect = document.createElement('button');
      inspect.className = 'ghost';
      inspect.textContent = 'Inspect';
      inspect.style.padding='6px 10px';
      inspect.addEventListener('click', async ()=>{
        try{
          bkStatus('Inspecting…');
          const j = await bkFetchJson(`/api/backups/inspect?project=${encodeURIComponent(project)}&name=${encodeURIComponent(name)}&max_items=800`);
          bkOut(j);
          const n = (j && j.items) ? j.items.length : 0;
          bkStatus(`OK (${n} items)`);
        }catch(e){
          bkStatus('ERROR');
          bkOut({ ok:false, error:String(e) });
        }
      });

      const preview = document.createElement('button');
      preview.className = 'ghost';
      preview.textContent = 'Preview';
      preview.style.padding='6px 10px';
      preview.addEventListener('click', async ()=>{
        try{
          bkStatus('Previewing…');
          const j = await bkFetchJson(`/api/backups/preview?project=${encodeURIComponent(project)}&name=${encodeURIComponent(name)}&sample=20`);
          bkOut(j);
          bkStatus(`OK (overwrites: ${j.overwrites ?? 0}, new: ${j.new_files ?? 0})`);
        }catch(e){
          bkStatus('ERROR');
          bkOut({ ok:false, error:String(e) });
        }
      });

      const restore = document.createElement('button');
      restore.className = 'ghost';
      restore.textContent = 'Restore';
      restore.style.padding='6px 10px';
      restore.addEventListener('click', async ()=>{
        const ok = window.confirm(`Restore (extract) backup '${name}' into project '${project}'?\n\nTip: Click Inspect first to review contents.\n\nThis will write files into the project root (SAFE MODE blocks this).`);
        if(!ok) return;
        try{
          bkStatus('Restoring…');
          const j = await bkFetchJson('/api/backups/extract', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ project, name })
          });
          bkOut(j);
          await bkRefresh();
          bkStatus('OK');
        }catch(e){
          bkStatus('ERROR');
          bkOut({ ok:false, error: String(e) });
        }
      });

      tdA.appendChild(dl);
      tdA.appendChild(inspect);
      tdA.appendChild(preview);
      tdA.appendChild(restore);
      tr.appendChild(tdA);
      tbody.appendChild(tr);
    }
  }

  table.appendChild(tbody);
  wrap.appendChild(table);
  host.appendChild(wrap);
}

async function bkRefresh(){
  const project = BK$('bkProject')?.value || 'default';
  const j = await bkFetchJson(`/api/backups/list?project=${encodeURIComponent(project)}`);
  bkRender(j.backups || []);
  return j;
}

async function bkCreate(){
  const project = BK$('bkProject')?.value || 'default';
  const name = (BK$('bkName')?.value || '').trim();
  const rawAreas = (BK$('bkAreas')?.value || '').trim();
  const areas = rawAreas ? rawAreas.split(',').map(s=>s.trim()).filter(Boolean) : [];
  bkStatus('Creating…');
  const j = await bkFetchJson(`/api/backups/create?project=${encodeURIComponent(project)}`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ project, project_id: project, name: name || null, areas })
  });
  bkOut(j);
  await bkRefresh();
  bkStatus('OK');
}

async function bkExportPack(){
  const project = BK$('bkProject')?.value || 'default';
  const name = (BK$('bkExportName')?.value || '').trim();
  const rawAreas = (BK$('bkExportAreas')?.value || '').trim();
  const areas = rawAreas ? rawAreas.split(',').map(s=>s.trim()).filter(Boolean) : [];
  bkStatus('Exporting…');
  const j = await bkFetchJson(`/api/projects/export_pack?project=${encodeURIComponent(project)}`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ project, project_id: project, name: name || null, areas })
  });
  bkOut(j);

  // Wire download link to the generated outbox file
  const link = BK$('bkExportLink');
  if(link && j && j.path){
    link.href = `/api/files/download?project=${encodeURIComponent(project)}&path=${encodeURIComponent(j.path)}`;
    link.style.display = 'inline-flex';
  }
  bkStatus('OK');
}

document.addEventListener('DOMContentLoaded', async ()=>{
  // page may not exist in some builds
  if(!BK$('page-backups')) return;

  await bkLoadProjects();

  BK$('bkRefresh')?.addEventListener('click', async ()=>{
    try{ bkStatus('Loading…'); await bkRefresh(); bkStatus('OK'); }
    catch(e){ bkStatus('ERROR'); bkOut({ ok:false, error:String(e) }); }
  });

  BK$('bkCreate')?.addEventListener('click', async ()=>{
    try{ await bkCreate(); }
    catch(e){ bkStatus('ERROR'); bkOut({ ok:false, error:String(e) }); }
  });

  BK$('bkProject')?.addEventListener('change', async ()=>{
    try{ bkStatus('Loading…'); await bkRefresh(); bkStatus('OK'); }
    catch(e){ bkStatus('ERROR'); }
  });

  BK$('bkExport')?.addEventListener('click', async ()=>{
    try{ await bkExportPack(); }
    catch(e){ bkStatus('ERROR'); bkOut({ ok:false, error:String(e) }); }
  });

  // initial load
  try{ bkStatus('Loading…'); await bkRefresh(); bkStatus('OK'); }
  catch(e){ bkStatus('ERROR'); }
});
