(function(){
  const $ = (id)=>document.getElementById(id);

  async function fetchJson(url, opts){
    const r = await fetch(url, Object.assign({cache:'no-store'}, opts||{}));
    const ct = r.headers.get('content-type')||'';
    let body;
    if(ct.includes('application/json')) body = await r.json();
    else body = await r.text();
    if(!r.ok) throw new Error(`${url} -> ${r.status} ${String(body).slice(0,200)}`);
    return body;
  }

  function setOut(text){
    const el = $('tsOut');
    if(el) el.textContent = text || '';
  }

  function pretty(obj){
    try{ return JSON.stringify(obj, null, 2); }catch{ return String(obj); }
  }

  async function refreshQuick(){
    try{
      const j = await fetchJson('/api/tests/quick');
      if($('tsVoice')) $('tsVoice').textContent = j.voice || '–';
      if($('tsTools')) $('tsTools').textContent = j.tools || '–';
      if($('tsAgent')) $('tsAgent').textContent = j.agent || '–';
      if($('tsUi')) $('tsUi').textContent = j.ui || '–';
      setOut(pretty(j));
    }catch(e){
      setOut('Refresh failed: ' + String(e));
    }
  }

  async function runSuite(save){
    try{
      setOut(save ? 'Running + saving…' : 'Running…');
      const url = save ? '/api/tests/quick?save=1' : '/api/tests/quick';
      const j = await fetchJson(url, { method:'POST', headers:{'Content-Type':'application/json'}, body:'{}' });
      setOut(pretty(j));
      await refreshQuick();
    }catch(e){
      setOut('Run failed: ' + String(e));
    }
  }

  function copyOut(){
    const el = $('tsOut');
    if(!el) return;
    const t = el.textContent || '';
    if(!t) return;
    navigator.clipboard && navigator.clipboard.writeText(t).catch(()=>{});
  }

  function init(){
    if(!$('page-troubleshoot')) return;
    const r = $('tsRefresh'); if(r) r.addEventListener('click', refreshQuick);
    const run = $('tsRunSuite'); if(run) run.addEventListener('click', ()=>runSuite(false));
    const save = $('tsSaveSuite'); if(save) save.addEventListener('click', ()=>runSuite(true));
    const c = $('tsCopy'); if(c) c.addEventListener('click', copyOut);
    refreshQuick();
  }

  window.addEventListener('DOMContentLoaded', init);
})();
