// BUNDLE124: disabled. We are preserving the existing 'System Tools' card inside System page.
// (Do not inject an additional top bar.)
(function(){
  try{
    const m = document.getElementById("systemNavMount");
    if(m) m.style.display="none";
  }catch(e){}
})();
