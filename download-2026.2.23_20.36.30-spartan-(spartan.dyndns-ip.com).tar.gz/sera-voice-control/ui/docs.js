async function listDocs(){
  const r = await fetch('/docs/index.json', {cache:'no-store'});
  if(!r.ok) throw new Error('docs index http ' + r.status);
  return await r.json();
}

async function loadDoc(path){
  const r = await fetch(path, {cache:'no-store'});
  if(!r.ok) throw new Error('doc http ' + r.status);
  return await r.text();
}

function setFooter(text){
  const el = document.getElementById('seraFooter');
  if(el) el.textContent = text;
}

async function updateStatus(){
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    const j = await r.json();
    const run = (j && j.run) ? j.run : 'UNKNOWN';
    const vg = j.voice ? 'VG:ok' : 'VG:down';
    const tg = j.tool ? 'TG:ok' : 'TG:down';
    const ar = j.agent ? 'AR:ok' : 'AR:down';
    setFooter(`${run} | ${vg} | ${tg} | ${ar}`);
  }catch{
    setFooter('UNKNOWN | status unavailable');
  }
}

// This script may be loaded on multiple pages. Only run if required elements exist.
document.addEventListener('DOMContentLoaded', ()=>{
  const sel = document.getElementById('docSelect');
  const out = document.getElementById('docOut');
  const raw = document.getElementById('rawLink');
  const reload = document.getElementById('reloadDocs');

  if(!sel || !out){
    // Not on docs page
    return;
  }

  async function refresh(){
    const idx = await listDocs();
    sel.innerHTML = '';
    for(const item of (idx.docs||[])){
      const opt = document.createElement('option');
      opt.value = item.path;
      opt.textContent = item.title || item.path;
      sel.appendChild(opt);
    }
    if(sel.value) await show();
  }

  async function show(){
    const p = sel.value;
    if(!p) return;
    raw.href = p;
    out.textContent = 'Loading...';
    out.textContent = await loadDoc(p);
  }

  reload?.addEventListener('click', ()=>refresh().catch(e=>out.textContent='Error: '+e));
  sel?.addEventListener('change', ()=>show().catch(e=>out.textContent='Error: '+e));

  refresh().catch(e=>{ out.textContent = 'Error: ' + e; });
  updateStatus();
  setInterval(updateStatus, 8000);
});
