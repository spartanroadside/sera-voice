// Dashboard controller for SERA AI UI (Sera AI Ver 1.001)
// Fix: nav buttons now actually switch visible pages.

const $ = (id) => document.getElementById(id);

// --- Theme (light/dark) ---
function getTheme(){
  try{ return localStorage.getItem('sera_theme') || 'dark'; }catch{ return 'dark'; }
}
function applyTheme(theme){
  const t = (theme === 'light') ? 'light' : 'dark';
  document.body.classList.toggle('theme-light', t === 'light');
  try{ localStorage.setItem('sera_theme', t); }catch{}
  const lbl = $('themeLabel');
  if(lbl) lbl.textContent = (t === 'light') ? 'Light' : 'Dark';
}
window.SERA_THEME = {
  get: getTheme,
  set: applyTheme,
  toggle: ()=>{
    const next = (getTheme()==='light') ? 'dark' : 'light';
    applyTheme(next);
    try{ if(window.SERA_SETTINGS && window.SERA_SETTINGS.post) window.SERA_SETTINGS.post({theme: next}); }catch(e){}
  }
};

async function fetchJson(url) {
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error(`${url} -> ${r.status}`);
  return await r.json();
}

// --- Settings sync (server-backed via /api/settings) ---
async function _getServerSettings(){
  try{
    const r = await fetch('/api/settings', {cache:'no-store'});
    if(!r.ok) return null;
    const j = await r.json();
    if(j && j.ok && j.settings) return j.settings;
  }catch(e){}
  return null;
}
let _settingsPostTimer = null;
function _postServerSettings(partial){
  try{
    clearTimeout(_settingsPostTimer);
    _settingsPostTimer = setTimeout(async ()=>{
      try{
        await fetch('/api/settings', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify(partial || {})
        });
      }catch(e){}
    }, 250);
  }catch(e){}
}
window.SERA_SETTINGS = {
  get: _getServerSettings,
  post: _postServerSettings
};

// On boot, try to pull theme/net_scope from server and apply locally.
document.addEventListener('DOMContentLoaded', async ()=>{
  const s = await _getServerSettings();
  if(s){
    try{
      if(s.theme) window.SERA_THEME.set(s.theme);
      if(s.net_scope) localStorage.setItem('sera_net_scope', String(s.net_scope));
    }catch(e){}
  }
});


function getBakedMeta(){
  const m = (window.__SERA_META__ || {});
  return {
    build_id: (m.build_id || "").toString(),
    built_at: (m.built_at || "").toString(),
  };
}

async function loadMetaForFooter(){
  // Prefer backend /api/meta when available; fallback to baked version.js
  const baked = getBakedMeta();
  let build_id = baked.build_id || "";
  let status = "STARTING";
  try{
    const j = await fetchJson("/api/meta");
    if(j && j.ok){
      build_id = (j.build_id || build_id || "").toString();
      status = "OK";
    }else{
      status = "OFFLINE";
    }
  }catch{
    status = "OFFLINE";
  }
  return { build_id, status };
}


function setFooter({ build_id = "", status = "OK" } = {}) {
  const el = $("footerStatus");
  if (!el) return;
  const st = status || "OK";
  // Footer details are handled by footer_meta.js; keep this status-only.
  el.textContent = ["SERA AI", st].join(" • ");
}


async function refreshStatus() {
  try {
    const m = await loadMetaForFooter();
    setFooter({ build_id: m.build_id, status: m.status });
  } catch (e) {
    console.warn("refreshStatus failed", e);
    setFooter({ build_id: "", status: "OFFLINE" });
  }
}

async function refreshPills() {
  // Optional endpoint provided by sysdiag container. UI should not break if absent.
  try {
    const j = await fetchJson("/sysdiag/system.json");
    if (j && typeof j === "object") {
      if ($("cpuPct")) $("cpuPct").textContent = (j.cpu?.pct ?? j.cpu_pct ?? "–");
      if ($("memPct")) $("memPct").textContent = (j.mem?.pct ?? j.mem_pct ?? "–");
      if ($("load1")) $("load1").textContent = (j.load?.one ?? j.load1 ?? "–");
    }
  } catch { /* ignore */ }
}

function showPage(pageId) {
  const raw = String(pageId || "");
  const parts = raw.split(":", 2);
  const basePage = parts[0] || "voice";
  const payload = (parts.length > 1) ? parts[1] : "";

  const pages = Array.from(document.querySelectorAll(".page"));
  let found = false;
  for (const p of pages) {
    const isTarget = p.id === `page-${basePage}`;
    p.style.display = isTarget ? "block" : "none";
    if (isTarget) found = true;
  }
  if (!found) {
    for (const p of pages) p.style.display = (p.id === "page-voice") ? "block" : "none";
  }

  document.querySelectorAll("[data-page]").forEach((btn) => {
    const isActive = btn.getAttribute("data-page") === basePage;
    btn.classList.toggle("active", isActive);
    btn.classList.toggle("primary", isActive);
  });

  try { window.location.hash = `#${basePage}${payload ? ":" + payload : ""}`; } catch {}

  // Notify other modules
  try{ window.dispatchEvent(new CustomEvent("sera:navigate", { detail:{ page: basePage, payload } })); }catch{}

  // Phase2 hooks
  try {
    if (basePage === "projects" && window.SERA_PROJECT_BUILDER?.renderProjects) {
      window.SERA_PROJECT_BUILDER.renderProjects();
    }
    if (basePage === "project-workspace" && window.SERA_PROJECT_BUILDER?.renderWorkspace) {
      window.SERA_PROJECT_BUILDER.renderWorkspace(payload || "");
    }
  } catch (e) {
    console.warn("Phase2 render hook failed", e);
  }
}
// ===== SERA_PHASE2_NATIVE =====

function wireNav() {
  document.querySelectorAll("[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => showPage(btn.getAttribute("data-page")));
  });

  // In-page links that navigate to other pages (e.g., Settings shortcuts)
  document.querySelectorAll("[data-nav]").forEach((a) => {
    a.addEventListener("click", (e) => {
      e.preventDefault();
      const target = a.getAttribute("data-nav") || "";
      if (target) showPage(target);
    });
  });

  // Back/forward hash nav
  window.addEventListener("hashchange", () => {
    const raw = String(window.location.hash || "").replace(/^#/, "");
    if (raw) showPage(raw);
  });
}


function wireUserMenu(){
  const btn = $("userBtn");
  const dd  = $("userDropdown");
  if(btn && dd){
    btn.addEventListener("click", () => {
      dd.style.display = (dd.style.display === "none" || !dd.style.display) ? "block" : "none";
    });
    document.addEventListener("click", (e) => {
      if(!btn.contains(e.target) && !dd.contains(e.target)) dd.style.display = "none";
    });
  }
  document.querySelectorAll("#userDropdown [data-action]").forEach((b) => {
    b.addEventListener("click", () => {
      const action = b.getAttribute("data-action");
      if(action === "settings") showPage("settings");
      dd && (dd.style.display = "none");
    });
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  // Apply theme early
  applyTheme(getTheme());

  // Settings page theme toggle
  const tbtn = $("btnThemeToggle");
  if(tbtn){
    tbtn.addEventListener("click", ()=>window.SERA_THEME.toggle());
    const lbl = $("themeLabel");
    if(lbl) lbl.textContent = (getTheme()==="light") ? "Light" : "Dark";
  }
  wireNav();
  wireUserMenu();
  await refreshStatus();

  const initial = String(window.location.hash || "").replace(/^#/, "") || "voice";
  showPage(initial);

  refreshPills();
  setInterval(refreshStatus, 15000);
  setInterval(refreshPills, 5000);
});
// ===== SERA_PHASE2_ROUTING (added by Phase2 pack) =====
// Adds hash routes:
//   #/projects
//   #/project/<projectId>
(function(){
  function parseHash(){
    const raw = (window.location.hash || "#/").replace(/^#/, "");
    const h = raw.startsWith("/") ? raw : ("/" + raw);
    return h.split("/").filter(Boolean);
  }

  const _origShowPage = (typeof showPage === "function") ? showPage : null;

  function phase2Route(){
    const parts = parseHash();
    const page = parts[0] || "";
    if (page === "projects"){
      if (window.SERA_P2 && window.SERA_P2.renderProjects) {
        window.SERA_P2.renderProjects();
        return true;
      }
    }
    if (page === "project"){
      const projectId = decodeURIComponent(parts[1] || "");
      if (projectId && window.SERA_P2 && window.SERA_P2.renderWorkspace) {
        window.SERA_P2.renderWorkspace(projectId);
        return true;
      }
    }
    return false;
  }

  function handle(){
    if (phase2Route()) return;
    if (_origShowPage){
      try { _origShowPage(parseHash()[0] || ""); } catch(e){}
    }
  }

  window.addEventListener("hashchange", handle);
  setTimeout(handle, 0);
})();
// ===== /SERA_PHASE2_ROUTING =====


// ===== Dashboard -> Programmer navigation (click a project) =====
(function(){
  const LS_ACTIVE = "SERA_ACTIVE_PROJECT";

  function getActiveProject(){
    try{
      return (localStorage.getItem(LS_ACTIVE)||"").trim() || "default";
    }catch{ return "default"; }
  }
  function setActiveProject(p){
    try{ localStorage.setItem(LS_ACTIVE, p); }catch{}
  }
  function extractProjectId(el){
    if(!el) return "";
    // try common dataset keys
    return (el.getAttribute("data-project-id")
      || el.getAttribute("data-project")
      || el.getAttribute("data-id")
      || "").trim();
  }

  function openProgrammer(projectId){
    const p = (projectId||"").trim() || getActiveProject();
    setActiveProject(p);
    if(typeof showPage === "function"){
      showPage("project-workspace:" + encodeURIComponent(p));
    }else{
      // fallback
      try{ location.hash = "#project-workspace:" + encodeURIComponent(p); }catch{}
    }
  }

  document.addEventListener("click", (ev)=>{
    const t = ev.target;
    if(!(t instanceof HTMLElement)) return;

    if(t.id === "dashOpenProgrammer"){
      openProgrammer("");
      return;
    }

    // Click any element inside p2ProjectsList that carries a project id
    const list = document.getElementById("p2ProjectsList");
    if(list && list.contains(t)){
      const hit = t.closest("[data-project-id],[data-project],[data-id]");
      if(hit){
        const pid = extractProjectId(hit);
        if(pid){
          openProgrammer(pid);
        }
      }
    }
  });

  // expose for debugging
  window.SERA_DASH_OPEN_PROGRAMMER = openProgrammer;
})();


// --- Theme toggle button hookup (header) ---
document.addEventListener('DOMContentLoaded', ()=>{
  const btn = document.getElementById('themeToggle');
  if(btn && window.SERA_THEME && window.SERA_THEME.toggle){
    btn.addEventListener('click', ()=>window.SERA_THEME.toggle());
    // apply initial theme
    try{ window.SERA_THEME.set(window.SERA_THEME.get()); }catch{}
  }
});
