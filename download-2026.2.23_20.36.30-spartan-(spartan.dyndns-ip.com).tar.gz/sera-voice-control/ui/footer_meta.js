/* Footer meta updater (safe, independent of dashboard wiring) */
(function(){
  function $(id){ return document.getElementById(id); }

  function getFallback(){
    const m = (typeof window !== "undefined" && window.__SERA_META__) ? window.__SERA_META__ : {};
    return {
      build_id: m.build_id || "UNKNOWN",
      version: m.version || null,
      host: (typeof location !== "undefined" && location.host) ? location.host : "?"
    };
  }

  async function run(){
    const el = $("footerStatus") || $("footer") || $("statusFooter");
    const info = $("footerInfo");
    if(!el) return;

    // Start with deterministic fallback
    const fb = getFallback();
    let host = fb.host;
    let build = fb.build_id || "UNKNOWN";
    let version = fb.version || null;

    // Prefer backend meta when available
    try{
      const r = await fetch("/api/meta", { cache: "no-store" });
      if(r.ok){
        const j = await r.json();
        if(j){
          build = j.build_id || j.run || j.version || build;
          host  = j.host || host;
          version = j.version || version;
        }
      }
    }catch(e){ /* ignore */ }

    const verStr = version ? `v${version}` : "v?";
    // Keep footer clean; show details on hover.
    el.textContent = `SERA AI • READY`;
    if(info){
      info.title = `${verStr} • Build:${build} • Host:${host}`;
    }
  }

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", run, { once: true });
  } else {
    run();
  }
})();
