(function(){
  // ---- per-script version marker (DEV) ----
  const SCRIPT_VERSION = "ui/project_builder.js@BUNDLE084.2";
  window.__SERA_SCRIPTS = window.__SERA_SCRIPTS || {};
  window.__SERA_SCRIPTS["project_builder.js"] = SCRIPT_VERSION;

  const $ = (id) => document.getElementById(id);

  function escapeHtml(s){
    return (s||"").replace(/[&<>"']/g, (m)=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;" }[m]));
  }

  function setStatus(el, msg, isErr=false){
    if(!el) return;
    el.textContent = msg || "";
    el.classList.toggle("err", !!isErr);
  }

  function getActiveProject(){
    try{
      const p = (localStorage.getItem("SERA_ACTIVE_PROJECT")||"").trim();
      return p || "default";
    }catch{ return "default"; }
  }
  function setActiveProject(p){
    try{ localStorage.setItem("SERA_ACTIVE_PROJECT", (p||"").trim()); }catch{}
  }

  async function apiGet(url){
    const r = await fetch(url, { cache:"no-store" });
    const ct = r.headers.get("content-type")||"";
    const out = ct.includes("application/json") ? await r.json() : await r.text();
    if(!r.ok) throw new Error(`${url} -> ${r.status}`);
    return out;
  }

  async function apiPost(url, body){
    const r = await fetch(url, {
      method:"POST",
      cache:"no-store",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify(body||{})
    });
    const ct = r.headers.get("content-type")||"";
    const out = ct.includes("application/json") ? await r.json() : await r.text();
    if(!r.ok){
      const msg = (out && out.detail) ? JSON.stringify(out.detail) : `${url} -> ${r.status}`;
      throw new Error(msg);
    }
    return out;
  }

  function humanErr(e){
    if(!e) return "Unknown error";
    const msg = (e.message||String(e));
    return msg.length > 200 ? msg.slice(0,200)+"…" : msg;
  }

  async function renderWorkspace(projectId){
    const pre = $("workspaceOut");
    if(!pre) return;
    pre.textContent = "Loading…";
    try{
      const j = await apiGet(`/api/projects/${encodeURIComponent(projectId)}/workspace`);
      pre.textContent = JSON.stringify(j, null, 2);
    }catch(e){
      pre.textContent = "Failed: " + humanErr(e);
    }
  }

  async function openWorkspace(projectId) {
    try{ localStorage.setItem("SERA_ACTIVE_PROJECT", String(projectId)); }catch(e){}
    const el = $("activeProject");
    if(el) el.textContent = projectId;
    await renderWorkspace(projectId);
  }

  async function renderProjects(){
    const listEl = $("projectsList");
    const errEl  = $("projectsErr");
    const nameEl = $("newProjectName");
    const tplEl  = $("newProjectTemplate");
    const createBtn = $("btnCreateProject");
    if(!listEl) return;

    async function refresh(){
      setStatus(errEl, "");
      listEl.innerHTML = "<div class='muted'>Loading...</div>";
      try{
        // Tool-gateway contract: POST /api/projects with {project:"name"} returns {registry:{projects:[...]}}
        // We call it with the currently active project to ensure it exists.
        const active = getActiveProject();
        const data = await apiPost("/api/projects", { project: active });
        const projects = (data && data.registry && Array.isArray(data.registry.projects)) ? data.registry.projects : [];

        if (!projects.length){
          listEl.innerHTML = "<div class='muted'>No projects yet.</div>";
          return;
        }

        listEl.innerHTML = "";
        for (const p of projects){
          const div = document.createElement("div");
          div.className = "p2item";
          div.title = p.path || "";
          div.innerHTML = `
            <div class="p2name">${escapeHtml(p.name || p.id)}</div>
            <div class="p2mono">${escapeHtml(p.id || "")}</div>
          `;
          div.addEventListener("click", () => {
            setActiveProject(p.id);
            openWorkspace(p.id);
          });
          listEl.appendChild(div);
        }
      }catch(e){
        setStatus(errEl, humanErr(e), true);
        listEl.innerHTML = "<div class='muted'>Failed to load.</div>";
      }
    }

    async function create(){
      setStatus(errEl, "");
      if (createBtn) createBtn.disabled = true;
      try{
        const name = (nameEl?.value || "").trim() || "default";
        // Template is a UI-only hint for now; backend doesn't accept it.
        const out = await apiPost("/api/projects", { project: name });
        const id = out?.created || out?.project?.id || name;
        setActiveProject(id);

        await refresh();
        if (id) openWorkspace(id);
      }catch(e){
        setStatus(errEl, humanErr(e), true);
      }finally{
        if (createBtn) createBtn.disabled = false;
      }
    }

    if (createBtn){
      createBtn.addEventListener("click", (ev) => {
        ev.preventDefault();
        create();
      });
    }
    if (nameEl){
      nameEl.addEventListener("keydown", (ev) => {
        if(ev.key === "Enter") create();
      });
    }

    // initial load
    await refresh();
  }

  
  // ---- expose Phase2 builder API for router integrations ----
  window.SERA_PROJECT_BUILDER = window.SERA_PROJECT_BUILDER || {};
  window.SERA_PROJECT_BUILDER.renderProjects = renderProjects;
  window.SERA_PROJECT_BUILDER.renderWorkspace = renderWorkspace;
  window.SERA_PROJECT_BUILDER.openWorkspace = openWorkspace;

  function getActiveProjectId(){
    try{ return localStorage.getItem("SERA_ACTIVE_PROJECT") || ""; }catch(e){ return ""; }
  }
  function setActiveProjectId(id){
    try{ if(id) localStorage.setItem("SERA_ACTIVE_PROJECT", String(id)); }catch(e){}
  }

  // When navigating directly to the workspace page, ensure it renders.
  function onNavigate(ev){
    const d = ev && ev.detail ? ev.detail : {};
    const page = String(d.page||"").toLowerCase();
    const payload = String(d.payload||"");
    if(page === "project-workspace"){
      const pid = payload || getActiveProjectId();
      if(pid) {
        setActiveProjectId(pid);
        renderWorkspace(pid).catch(console.warn);
      } else {
        // No project selected yet; renderProjects so user can pick one.
        renderProjects().catch(console.warn);
      }
    }
    if(page === "projects"){
      renderProjects().catch(console.warn);
    }
  }
  try{ window.addEventListener("sera:navigate", onNavigate); }catch(e){}
function init(){
    renderProjects().catch(console.warn);
  }

  window.addEventListener("DOMContentLoaded", init);
})();