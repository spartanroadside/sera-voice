
// ui/version.js
// Loaded as a classic script (NOT type="module")
window.SERA_UI_VERSION = window.SERA_UI_VERSION || "dev";
window.SERA_UI_BUILD_DATE = window.SERA_UI_BUILD_DATE || "";