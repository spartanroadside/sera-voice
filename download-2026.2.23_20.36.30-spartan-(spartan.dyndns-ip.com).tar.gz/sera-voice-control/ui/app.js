// deprecated: use dashboard.js

// User menu scaffold (v1.009)
(function(){
  const btn = document.getElementById('userBtn');
  const dd = document.getElementById('userDropdown');
  if(!btn || !dd) return;

  function close(){ dd.style.display='none'; }
  function toggle(){ dd.style.display = (dd.style.display==='none' || !dd.style.display) ? 'block' : 'none'; }

  btn.addEventListener('click', (e)=>{ e.stopPropagation(); toggle(); });
  document.addEventListener('click', ()=>close());

  dd.addEventListener('click', (e)=>{
    const t = e.target;
    if(!(t && t.dataset && t.dataset.action)) return;
    const a = t.dataset.action;
    if(a==='login') alert('Login UI not wired yet (scaffold).');
    if(a==='logout') alert('Logout UI not wired yet (scaffold).');
    if(a==='settings'){ try{ window.setPage && window.setPage('settings'); }catch(e){} return; }
    close();
  });
})();

/* BUNDLE077: tiny unified diff helper (client-side) */
window._unifiedDiff = function(aLines, bLines, aName, bName){
  // Very small diff: marks line-level changes; Phase 6 will replace with robust diff engine.
  const out = [];
  out.push(`--- ${aName}`);
  out.push(`+++ ${bName}`);
  const max = Math.max(aLines.length, bLines.length);
  for(let i=0;i<max;i++){
    const a = aLines[i];
    const b = bLines[i];
    if(a === b) continue;
    if(a !== undefined) out.push(`- ${a}`);
    if(b !== undefined) out.push(`+ ${b}`);
  }
  return out.join("\n");
};

/* BUNDLE077: Deploy Profiles (2-slot scaffold) */
function _defaultProfiles(){
  return {
    snapshotBeforePush: false,
    profiles: [
      { name:"voice-ui", container:"voice-ui", path:"/srv/app.js", restart:"voice-ui" },
      { name:"tool-gateway", container:"tool-gateway", path:"/app/server.py", restart:"tool-gateway" },
    ]
  };
}
function loadDeployProfiles(){
  try{
    const j = JSON.parse(localStorage.getItem("SERA_DEPLOY_PROFILES")||"null");
    if(j && j.profiles) return j;
  }catch(e){}
  return _defaultProfiles();
}
function saveDeployProfiles(obj){
  localStorage.setItem("SERA_DEPLOY_PROFILES", JSON.stringify(obj||_defaultProfiles()));
}
function loadProfilesToUI(){
  const d = loadDeployProfiles();
  document.getElementById("snapshotBeforePush").checked = !!d.snapshotBeforePush;
  const p1=d.profiles[0]||{}; const p2=d.profiles[1]||{};
  document.getElementById("p1_name").value = p1.name||"";
  document.getElementById("p1_container").value = p1.container||"";
  document.getElementById("p1_path").value = p1.path||"";
  document.getElementById("p1_restart").value = p1.restart||"";
  document.getElementById("p2_name").value = p2.name||"";
  document.getElementById("p2_container").value = p2.container||"";
  document.getElementById("p2_path").value = p2.path||"";
  document.getElementById("p2_restart").value = p2.restart||"";
}
function saveProfilesFromUI(){
  const d = loadDeployProfiles();
  d.snapshotBeforePush = !!document.getElementById("snapshotBeforePush").checked;
  d.profiles = [
    {
      name: document.getElementById("p1_name").value.trim(),
      container: document.getElementById("p1_container").value.trim(),
      path: document.getElementById("p1_path").value.trim(),
      restart: document.getElementById("p1_restart").value.trim(),
    },
    {
      name: document.getElementById("p2_name").value.trim(),
      container: document.getElementById("p2_container").value.trim(),
      path: document.getElementById("p2_path").value.trim(),
      restart: document.getElementById("p2_restart").value.trim(),
    }
  ];
  saveDeployProfiles(d);
  return d;
}
function populateDeployProfileSelect(){
  const sel = document.getElementById("deployProfileSel");
  if(!sel) return;
  const d = loadDeployProfiles();
  sel.innerHTML = (d.profiles||[]).map((p,i)=>`<option value="${i}">${escapeHtml(p.name||("Profile "+(i+1)))}</option>`).join("");
}
function applySelectedProfile(){
  const sel = document.getElementById("deployProfileSel");
  if(!sel) return;
  const idx = parseInt(sel.value||"0",10);
  const d = loadDeployProfiles();
  const p = (d.profiles||[])[idx] || {};
  const cInp = document.getElementById("deployContainer");
  const pInp = document.getElementById("deployPath");
  if(cInp) cInp.value = p.container||"";
  if(pInp) pInp.value = p.path||"";
  const rName = document.getElementById("restartServiceName");
  if(rName) rName.value = p.restart || p.container || "";
}
document.addEventListener("change", (ev)=>{
  const t = ev.target;
  if(t && t.id === "deployProfileSel"){
    applySelectedProfile();
  }
});
document.addEventListener("click", (ev)=>{
  const t = ev.target;
  if(!t) return;
  if(t.id === "profilesLoadBtn"){ loadProfilesToUI(); alert("Profiles loaded"); }
  if(t.id === "profilesSaveBtn"){ saveProfilesFromUI(); alert("Profiles saved"); populateDeployProfileSelectFromDB(); }
});

/* BUNDLE077_HOOKS */
(function(){
  const _orig = window.showPage;
  if(typeof _orig === "function"){
    window.showPage = function(pid){
      _orig(pid);
      if(pid === "settings"){
        setTimeout(()=>{ loadProfilesToUI(); }, 120);
      }
      if(pid === "projects"){
        setTimeout(()=>{ populateDeployProfileSelectFromDB(); }, 120);
      }
    };
  }
})();

async function openDeployedIntoEditor(){
  const c = document.getElementById("deployContainer").value.trim();
  const p = document.getElementById("deployPath").value.trim();
  if(!c || !p){ alert("Set deploy container + path."); return; }
  // preview diff vs deployed before confirm
  await prePushDiffPreview(c, p, document.getElementById("editorText").value||"");
  const st = document.getElementById("editorStatus");
  if(st) st.textContent = "Pulling D...";
  const j = await _fetchJson("/api/deploy/pull_file", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ container:c, path:p }) });
  document.getElementById("editorText").value = (j.text || "");
  if(st) st.textContent = "Loaded D";
}

document.addEventListener("click", (ev)=>{
  const t = ev.target;
  if(t && t.id === "editorOpenDeployedBtn"){
    ev.preventDefault();
    openDeployedIntoEditor().catch(e=>{ document.getElementById("editorStatus").textContent="Error"; alert(e.message||e); });
  }
});

/* BUNDLE078: DB-backed Deploy Profiles */
async function apiGetProfiles(){
  const j = await _fetchJson("/api/profiles", { method:"GET" });
  return (j.profiles || []);
}

async function apiSaveProfile(p){
  if(p.id){
    return await _fetchJson("/api/profiles/"+p.id, { method:"PUT", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(p) });
  }
  return await _fetchJson("/api/profiles", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(p) });
}

async function populateDeployProfileSelectFromDB(){
  const sel = document.getElementById("deployProfileSel");
  if(!sel) return;
  try{
    const profiles = await apiGetProfiles();
    sel.innerHTML = profiles.map((p)=>`<option value="${p.id}">${escapeHtml(p.name||("Profile "+p.id))}</option>`).join("");
    // store on window for quick lookup
    window.__deployProfiles = profiles;
    if(profiles.length){
      sel.value = String(profiles[0].id);
      applySelectedProfileFromDB();
    }
  }catch(e){
    console.warn("profiles load failed", e);
  }
}

function applySelectedProfileFromDB(){
  const sel = document.getElementById("deployProfileSel");
  const id = parseInt(sel.value||"0",10);
  const profiles = window.__deployProfiles || [];
  const p = profiles.find(x=>x.id===id) || {};
  const cInp = document.getElementById("deployContainer");
  const pInp = document.getElementById("deployPath");
  if(cInp) cInp.value = p.container||"";
  if(pInp) pInp.value = p.path||"";
  const rName = document.getElementById("restartServiceName");
  if(rName) rName.value = p.restart || p.container || "";
}

document.addEventListener("change",(ev)=>{
  const t = ev.target;
  if(t && t.id==="deployProfileSel"){ applySelectedProfileFromDB(); }
});

async function loadProfilesToUIFromDB(){
  const profiles = await apiGetProfiles();
  // map first two
  const p1 = profiles[0] || {};
  const p2 = profiles[1] || {};
  document.getElementById("p1_name").value = p1.name||"";
  document.getElementById("p1_container").value = p1.container||"";
  document.getElementById("p1_path").value = p1.path||"";
  document.getElementById("p1_restart").value = p1.restart||"";
  document.getElementById("p1_id").value = p1.id||"";
  document.getElementById("p2_name").value = p2.name||"";
  document.getElementById("p2_container").value = p2.container||"";
  document.getElementById("p2_path").value = p2.path||"";
  document.getElementById("p2_restart").value = p2.restart||"";
  document.getElementById("p2_id").value = p2.id||"";
}

async function saveProfilesFromUIToDB(){
  const p1 = { id: parseInt(document.getElementById("p1_id").value||"0",10) || undefined,
    name: document.getElementById("p1_name").value.trim(),
    container: document.getElementById("p1_container").value.trim(),
    path: document.getElementById("p1_path").value.trim(),
    restart: document.getElementById("p1_restart").value.trim(),
  };
  const p2 = { id: parseInt(document.getElementById("p2_id").value||"0",10) || undefined,
    name: document.getElementById("p2_name").value.trim(),
    container: document.getElementById("p2_container").value.trim(),
    path: document.getElementById("p2_path").value.trim(),
    restart: document.getElementById("p2_restart").value.trim(),
  };
  await apiSaveProfile(p1);
  await apiSaveProfile(p2);
  await populateDeployProfileSelectFromDB();
}

document.addEventListener("click",(ev)=>{
  const t=ev.target;
  if(!t) return;
  if(t.id==="profilesLoadBtn"){
    loadProfilesToUIFromDB().then(()=>alert("Profiles loaded (DB)")).catch(e=>alert(e.message||e));
  }
  if(t.id==="profilesSaveBtn"){
    saveProfilesFromUIToDB().then(()=>alert("Profiles saved (DB)")).catch(e=>alert(e.message||e));
  }
});

/* BUNDLE079: Profiles CRUD list UI */
function renderProfilesList(profiles){
  const el = document.getElementById("profilesList");
  if(!el) return;
  el.innerHTML = "";
  (profiles||[]).forEach(p=>{
    const row = document.createElement("div");
    row.className = "row";
    row.style.justifyContent="space-between";
    row.style.padding="8px";
    row.style.border="1px solid rgba(255,255,255,0.08)";
    row.style.borderRadius="10px";
    row.style.marginBottom="8px";
    row.style.cursor="pointer";
    row.innerHTML = `<div><div><b>${escapeHtml(p.name||("Profile "+p.id))}</b></div><div class="small" style="opacity:.75">${escapeHtml(p.container||"")} · ${escapeHtml(p.path||"")}</div></div><div class="small" style="opacity:.65">#${p.id}</div>`;
    row.addEventListener("click", ()=>{
      window.__deployProfiles = profiles;
      // populate editor
      document.getElementById("pe_id").value = p.id || "";
      document.getElementById("pe_name").value = p.name || "";
      document.getElementById("pe_container").value = p.container || "";
      document.getElementById("pe_path").value = p.path || "";
      document.getElementById("pe_restart").value = p.restart || "";
    });
    el.appendChild(row);
  });
}

async function refreshProfilesList(){
  try{
    const profiles = await apiGetProfiles();
    window.__deployProfiles = profiles;
    renderProfilesList(profiles);
    // also refresh editor dropdown
    const sel = document.getElementById("deployProfileSel");
    if(sel){
      sel.innerHTML = profiles.map((p)=>`<option value="${p.id}">${escapeHtml(p.name||("Profile "+p.id))}</option>`).join("");
      if(profiles.length){
        sel.value = String(profiles[0].id);
        applySelectedProfileFromDB();
      }
    }
  }catch(e){
    alert(e.message || e);
  }
}

async function addProfile(){
  document.getElementById("pe_id").value = "";
  document.getElementById("pe_name").value = "new-profile";
  document.getElementById("pe_container").value = "voice-ui";
  document.getElementById("pe_path").value = "/srv/app.js";
  document.getElementById("pe_restart").value = "voice-ui";
  window.scrollTo(0, document.body.scrollHeight);
}

async function saveProfileEditor(){
  const id = parseInt(document.getElementById("pe_id").value||"0",10) || undefined;
  const p = {
    id,
    name: document.getElementById("pe_name").value.trim(),
    container: document.getElementById("pe_container").value.trim(),
    path: document.getElementById("pe_path").value.trim(),
    restart: document.getElementById("pe_restart").value.trim(),
  };
  await apiSaveProfile(p);
  await refreshProfilesList();
  alert("Saved");
}

async function deleteProfileEditor(){
  const id = parseInt(document.getElementById("pe_id").value||"0",10);
  if(!id) { alert("Select a profile first"); return; }
  if(!confirm("Delete profile #" + id + "?")) return;
  await _fetchJson("/api/profiles/"+id, { method:"DELETE" });
  document.getElementById("pe_id").value = "";
  await refreshProfilesList();
  alert("Deleted");
}

document.addEventListener("click",(ev)=>{
  const t=ev.target;
  if(!t) return;
  if(t.id==="profilesRefreshBtn"){ refreshProfilesList(); }
  if(t.id==="profileAddBtn"){ addProfile(); }
  if(t.id==="profileSaveBtn"){ saveProfileEditor().catch(e=>alert(e.message||e)); }
  if(t.id==="profileDeleteBtn"){ deleteProfileEditor().catch(e=>alert(e.message||e)); }
});

// auto-load on settings page
(function(){
  const _orig = window.showPage;
  if(typeof _orig === "function"){
    window.showPage = function(pid){
      _orig(pid);
      if(pid === "settings"){
        setTimeout(()=>{ refreshProfilesList().catch(()=>{}); }, 150);
      }
    };
  }
})();

async function prePushDiffPreview(container, path, localText){
  try{
    const wrap = document.getElementById("diffBoxWrap");
    const box = document.getElementById("diffBox");
    if(!wrap || !box) return;
    const j = await _fetchJson("/api/deploy/pull_file", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ container, path }) });
    const remote = (j.text||"").split("\n");
    const local = (localText||"").split("\n");
    wrap.style.display = "";
    box.textContent = window._unifiedDiff ? window._unifiedDiff(remote, local, "deployed", "local") : "(diff helper missing)";
  }catch(e){}
}

/* BUNDLE079: Actions viewer */
async function refreshActions(){
  const out = document.getElementById("actionsOut");
  const lim = parseInt((document.getElementById("actionsLimit")||{}).value||"200",10) || 200;
  if(out) out.textContent = "Loading...";
  const j = await _fetchJson("/api/actions?limit="+encodeURIComponent(String(lim)), { method:"GET" });
  if(out) out.textContent = JSON.stringify(j.actions||[], null, 2);
}
document.addEventListener("click",(ev)=>{
  const t=ev.target;
  if(t && t.id==="actionsRefreshBtn"){ refreshActions().catch(e=>alert(e.message||e)); }
});


/* BUNDLE080: formatted deploy report */
function renderDeployReportFormatted(obj){
  const wrap = document.getElementById("deployReportWrap");
  const pre = document.getElementById("deployReport");
  if(!wrap || !pre) return;
  wrap.style.display = "";
  const lines = [];
  lines.push("=== DEPLOY RESULT ===");
  if(obj.snapshot) lines.push("Snapshot: " + JSON.stringify(obj.snapshot));
  if(obj.backup) lines.push("Backup: " + JSON.stringify(obj.backup));
  if(obj.restart) lines.push("Restart: " + JSON.stringify(obj.restart));
  if(obj.health){
    lines.push("Health:");
    obj.health.forEach(h=> lines.push("  " + h.url + " => " + (h.ok?"OK":"FAIL")));
  }
  pre.textContent = lines.join("\n");
}


// BUNDLE081: override RBAC init to use /api/rbac/me if not already
async function _initRBAC2(){
  try{
    const j = await _fetchJson("/api/rbac/me",{method:"GET"});
    applyUserRoleUI(j.role||"guest");
  }catch(e){ applyUserRoleUI("guest"); }
}
document.addEventListener("DOMContentLoaded", ()=>{ setTimeout(_initRBAC2, 350); });


/* BUNDLE081: System widgets */
async function refreshHealthMatrix(){
  const out = document.getElementById("healthMatrixOut");
  if(out) out.textContent="Loading...";
  const j = await _fetchJson("/api/sys/health_matrix",{method:"GET"});
  if(out) out.textContent = JSON.stringify(j, null, 2);
}

function _serviceRowHtml(c){
  const name = escapeHtml(c.name||"");
  const status = escapeHtml(c.status||"");
  const img = escapeHtml(c.image||"");
  const ports = escapeHtml(c.ports||"");
  return `<div class="row" style="justify-content:space-between;gap:10px;padding:8px;border:1px solid rgba(255,255,255,0.08);border-radius:12px;margin-bottom:8px;align-items:center;flex-wrap:wrap">
    <div style="min-width:260px">
      <div><b>${name}</b></div>
      <div class="small" style="opacity:.75">${status}</div>
      <div class="small" style="opacity:.6">${img}</div>
      <div class="small" style="opacity:.6">${ports}</div>
    </div>
    <div class="row" style="gap:8px">
      <button class="ghost" data-requires-priv="1" data-svc-restart="${name}">Restart</button>
    </div>
  </div>`;
}

async function refreshServices(){
  const el = document.getElementById("servicesTable");
  if(!el) return;
  el.innerHTML = "<div class='small'>Loading...</div>";
  const j = await _fetchJson("/api/services/list",{method:"GET"});
  const containers = j.containers || [];
  const compose = (j.compose && j.compose.services) ? j.compose.services : [];
  let html = "";
  html += `<div class="small" style="opacity:.8;margin-bottom:8px">Compose: ${escapeHtml((j.compose&&j.compose.path)||"")}</div>`;
  if(compose.length){
    html += `<div class="small" style="opacity:.8;margin-bottom:8px">Services: ${compose.map(escapeHtml).join(", ")}</div>`;
  }
  containers.forEach(c=>{ html += _serviceRowHtml(c); });
  el.innerHTML = html || "<div class='small'>No containers found.</div>";
  // re-apply RBAC hiding for newly added buttons
  const role = document.body.getAttribute("data-user-role") || "guest";
  applyUserRoleUI(role);
}

document.addEventListener("click",(ev)=>{
  const t = ev.target;
  if(!t) return;
  if(t.id==="healthMatrixRefreshBtn"){ refreshHealthMatrix().catch(e=>alert(e.message||e)); }
  if(t.id==="servicesRefreshBtn"){ refreshServices().catch(e=>alert(e.message||e)); }
  if(t.dataset && t.dataset.svcRestart){
    const name = t.dataset.svcRestart;
    _fetchJson("/api/services/restart",{method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({name})})
      .then(j=>alert("Restarted: "+name))
      .catch(e=>alert(e.message||e));
  }
});


/* BUNDLE081: A/C file open + C write */
async function openFileFromRoot(root){
  const p = document.getElementById("deployPath").value.trim();
  if(!p){ alert("Set path first"); return; }
  const j = await _fetchJson("/api/files/read?root="+encodeURIComponent(root)+"&path="+encodeURIComponent(p),{method:"GET"});
  document.getElementById("editorText").value = j.text || "";
}

async function saveFileToC(){
  const p = document.getElementById("deployPath").value.trim();
  if(!p){ alert("Set path first"); return; }
  const text = document.getElementById("editorText").value || "";
  await _fetchJson("/api/files/write",{method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({root:"C", path:p, text})});
  alert("Saved to C: "+p);
}

document.addEventListener("click",(ev)=>{
  const t = ev.target;
  if(!t) return;
  if(t.id==="editorOpenA"){ openFileFromRoot("A").catch(e=>alert(e.message||e)); }
  if(t.id==="editorOpenC"){ openFileFromRoot("C").catch(e=>alert(e.message||e)); }
  if(t.id==="editorSaveC"){ saveFileToC().catch(e=>alert(e.message||e)); }
});


// ---- Build info footer ----
(function(){
  const el = document.getElementById("buildInfo");
  if(!el) return;
  let txt = "";
  try{ txt = (window.__SERA_BUILD || "").trim(); }catch{}
  if(!txt){
    try{ txt = (document.title || "").trim(); }catch{}
  }
  if(!txt) txt = "local";
  el.textContent = txt;
  window.SERA_BUILDINFO = txt;
})();
