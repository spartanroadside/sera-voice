# BUNDLE097 – Threads API Contract Fix (UI)

Fixes 400 Bad Request on `POST /api/threads/list` by sending both fields expected by backend:
- `project`
- `project_id` (same value)

Changed:
- ui/threads.js
- ui/projects_threads.js
