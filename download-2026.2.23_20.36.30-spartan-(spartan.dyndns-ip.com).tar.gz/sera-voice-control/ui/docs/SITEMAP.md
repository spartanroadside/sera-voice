# Sitemap

## / (Voice)
- Connect/disconnect realtime voice session
- System health + CPU/RAM pills
- Tools/actions quick buttons
- File upload/download panel
- Projects/Threads panel (basic)

## /deploy.html (Deploy)
- List bundles from `/incoming`
- Trigger deploy through voice-gateway → tool-gateway
- Show deploy output / status

## /docs.html (Docs)
- View markdown docs shipped with UI at `/docs/*`

Future pages (RUN12+):
- /chat.html (Chat threads sidebar + main chat)
- /tools.html (plugin/tool install + pipeline tools)
- /logs.html (deploy/service logs viewer)
- /admin.html (system config, users, quotas)
