# Patch BUNDLE090: Threads under Chat sidebar + quick navigation

## What this patch does
- Adds a **Threads** section to the Chat sidebar (mini list from `/api/threads/list`).
- Clicking a thread takes you to the existing **Threads (Legacy)** page and preserves active project.
- Adds a small helper to `threads.js` to default the project selector from `localStorage.SERA_ACTIVE_PROJECT`.
- Adds `.smallBtn` styling if missing.

## Files changed
- `ui/index.html`
- `ui/chat.js`
- `ui/threads.js`
- `ui/main.css`

## Notes
- This does not delete the Threads page; it simply relocates the entry point under Chat.
- Full integration (opening a specific thread view) can be added next by extending `threads.js` to pre-select by `SERA_ACTIVE_THREAD_ID`.
