# Home Assistant (notes)

You can run Home Assistant alongside SERA (host networking is already used).

Current server pattern (example):
- Container: `ghcr.io/home-assistant/home-assistant:stable`
- Data dir: `/home/spartan/sera/sera-ai/ha/config` (recommended)

SERA does **not** directly control HA yet.
Planned integration (RUN12+):
- Add a Tool Gateway plugin that can:
  - Call HA REST API
  - Manage whitelisted devices (IP allowlist)
  - Expose high-level intents (lights, scenes, automations)

Security:
- Keep HA and SERA behind LAN/VPN.
- Use long-lived access token for HA stored server-side (never in browser).
