# BUNDLE101 – Sticky header area + footer build info

Adds:
- A sticky header wrapper so logo/header/nav/global menu remain visible while pages scroll.
- Populates footer buildInfo from __SERA_BUILD or document.title.

Files changed:
- ui/index.html
- ui/main.css
- ui/app.js
