# Build Guide (RUN11–RUN15)

## RUN11 (this bundle)
- Fix UI JS syntax failure (no inline scripts)
- Add `/api/*` alias routes in voice-gateway
- Add UI footer tracking RUN + statuses
- Add docs viewer + ship docs in UI `/docs`
- Add log/backup retention doc + rotation script
- Harden installer: create missing folders, copy tools

## RUN12
- Split UI into dedicated pages (Voice/Chat/Deploy/Tools/Logs/Admin)
- Add in-UI bundle selection + rollback UX
- Add plugin install UI

## RUN13
- ChatGPT-like chat UX (threads sidebar, per-project memory)
- File pipeline UI (upload → process → download)

## RUN14
- Tool marketplace: OCR, VTT validator, syntax checkers, media processors
- Quarantine/temp storage policies

## RUN15
- Multi-user auth + per-user isolation
- Permissions + quotas per user/project
