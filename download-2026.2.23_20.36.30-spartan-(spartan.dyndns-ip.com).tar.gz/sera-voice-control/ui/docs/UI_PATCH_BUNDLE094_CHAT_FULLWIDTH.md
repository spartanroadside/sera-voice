# BUNDLE094 – Chat Full-Width Layout

Goals:
- Make the Chat page fill the page (main chat area extends right).
- Provide a consistent left sidebar region suitable for Threads (threads-under-chat).
- Prevent workspace layouts from visually covering the global header by avoiding 100vh usage.

Changed:
- ui/index.html (chat section wrapped in .chatLayout)
- ui/main.css (added .chatLayout styles)
