# BUNDLE103 – Threads as Chat-side feature (hide legacy top nav)

Goals:
- Remove Threads (Legacy) from the top nav/global bar to reduce clutter.
- Keep Threads accessible via:
  - Dashboard module card
  - Chat sidebar (Threads panel + Legacy button)
- Add a dedicated `#chatThreadsPanel` container for the mini threads list.

Files changed:
- ui/index.html
- ui/main.css
