# BUNDLE102 – Settings self-heal UI (Profiles + Base URL)

Fixes cases where the Settings page loses the LAN/WAN/Local profile dropdown UI
due to missing DOM elements.

Adds:
- ensureSettingsUI(): injects the expected controls into #page-settings if missing
- Base URL save/clear controls backed by localStorage key SERA_BASE_URL
- Keeps window.__SERA_BASE_URL updated for other scripts/diagnostics

File changed:
- ui/settings.js
