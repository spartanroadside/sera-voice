# UI Folder Familiarization + Layout Roadmap (2026-02-21 snapshot)

This guide is based on the uploaded `ui/` folder tarball and your layout notes + sketches (Program Builder workbench + Voice page PTT).

## 1) Key files and what they do

### App shell / routing
- `ui/index.html`
  - Defines **global header** (logo + user menu), stats bar, main nav buttons, and all page `<section id="page-...">` containers.
- `ui/dashboard.js`
  - Owns `showPage()` routing and nav wiring (`[data-page]` buttons).
  - Dispatches `sera:navigate` event for page modules.
- `ui/app.css`
  - Theme variables (currently **dark only**).
- `ui/main.css`
  - Canonical overrides: header centering, chat layout v2, voice layout, etc.

### Major page modules
- `ui/voice_client.js` + Voice section in `index.html`
- `ui/chat.js` (Chat page UI)
- `ui/threads.js` (Legacy Threads page)
- `ui/projects_threads.js` + `ui/project_builder.js` + `ui/project_builder.css`
  - Projects dashboard and the Program Builder/Workspace logic.
- `ui/system_ops.js`, `ui/sysdiag_view.js`, `ui/troubleshoot_suite.js`
  - System tools / diagnostics pages

## 2) Your requested direction (high level)

### Global
- Every page: header/logo + footer + main nav stays visible.
- Restore **light/dark** toggle (persisted).
- Preserve System Tools navigation buttons across System pages.
- Restore Settings LAN/WAN/Local dropdown.

### Navigation & IA
- Rename "Projects Dashboard" -> "Dashboard"
- From Dashboard, click a project to open Program Builder.
- Threads should be accessible from Chat (move thread list into chat sidebar; keep Threads page as legacy or remove later).

### Voice page
- Round PTT button (center)
- Optional small text box on the right

## 3) This patch (BUNDLE088) does

- Adds a global **Theme** button in the header and implements light/dark mode toggle with `localStorage` key `sera.theme`.
- Ensures the Voice page matches your sketch: **round PTT button** + right-side "Quick text" panel.
- Renames nav label "Projects Dashboard" to "Dashboard" and marks Threads as legacy.
- Adds z-index layering so nav/header stay clickable if a page tries to overlay it.

## 4) Next patches (recommended sequencing)

### Patch A (Navigation / trapped pages)
- Ensure Program Builder uses `height:100%` not `100vh`, and never covers header/nav.
- Convert `.wrap` to a flex column shell so header + nav are always on top and content scrolls.

### Patch B (Threads under Chat)
- Add a Threads list panel in Chat sidebar (reuse `/api/threads/list` contract).
- Keep Threads page but mark as "Legacy" until removal.

### Patch C (Dashboard / Projects rewrite)
- Rename `page-projects` content to "Dashboard".
- Make project cards open Program Builder page with correct project context.
- Modularize dashboard widgets for future expansion.

### Patch D (Settings LAN/WAN/Local)
- Restore profile dropdown in Settings page and confirm endpoint mapping.

### Patch E (Voice troubleshooting)
- Confirm voice endpoints used by `voice_client.js` and backend routes, add visible status info, and re-enable service health checks.