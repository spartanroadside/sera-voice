# BUNDLE092 – System Tools Quick Nav Everywhere

This patch makes the **System Tools quick navigation** card appear at the top of:
- Deploy
- Admin
- Troubleshoot
- Settings
(and System already had it)

Purpose: you never get “stuck” inside a system page, and admin/diagnostics navigation is always one click away.

Changed files:
- ui/index.html
- ui/main.css
