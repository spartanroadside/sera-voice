# BUNDLE098 – Backups/Create + Export Pack contract fix (422)

Fixes UI calls that were returning 422 due to missing required `project` query parameter
and/or differing backend expectations.

Changes:
- Ensure requests include `?project=<id>` on:
  - POST /api/backups/create
  - POST /api/projects/export_pack
- Include `project` + `project_id` in the JSON body for forward/backward compatibility.

File changed:
- ui/backups.js
