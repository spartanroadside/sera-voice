# UI Patch: Global Button Header Bar + Voice Round PTT

## Summary
This patch adds an always-visible **global button header bar** under the existing top nav and updates the Voice page to match the round **PTT** concept sketch.

## Changes
### Global button header bar
Inserted `div.globalBar` under `.nav` in `ui/index.html` with:
- Back
- Voice / Chat / Dashboard / Programmer / System Tools
- Settings / Theme

`ui/dashboard.js` wires:
- `#btnGlobalBack` -> history.back()
- `#btnProgrammer` -> showPage('project-workspace:<activeProject>')
- `#btnTheme` -> calls existing toggleTheme()

### Voice page
Replaces the wide PTT button row with a round PTT UI while preserving `id="btnPTT"` for compatibility.
Adds optional right-side textarea `#voiceQuickNote`.

### Small fixes
- Logo image src made consistent (PNG)
- Nav labels:
  - Threads -> Threads (Legacy)
  - Projects Dashboard -> Dashboard

## Files changed
- ui/index.html
- ui/dashboard.js
- ui/main.css
