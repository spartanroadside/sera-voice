# BUNDLE095 – App Shell Guarantee (Header/Logo/Footer + Global Menu)

Goals:
- Guarantee the global header/logo/nav/globalBar render on all pages (app shell).
- Ensure page sections live in a dedicated <main id="pages"> container that flexes to fill the viewport.
- Add a consistent footer across the app.
- Restore light-theme CSS overrides if missing.

Changes:
- ui/index.html: wraps all <section id="page-..."> blocks in <main id="pages" class="pages"> and adds <footer>.
- ui/main.css: app shell flex layout + footer styles + proper min-height/scroll behavior.
- ui/app.css: adds body.light theme overrides (only if missing).
