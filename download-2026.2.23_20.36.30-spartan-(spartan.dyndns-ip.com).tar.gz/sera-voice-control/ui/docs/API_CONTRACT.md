# API Contract

UI talks to **voice-gateway** at `/api/*`.

## Conventions
- `GET /api/status` → { run, voice, tool, agent }
- `GET /api/sys/metrics` → { loadavg, meminfo, ... } passthrough
- Tool endpoints are proxied; token is injected server-side.

## Key endpoints
- `GET  /api/bundles/list`
- `POST /api/deploy/bundle`
- `POST /api/files/list`
- `POST /api/files/upload_b64`
- `GET  /api/files/download?path=...&project=...`
- `POST /api/backups/restore`
- `GET  /api/plugins/list`
- `GET/POST /api/projects/*`
- `POST /api/threads/*`

## Error shape (recommended)
- `{ ok:false, error:"...", details?:any }`
