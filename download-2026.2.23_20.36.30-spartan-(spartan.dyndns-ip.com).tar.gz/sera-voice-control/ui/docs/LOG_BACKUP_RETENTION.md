# Log & Backup Retention

Recommended defaults:
- Deploy logs: keep 30 days or last 200
- Backups: keep last 10 per project
- Workspaces:
  - tmp/: purge > 24h
  - outbox/: purge > 30d (unless pinned)
  - uploads/: keep 30d

Implementation:
- `/home/spartan/sera/sera-ai/tools/sera_rotate.sh` (dry-run by default)
