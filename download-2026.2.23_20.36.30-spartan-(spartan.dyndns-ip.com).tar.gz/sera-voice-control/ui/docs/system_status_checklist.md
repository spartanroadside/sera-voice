# ADD TO UPDATE — System Status Page + Persistent Checklist (Next Build Module)

Date: 2026-02-11  
Target: Next bundle run (add “System Status” UI + backend persistence + per-operation notes)

---

## Goal

Add a **System Status** page in the UI that displays **all system + UI operations** and lets the user:

- Mark each operation as **Working / Not working / Unknown**
- Add **individual notes per operation** (not global notes)
- Auto-save changes (no “submit” required, but allow optional “Save” + “Reset” buttons)
- Persist this checklist + notes across runs so it **carries into the next build run**

This becomes the canonical “what works / what’s broken” tracker inside the app.

---

## Deliverables (must be included in the next build)

### 1) Persistent storage (host + container)

Create a new host directory:

- `/home/spartan/sera/sera-ai/sera-voice-control/state/`

Persisted file:

- `/home/spartan/sera/sera-ai/sera-voice-control/state/system_checklist.json`

Bind-mount into the backend container (recommended: voice-gateway):

- host: `/home/spartan/sera/sera-ai/sera-voice-control/state`
- container: `/state`
- file path inside container: `/state/system_checklist.json`

**Compose change (example):**
- Add to `voice-gateway` service:
  - `- ./state:/state`  (or absolute bind if you prefer)

> IMPORTANT: This file must be treated as “protected state” during updates and backups.

---

### 2) Backend API endpoints (recommended location: voice-gateway)

Add these endpoints:

#### A) GET `/system/checklist`
Returns the persisted checklist JSON. If file does not exist, return a default template (all items `unknown`).

#### B) PUT `/system/checklist/item/{id}`
Updates one operation item.

Request body:
```json
{ "status": "working|broken|unknown", "note": "string" }
```

Server behavior:
- Validate `status` enum
- Trim note (keep full text, but cap length e.g. 2000 chars)
- Update `updated_at` timestamp on that item
- Write JSON to `/state/system_checklist.json` atomically
  - write temp file then rename

Response: updated item and overall `meta.updated_at`

#### C) GET `/system/checklist/template`
Returns the default template used when file missing (helps UI reset)

#### D) OPTIONAL: POST `/system/checklist/probe`
Runs a quick probe of system health and returns computed statuses (does NOT overwrite unless UI chooses to apply).
Examples:
- check `/__ping` for voice-ui via internal routing (or direct services)
- check gateway `/health`
- check tool-gateway route
- check agent-runner route

---

### 3) Status data model (stable operation IDs)

#### JSON schema (store per-operation notes + status)
```json
{
  "meta": {
    "run_tag": "1.006",
    "updated_at": "2026-02-11T22:14:00-05:00",
    "updated_by": "spartan"
  },
  "items": {
    "svc.voice_gateway.running": { "status": "working", "note": "", "updated_at": "..." },
    "ui.page.system.loads":      { "status": "unknown", "note": "", "updated_at": null }
  }
}
```

#### Status enum
- `working`
- `broken`
- `unknown`

#### Operation ID naming rules
Use stable dot-path identifiers:
- `svc.<service>.running`
- `net.port.<port>.listening`
- `route.<name>`
- `installer.<feature>`
- `ui.page.<page>.loads`
- `ui.action.<feature>`

IDs must never change once introduced (or provide an alias/migration map).

---

### 4) UI: new page + navigation link

Add a UI navigation link: **System** → route `/system`

Create new page/component:
- `/system` (or `/system/status`)

Page features:
- Summary header: counts of Working / Broken / Unknown
- Search box (filters by ID/label)
- Filter toggles: All / Broken / Unknown / Working
- Sections (collapsible):
  1) Core stack
  2) Services & ports
  3) Routes (reverse proxies)
  4) Installer features
  5) Home Assistant integration
  6) UI functions

Each row:
- Label + short description
- Status controls:
  - ✅ Working
  - ❌ Not working
  - ⬜ Unknown
- Notes field (textarea)
- Last updated timestamp
- OPTIONAL “Probe” button if endpoint exists

Autosave behavior:
- Debounce note writes (e.g. 500–800ms)
- Status click saves immediately
- Visual “Saved ✓” indicator per row (or small toast)

---

## Default checklist items (seed list)

> Include this seed list in code as the default template (all unknown).

### Core / stack
- `core.docker.running`
- `core.compose.available`
- `core.paths.root_exists`
- `core.paths.incoming_exists`
- `installer.sha_filename_agnostic`
- `installer.force_recreate_on_version_change`
- `installer.modes.update`
- `installer.modes.fresh`
- `installer.modes.repair`
- `installer.modes.rollback`

### Services
- `svc.voice_ui.running`
- `svc.voice_gateway.running`
- `svc.tool_gateway.running`
- `svc.agent_runner.running`
- `svc.home_assistant.running`
- `svc.qdrant.running`

### Ports (host-visible)
- `net.port.8080.listening`
- `net.port.8443.listening`
- `net.port.6333.listening`

### Routes (Caddy)
- `route.http.ping`
- `route.https.ping`
- `route.ui.index`
- `route.api_proxy`
- `route.sysdiag_proxy`
- `route.agent_proxy`

### Home Assistant integration (planned)
- `ha.configured`
- `ha.reachable`
- `ha.webhook_configured`

### UI functions (seed)
- `ui.page.home.loads`
- `ui.page.system.loads`
- `ui.assets.load_ok`
- `ui.router.navigation_ok`
- `ui.voice.mic_toggle`
- `ui.voice.capture_audio`
- `ui.voice.send_request`
- `ui.voice.playback_audio`
- `ui.agent.prompt_submit`
- `ui.agent.stream_response`
- `ui.sysdiag.view`
- `ui.sysdiag.run_test`

---

## Implementation notes

### Atomic writes (required)
When saving checklist file:
1) write to `/state/system_checklist.json.tmp`
2) `fsync`
3) rename to `/state/system_checklist.json`

### Backward compatibility (recommended)
If older file exists, merge with new template:
- keep existing statuses/notes
- add any missing new IDs as unknown

### Security
- If the UI is unauthenticated, this page should still be safe (no secrets).
- Notes should be plain text only (escape in UI).

---

## Acceptance tests (must pass)

### Container / health
- voice-gateway continues to run with `/state` mount
- `GET /system/checklist` returns valid JSON
- `PUT /system/checklist/item/{id}` persists and survives container restart

### UI
- `/system` page loads
- Click status saves and reload shows same status
- Notes confirm saved after reload
- Filter/search works
- Counts update correctly

### Persistence across runs
- Update/deploy does NOT wipe `/home/spartan/sera/sera-ai/sera-voice-control/state/system_checklist.json`
- Backup process includes the `/state` directory

---

## Files to add / modify

- `voice-gateway/` backend:
  - add router/controller for `/system/checklist*`
  - add filesystem storage helper
  - add default template list (IDs + labels)

- `ui/` frontend:
  - new System page route
  - new nav link
  - components: StatusToggle, NotesField, SectionPanel
  - client API wrapper for endpoints

- `docker-compose.yml`:
  - bind mount `./state:/state` for voice-gateway (or tool-gateway)

- `docs/`:
  - update “Features / System Status” section explaining usage

---

## Optional next-step enhancements (nice-to-have)

- Add “Probe all” to call `/system/checklist/probe` and apply results selectively
- Export button: download checklist JSON
- Import button: load checklist JSON
- Per-item “Test command” displayed in UI (copy/paste)
