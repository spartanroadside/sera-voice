# BUNDLE100 – Dashboard modules + click project -> Programmer

Adds a modular dashboard layout:
- 3 cards: Programmer / Chat / System
- 'Open Programmer' button (uses active project)
- Tip text: click a project to open in Programmer

Also adds robust click handling:
- Clicking any project item in #p2ProjectsList with data-project-id/data-project/data-id opens Programmer.

Files changed:
- ui/index.html
- ui/dashboard.js
- ui/main.css
