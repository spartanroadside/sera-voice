# SERA System Guide (non-negotiables)

## Contracts
- UI calls only `voice-gateway` under `/api/*`
- No UI secrets/tokens in browser
- Responses are JSON; errors are explicit and surfaced

## JS rules
- No inline JS in HTML (use `ui/app.js`, `ui/deploy.js`, etc.)
- Any bundle build must pass JS syntax checks (`node --check`)

## Folder layout (server root)
Target root (default): `/home/spartan/sera`
- `incoming/` bundles uploaded for deploy
- `outgoing/` exports/snapshots for download
- `backups/<project>/` backup tarballs + manifests
- `logs/<project>/` deploy logs
- `workspaces/<project>/` uploads/tmp/outbox/restores

## Docker
- Host networking (Virtualmin/Apache coexistence friendly)
- Keep ports explicit; do not bind UI to public interfaces without protection.

## Auth (future)
- RUN15: multi-user auth (sessions)
- Until then: restrict access at reverse proxy / VPN / LAN rules.
