# BUNDLE096 – Diagnostics Page + Endpoint Consistency Helpers

Adds a new **Diagnostics** page that:
- shows client/base URL/active project/theme
- runs health probes against common endpoints
- lists recent fetch() failures and non-2xx responses (captured globally)

Also adds:
- global fetch wrapper to capture API errors into localStorage (last 25)

Files changed:
- ui/index.html
- ui/app.js
- ui/main.css
