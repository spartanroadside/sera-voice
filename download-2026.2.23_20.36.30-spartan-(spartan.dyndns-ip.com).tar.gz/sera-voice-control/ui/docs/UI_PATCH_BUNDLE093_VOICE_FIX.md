# BUNDLE093 – Voice page fix

Fixes voice page by aligning `ui/partials/voice.html` with `ui/voice_client.js` expected element IDs.
Adds round PTT UI and basic voice input/send controls.
Adds CSS for voice layout and improves logging when voice UI elements are missing.

Changed files:
- ui/partials/voice.html
- ui/voice_client.js
- ui/main.css
