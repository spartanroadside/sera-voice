# BUNDLE091 – Dashboard → Programmer + Settings Profiles UI

## What this patch does
1) **Dashboard naming cleanup**
- Renames "Projects Dashboard" to **Dashboard** in the Projects page header (UI text only).

2) **Click project → open Programmer**
- Adds a delegated click handler on `#p2ProjectsList` so clicks on elements containing
  `data-project`, `data-project-id`, or `data-id` will:
  - set `localStorage.SERA_ACTIVE_PROJECT`
  - navigate to `project-workspace:<projectId>`

> This is intentionally flexible because the projects list may render different card markup over time.

3) **Restore LAN/WAN/Local profile dropdown in Settings**
- Injects missing Settings HTML controls expected by `ui/settings.js`:
  - `#profileSelect`, `#btnProfilesReload`, `#profileDetails`
  - path/base/tool/agent inputs and load/save controls
  - `#settingsStatus`

## Files changed
- `ui/index.html`
- `ui/dashboard.js`
- `ui/docs/UI_PATCH_BUNDLE091.md` (this file)

## Install
Copy tarball + sha into `/home/spartan/sera/sera-ai/incoming/` and apply using installer PATCH mode.
