# SERA Voice Control (SERA AI Stack)

A lightweight, self-hosted control plane for:
- **Voice**: OpenAI Realtime WebRTC session (mic ↔ model ↔ audio)
- **Agent/Tools**: local tool-gateway + agent-runner for file ops, deploy actions, and project/thread storage
- **UI**: responsive Caddy-served static UI (Voice, Deploy, Docs)

## Quick start (server)
1. Copy `.env.example` → `.env` and set:
   - `OPENAI_API_KEY=...`
   - `TOOLGATEWAY_SECRET=<strong random token>`
2. Deploy a bundle:
   - Place bundles in: `/home/spartan/sera/sera-ai/incoming`
   - Run:
     ```bash
     sudo /home/spartan/sera/sera-ai/tools/deploy_bundle.sh
     ```
3. Open UI:
   - http://127.0.0.1:8080/
   - https://127.0.0.1:8443/ (internal tls)

## Ports (host network)
- voice-gateway: `3000`
- tool-gateway: `3100`
- agent-runner: `3200`
- UI (caddy): `8080` and `8443`

## UI/API security model
- Browser calls **voice-gateway only** via `/api/*`.
- voice-gateway injects `X-Tool-Token` when talking to tool-gateway.
- tool-gateway remains token-protected; tokens never appear in the browser.

See docs:
- `docs/SERA_SYSTEM_GUIDE.md`
- `docs/API_CONTRACT.md`
- `docs/SITEMAP.md`
- `docs/BUILD_GUIDE.md`
- `docs/LOG_BACKUP_RETENTION.md`
