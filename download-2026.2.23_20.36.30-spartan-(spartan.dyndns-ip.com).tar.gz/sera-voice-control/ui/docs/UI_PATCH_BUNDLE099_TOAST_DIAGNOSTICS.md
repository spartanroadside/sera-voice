# BUNDLE099 – Toast notifications for API failures (links to Diagnostics)

Adds:
- A toast container to UI (fixed bottom-right)
- A small JS toast helper
- A hook that watches diagnostics error log (SERA_DIAG) and shows a toast on new failures
- Toast includes a one-click action to open the Diagnostics page

Files changed:
- ui/index.html
- ui/main.css
- ui/app.js
