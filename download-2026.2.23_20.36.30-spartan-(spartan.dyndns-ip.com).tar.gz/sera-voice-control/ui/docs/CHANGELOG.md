# Changelog

## RUN11 — 2026-02-05
- UI: external JS, fixed syntax error, buttons wired via /api/*
- Gateway: added /api/* aliases + status endpoint
- UI: footer tracking (RUN + service health)
- Docs: system docs + docs viewer
- Tools: rotation script (dry-run default)

## RUN10 — 2026-02-04
- Bundle deploy framework + token-protected tool-gateway endpoints
