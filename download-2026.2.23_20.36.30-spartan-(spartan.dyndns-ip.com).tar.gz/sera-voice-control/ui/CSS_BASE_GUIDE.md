# SERA UI Schema – Final Unified Workbench

## Core Concepts

### Workbench
Resizable layout using CSS variables:
- --p2-left
- --p2-right
- --p2-chat-h

Controlled by workspace.js.

### Splitters
- .seraP2VSplit
- .seraP2HSplit

### Panels
Canonical panel visual:
- .seraP2Card
- .seraP2Panel
- .p2panel (legacy alias)
- .pbPanel (legacy alias)

### Floating Tool Window
- .seraP2Float
- .seraP2FloatBar
- .seraP2FloatBody

Used for AI console undock.

### Modals (Blocking)
- .modalOverlay
- .modalWin
- .modalHdr
- .modalBody
- .modalFtr

Use for confirmations, settings dialogs.

## Migration Notes

- Retire .p2grid.
- Mount Phase2 workspace inside #page-project-workspace.
- Keep legacy panel classes for backward compatibility.
- Future installer can merge p2_workbench.css into a unified design system.
