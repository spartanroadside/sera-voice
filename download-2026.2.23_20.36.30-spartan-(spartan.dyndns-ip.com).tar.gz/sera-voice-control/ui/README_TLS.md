If `ui/caddy-root.crt` exists, it is downloadable at:
- /caddy-root.crt

Generate it on the server:
  ./tools/tls/export_caddy_root.sh
