/* SERA UI - System Status Checklist (persistent)
 * - Reads/writes to voice-gateway:
 *   GET  /api/system/checklist
 *   GET  /api/system/checklist/template
 *   PUT  /api/system/checklist/item/:id
 */

(function(){
  const STATUS = [
    { value: 'unknown', label: 'Unknown' },
    { value: 'working', label: 'Working' },
    { value: 'broken',  label: 'Broken' },
  ];

  // Optional friendly labels/descriptions (fallback is the id)
  const META = {
    'core.docker.running':                { group: 'Core', label: 'Docker running' },
    'core.compose.available':             { group: 'Core', label: 'docker compose available' },
    'core.paths.root_exists':             { group: 'Core', label: 'Root path exists' },
    'core.paths.incoming_exists':         { group: 'Core', label: 'Incoming path exists' },

    'installer.sha_filename_agnostic':    { group: 'Installer', label: 'SHA filename agnostic' },
    'installer.force_recreate_on_change': { group: 'Installer', label: 'Force recreate on change' },
    'installer.modes.update':             { group: 'Installer', label: 'Update mode works' },
    'installer.modes.fresh':              { group: 'Installer', label: 'Fresh mode works' },
    'installer.modes.repair':             { group: 'Installer', label: 'Repair mode works' },
    'installer.modes.rollback':           { group: 'Installer', label: 'Rollback mode works' },

    'svc.voice_ui.running':               { group: 'Services', label: 'voice-ui running' },
    'svc.voice_gateway.running':          { group: 'Services', label: 'voice-gateway running' },
    'svc.tool_gateway.running':           { group: 'Services', label: 'tool-gateway running' },
    'svc.agent_runner.running':           { group: 'Services', label: 'agent-runner running' },
    'svc.home_assistant.running':         { group: 'Services', label: 'home-assistant running' },
    'svc.qdrant.running':                 { group: 'Services', label: 'qdrant running' },

    'net.port.8080.listening':            { group: 'Networking', label: 'Port 8080 listening' },
    'net.port.8443.listening':            { group: 'Networking', label: 'Port 8443 listening' },
    'net.port.6333.listening':            { group: 'Networking', label: 'Port 6333 listening' },

    'route.http.ping':                    { group: 'Routes', label: 'HTTP ping /__ping' },
    'route.https.ping':                   { group: 'Routes', label: 'HTTPS ping /__ping' },
    'route.ui.index':                     { group: 'Routes', label: 'UI index loads' },
    'route.api_proxy':                    { group: 'Routes', label: 'API proxy works' },
    'route.sysdiag_proxy':                { group: 'Routes', label: 'Sysdiag proxy works' },
    'route.agent_proxy':                  { group: 'Routes', label: 'Agent proxy works' },

    'ha.configured':                      { group: 'Home Assistant', label: 'Configured' },
    'ha.reachable':                       { group: 'Home Assistant', label: 'Reachable' },
    'ha.webhook_configured':              { group: 'Home Assistant', label: 'Webhook configured' },

    'ui.page.home.loads':                 { group: 'UI', label: 'Home page loads' },
    'ui.page.system.loads':               { group: 'UI', label: 'System page loads' },
    'ui.assets.load_ok':                  { group: 'UI', label: 'Assets load OK' },
    'ui.router.navigation_ok':            { group: 'UI', label: 'Navigation works' },
    'ui.voice.mic_toggle':                { group: 'UI Voice', label: 'Mic toggle' },
    'ui.voice.capture_audio':             { group: 'UI Voice', label: 'Capture audio' },
    'ui.voice.send_request':              { group: 'UI Voice', label: 'Send request' },
    'ui.voice.playback_audio':            { group: 'UI Voice', label: 'Playback audio' },
    'ui.agent.prompt_submit':             { group: 'UI Agent', label: 'Prompt submit' },
    'ui.agent.stream_response':           { group: 'UI Agent', label: 'Stream response' },
    'ui.sysdiag.view':                    { group: 'UI Sysdiag', label: 'Sysdiag view' },
    'ui.sysdiag.run_test':                { group: 'UI Sysdiag', label: 'Run sysdiag test' },
  };

  function $(id){ return document.getElementById(id); }

  function toast(msg){
    const t = $('toast');
    if(!t) return;
    t.textContent = msg;
    t.style.opacity = '1';
    clearTimeout(toast._t);
    toast._t = setTimeout(()=>{ t.style.opacity='0'; }, 1200);
  }

  async function apiGet(path){
    const r = await fetch(path, { cache: 'no-store' });
    if(!r.ok) throw new Error(`${r.status} ${await r.text()}`);
    return await r.json();
  }

  async function apiPut(path, body){
    const r = await fetch(path, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    const ct = r.headers.get('content-type') || '';
    const out = ct.includes('application/json') ? await r.json() : await r.text();
    if(!r.ok) throw new Error(typeof out === 'string' ? out : (out.error || JSON.stringify(out)));
    return out;
  }

  async function apiPost(url, body){
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : null
    });
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  }

  function groupFor(id){
    return META[id]?.group || (id.split('.')[0] || 'Other');
  }

  function labelFor(id){
    return META[id]?.label || id;
  }

  function sortedIds(items){
    const ids = Object.keys(items || {});
    ids.sort((a,b)=>{
      const ga = groupFor(a);
      const gb = groupFor(b);
      if(ga < gb) return -1;
      if(ga > gb) return 1;
      return a.localeCompare(b);
    });
    return ids;
  }

  function counts(items){
    const c = { working:0, broken:0, unknown:0 };
    for(const v of Object.values(items || {})){
      if(v && v.status && c.hasOwnProperty(v.status)) c[v.status]++;
    }
    return c;
  }

  function toNotesMarkdown(data){
    const now = new Date().toISOString();
    const items = data.items || {};
    const ids = sortedIds(items);
    let out = `# SERA System Status Notes\n\nGenerated: ${now}\n\n`;
    let curGroup = null;
    for(const id of ids){
      const g = groupFor(id);
      if(g !== curGroup){
        curGroup = g;
        out += `## ${g}\n\n`;
      }
      const it = items[id] || {};
      const st = (it.status || 'unknown');
      out += `### ${labelFor(id)}\n- ID: \`${id}\`\n- Status: **${st}**\n`;
      if(it.updated_at) out += `- Updated: ${it.updated_at}\n`;
      if(it.note) out += `- Notes: ${String(it.note).trim()}\n`;
      out += `\n`;
    }
    return out;
  }

  function download(name, text, mime){
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: mime || 'text/plain' }));
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  function debounce(fn, ms){
    // Prefer shared control library if available
    if(window.SeraUI && typeof window.SeraUI.debounce === 'function'){
      return window.SeraUI.debounce(fn, ms);
    }
    let t = null;
    return function(...args){
      clearTimeout(t);
      t = setTimeout(()=>fn.apply(this, args), ms);
    };
  }

  async function render(){
    const tbl = $('chkTable');
    if(!tbl) return;

    tbl.innerHTML = '<tr><td class="muted" style="padding:12px">Loading checklist…</td></tr>';

    let data;
    let fmItems = {};
    try{
      data = await apiGet('/api/system/checklist');
      // optional function map (adds Run Test buttons)
      try{
        const fm = await apiGet('/api/function-map');
        fmItems = (fm && fm.items) ? fm.items : {};
      }catch(e){
        fmItems = {};
      }
    }catch(e){
      tbl.innerHTML = `<tr><td style="padding:12px">Failed to load checklist: ${String(e)}</td></tr>`;
      return;
    }

    const items = data.items || {};
    const ids = sortedIds(items);

    const c = counts(items);
    const last = $('chkLastSaved');
    if(last){
      const ts = data.meta?.updated_at;
      last.textContent = ts ? `Last saved: ${ts}` : 'Not saved yet';
    }

    tbl.innerHTML = '';
    const thead = document.createElement('thead');
    thead.innerHTML = '<tr><th style="width:160px">Group</th><th>Item</th><th style="width:170px">Status</th><th>Notes</th><th style="width:170px">Updated</th></tr>';
    tbl.appendChild(thead);

    const tbody = document.createElement('tbody');

    let lastGroup = null;
    let groupRowspanCount = 0;
    let groupFirstRow = null;

    // Pre-compute group sizes
    const groupSizes = {};
    for(const id of ids){
      const g = groupFor(id);
      groupSizes[g] = (groupSizes[g]||0) + 1;
    }

    const saveItem = async (id, status, note, savedBadgeHost) => {
      if(savedBadgeHost && window.SeraUI && typeof window.SeraUI.setSavedState === 'function'){
        window.SeraUI.setSavedState(savedBadgeHost, 'saving');
      }
      try{
        const r = await apiPut(`/api/system/checklist/item/${encodeURIComponent(id)}`, { status, note });
        const ts = r.meta?.updated_at;
        if(last) last.textContent = ts ? `Last saved: ${ts}` : 'Saved';
        if(savedBadgeHost && window.SeraUI && typeof window.SeraUI.setSavedState === 'function'){
          window.SeraUI.setSavedState(savedBadgeHost, 'saved');
        }
      }catch(e){
        toast(`Save failed: ${String(e)}`);
        if(savedBadgeHost && window.SeraUI && typeof window.SeraUI.setSavedState === 'function'){
          window.SeraUI.setSavedState(savedBadgeHost, 'error');
        }
      }
    };

    const debouncedSave = debounce(saveItem, 700);

    for(const id of ids){
      const g = groupFor(id);
      const it = items[id] || { status:'unknown', note:'' };

      const tr = document.createElement('tr');

      if(g !== lastGroup){
        lastGroup = g;
        groupRowspanCount = groupSizes[g] || 1;
        const tdGroup = document.createElement('td');
        tdGroup.rowSpan = groupRowspanCount;
        tdGroup.innerHTML = `<span class="badge">${g}</span>`;
        tr.appendChild(tdGroup);
        groupFirstRow = tr;
      }

      const tdItem = document.createElement('td');
      tdItem.textContent = labelFor(id);

      const tdStatus = document.createElement('td');
      const sel = (window.SeraUI && window.SeraUI.createSelect)
        ? window.SeraUI.createSelect(STATUS, it.status)
        : document.createElement('select');
      sel.setAttribute('data-id', id);
      if(!sel.options || sel.options.length === 0){
        for(const s of STATUS){
          const opt = document.createElement('option');
          opt.value = s.value;
          opt.textContent = s.label;
          if(s.value === it.status) opt.selected = true;
          sel.appendChild(opt);
        }
      }
      tdStatus.appendChild(sel);

      const tdNotes = document.createElement('td');
      const ta = (window.SeraUI && window.SeraUI.createTextarea)
        ? window.SeraUI.createTextarea(it.note || '', 2)
        : document.createElement('textarea');
      ta.setAttribute('data-id', id);
      if(!('rows' in ta)) ta.rows = 2;
      if(!ta.style.width) ta.style.width = '100%';
      if(!ta.value) ta.value = it.note || '';
      tdNotes.appendChild(ta);

      const tdUpdated = document.createElement('td');
      tdUpdated.className = 'muted';
      // Timestamp + inline saved indicator
      const tsSpan = document.createElement('span');
      tsSpan.textContent = it.updated_at || '';
      tdUpdated.appendChild(tsSpan);
      const badgeHost = document.createElement('span');
      tdUpdated.appendChild(badgeHost);

      // Optional per-item probe button (if mapped)
      const fmEntry = fmItems[id];
      if(fmEntry && fmEntry.probe){
        const btn = document.createElement('button');
        btn.textContent = 'Run Test';
        btn.className = 'btn btn-sm';
        btn.style.marginLeft = '8px';
        btn.onclick = async () => {
          btn.disabled = true;
          btn.textContent = 'Testing...';
          try{
            const r = await apiPost(`/api/function-map/probe/${encodeURIComponent(id)}`, {});
            const ok = !!r.pass;
            toast(`${labelFor(id)}: ${ok ? 'PASS' : 'FAIL'} (${r.latency_ms}ms)`);
            // Optionally set status based on probe result (only if unknown)
            if(sel.value === 'unknown'){
              sel.value = ok ? 'working' : 'broken';
              saveItem(id, sel.value, ta.value || '', badgeHost);
            }
          }catch(e){
            toast(`Probe failed: ${String(e)}`);
          }finally{
            btn.disabled = false;
            btn.textContent = 'Run Test';
          }
        };
        tdUpdated.appendChild(btn);
      }

      tr.appendChild(tdItem);
      tr.appendChild(tdStatus);
      tr.appendChild(tdNotes);
      tr.appendChild(tdUpdated);
      tbody.appendChild(tr);

      sel.addEventListener('change', () => {
        const status = sel.value;
        const note = ta.value || '';
        tsSpan.textContent = new Date().toISOString();
        saveItem(id, status, note, badgeHost);
      });

      ta.addEventListener('input', () => {
        const status = sel.value;
        const note = ta.value || '';
        tsSpan.textContent = new Date().toISOString();
        debouncedSave(id, status, note, badgeHost);
      });
    }

    tbl.appendChild(tbody);

    // Wire buttons
    const btnReset = $('chkReset');
    const btnRunAll = $('chkRunAll');
    const btnJson = $('chkDownloadJson');
    const btnExportSettings = $('chkExportSettings');
    const btnExportSysdiag = $('chkExportSysdiag');
    const btnNotes = $('chkDownloadNotes');
    const btnImportChecklist = $('chkImportChecklist');
    const btnImportSettings = $('chkImportSettings');
    const fileImportChecklist = $('fileImportChecklist');
    const fileImportSettings = $('fileImportSettings');
    const btnLegacy = $('chkToggleLegacy');

    if(btnJson){
      btnJson.onclick = async () => {
        try{
          const cur = await apiGet('/api/system/checklist');
          download('system_checklist.json', JSON.stringify(cur, null, 2), 'application/json');
        }catch(e){
          toast(`Export failed: ${String(e)}`);
        }
      };
    }

    // Export settings/sysdiag using dedicated backend endpoints
    async function exportFrom(url, filename){
      try{
        const r = await fetch(url, { cache: 'no-store' });
        if(!r.ok) throw new Error(`HTTP ${r.status}`);
        const text = await r.text();
        download(filename, text, 'application/json');
      }catch(e){
        toast(`Export failed: ${String(e)}`);
      }
    }

    if(btnExportSettings){
      btnExportSettings.onclick = () => exportFrom('/api/export/settings', 'app_settings.json');
    }

    if(btnExportSysdiag){
      btnExportSysdiag.onclick = () => exportFrom('/api/export/sysdiag_last', 'sysdiag_last.json');
    }

    // Import helpers
    async function importJsonFile(file, endpoint){
      const text = await file.text();
      const obj = JSON.parse(text);
      const r = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(obj)
      });
      const out = await r.text();
      if(!r.ok) throw new Error(out || `HTTP ${r.status}`);
      return out;
    }

    if(btnImportChecklist && fileImportChecklist){
      btnImportChecklist.onclick = () => fileImportChecklist.click();
      fileImportChecklist.onchange = async () => {
        const f = fileImportChecklist.files && fileImportChecklist.files[0];
        fileImportChecklist.value = '';
        if(!f) return;
        if(!confirm('Import checklist JSON? This will merge into the current checklist state.')) return;
        try{
          await importJsonFile(f, '/api/import/system_checklist');
          toast('Checklist imported');
          render();
        }catch(e){
          toast(`Import failed: ${String(e)}`);
        }
      };
    }

    if(btnImportSettings && fileImportSettings){
      btnImportSettings.onclick = () => fileImportSettings.click();
      fileImportSettings.onchange = async () => {
        const f = fileImportSettings.files && fileImportSettings.files[0];
        fileImportSettings.value = '';
        if(!f) return;
        if(!confirm('Import settings JSON? This will overwrite current settings (with default merge).')) return;
        try{
          await importJsonFile(f, '/api/import/settings');
          toast('Settings imported');
        }catch(e){
          toast(`Import failed: ${String(e)}`);
        }
      };
    }

    if(btnRunAll){
      btnRunAll.onclick = async () => {
        btnRunAll.disabled = true;
        const prev = btnRunAll.textContent;
        btnRunAll.textContent = 'Running...';
        try{
          // Run all mapped tests (backend uses function-map)
          const r = await apiPost('/api/sysdiag/run', null);
          const s = r.summary || {};
          toast(`Sysdiag: ${s.pass || 0}/${s.total || 0} pass`);
        }catch(e){
          toast(`Sysdiag failed: ${String(e)}`);
        }finally{
          btnRunAll.disabled = false;
          btnRunAll.textContent = prev;
        }
      };
    }

    async function renderLegacy(){
      const wrap = $('legacyWrap');
      const tbl = $('legacyTable');
      if(!wrap || !tbl) return;
      tbl.innerHTML = '<tr><td class="muted" style="padding:12px">Loading legacy checklist…</td></tr>';
      try{
        const items = await apiGet('/api/system/checklist/legacy');
        const head = document.createElement('thead');
        head.innerHTML = '<tr><th style="width:140px">Group</th><th>Item</th><th style="width:100px">Status</th><th>Notes</th></tr>';
        const body = document.createElement('tbody');
        for(const it of (items || [])){
          const tr = document.createElement('tr');
          const tdG = document.createElement('td'); tdG.textContent = it.group || '';
          const tdL = document.createElement('td'); tdL.textContent = it.label || it.key || '';
          const tdS = document.createElement('td');
          tdS.textContent = (it.status || '').toUpperCase();
          tdS.className = 'muted';
          const tdN = document.createElement('td'); tdN.textContent = (it.notes || '').toString();
          tr.appendChild(tdG); tr.appendChild(tdL); tr.appendChild(tdS); tr.appendChild(tdN);
          body.appendChild(tr);
        }
        tbl.innerHTML = '';
        tbl.appendChild(head);
        tbl.appendChild(body);
      }catch(e){
        tbl.innerHTML = `<tr><td style="padding:12px">Failed to load legacy checklist: ${String(e)}</td></tr>`;
      }
    }

    if(btnLegacy){
      btnLegacy.onclick = async () => {
        const wrap = $('legacyWrap');
        if(!wrap) return;
        const nextShow = (wrap.style.display === 'none' || !wrap.style.display);
        wrap.style.display = nextShow ? 'block' : 'none';
        if(nextShow) await renderLegacy();
      };
    }

    if(btnNotes){
      btnNotes.onclick = async () => {
        try{
          const cur = await apiGet('/api/system/checklist');
          download('system_checklist_notes.md', toNotesMarkdown(cur), 'text/markdown');
        }catch(e){
          toast(`Export failed: ${String(e)}`);
        }
      };
    }

    if(btnReset){
      btnReset.onclick = async () => {
        if(!confirm('Reset all items to Unknown? This will overwrite notes and statuses.')) return;
        try{
          const tpl = await apiGet('/api/system/checklist/template');
          const ids2 = sortedIds(tpl.items || {});
          for(const id of ids2){
            await apiPut(`/api/system/checklist/item/${encodeURIComponent(id)}`, { status:'unknown', note:'' });
          }
          toast('Reset complete');
          render();
        }catch(e){
          toast(`Reset failed: ${String(e)}`);
        }
      };
    }

    // Show counts in the existing system page summary (optional)
    const footer = $('footerStatus');
    if(footer){
      // do not overwrite footer; just leave
    }

    // Expose counts in console for quick debugging
    window.__seraChecklistCounts = c;
  }

  window.addEventListener('DOMContentLoaded', render);
})();
