/* SERA UI Controls - shared primitives (v1)
 * Keep this file framework-free and dependency-free.
 */

(function(){
  function debounce(fn, ms){
    let t = null;
    return function(...args){
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), ms);
    };
  }

  function createSelect(options, value){
    const sel = document.createElement('select');
    for(const optDef of (options || [])){
      const opt = document.createElement('option');
      opt.value = optDef.value;
      opt.textContent = optDef.label;
      if(optDef.value === value) opt.selected = true;
      sel.appendChild(opt);
    }
    return sel;
  }

  function createTextarea(value, rows){
    const ta = document.createElement('textarea');
    ta.rows = rows || 2;
    ta.style.width = '100%';
    ta.value = value || '';
    return ta;
  }

  function ensureSavedBadge(container){
    let badge = container.querySelector('.saved-badge');
    if(!badge){
      badge = document.createElement('span');
      badge.className = 'saved-badge muted';
      badge.textContent = '';
      container.appendChild(badge);
    }
    return badge;
  }

  function setSavedState(container, state){
    // state: idle | saving | saved | error
    const badge = ensureSavedBadge(container);
    if(state === 'saving'){
      badge.textContent = 'Saving…';
      badge.classList.remove('ok','err');
    }else if(state === 'saved'){
      badge.textContent = 'Saved ✓';
      badge.classList.add('ok');
      badge.classList.remove('err');
      clearTimeout(setSavedState._t);
      setSavedState._t = setTimeout(()=>{ badge.textContent=''; }, 1200);
    }else if(state === 'error'){
      badge.textContent = 'Save failed';
      badge.classList.add('err');
      badge.classList.remove('ok');
    }else{
      badge.textContent = '';
      badge.classList.remove('ok','err');
    }
  }

  window.SeraUI = {
    debounce,
    createSelect,
    createTextarea,
    setSavedState,
  };
})();
