// Settings page controller: profiles (LAN/WAN/Local) + base_url hints.
(() => {
  // ---- per-script version marker (DEV) ----
  const LS_BASE_URL = "SERA_BASE_URL";
  const SCRIPT_VERSION = "ui/settings.js@BUNDLE084.1";
  window.__SERA_SCRIPTS = window.__SERA_SCRIPTS || {};
  window.__SERA_SCRIPTS["settings.js"] = SCRIPT_VERSION;

  const $ = (id) => document.getElementById(id);

  function ensureSettingsUI(){
    const sec = document.getElementById("page-settings");
    if(!sec) return;

    // If the expected controls exist, do nothing.
    if(document.getElementById("profileSelect") && document.getElementById("baseUrlInput")) return;

    // Find a sensible insertion point: after the page <h2>.
    let anchor = sec.querySelector("h2");
    const container = document.createElement("div");
    container.innerHTML = `
      <div class="card" style="margin-top:12px">
        <div class="cardTitle">Profiles (LAN / WAN / Local)</div>
        <div class="small" style="opacity:.85;margin-top:6px">Switch API profile and base URL hints.</div>
        <div class="row" style="gap:10px;flex-wrap:wrap;margin-top:10px">
          <select id="profileSelect" class="input" style="min-width:220px"></select>
          <button id="btnProfilesReload" class="ghost">Reload</button>
          <button id="btnProfilesSave" class="primary">Set Active</button>
        </div>
        <div id="profileDetails" class="small" style="opacity:.85;margin-top:10px"></div>
      </div>

      <div class="card" style="margin-top:14px">
        <div class="cardTitle">Base URL</div>
        <div class="small" style="opacity:.85;margin-top:6px">Optional override for API routing (leave blank for default).</div>
        <div class="row" style="gap:10px;flex-wrap:wrap;margin-top:10px">
          <input id="baseUrlInput" class="input" placeholder="https://sera.lan:8443" style="min-width:320px;flex:1" />
          <button id="btnBaseUrlSave" class="primary">Save</button>
          <button id="btnBaseUrlClear" class="ghost">Clear</button>
        </div>
        <div class="small" style="opacity:.85;margin-top:10px">
          Current: <span id="baseUrlCurrent" style="font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace"></span>
        </div>
      </div>
    `.trim();

    if(anchor && anchor.parentElement){
      anchor.insertAdjacentElement("afterend", container);
    }else{
      sec.appendChild(container);
    }
  }

  async function fetchJson(url, opts){
    const r = await fetch(url, Object.assign({ cache:"no-store" }, opts||{}));
    if(!r.ok) throw new Error(`${url} -> ${r.status}`);
    return await r.json();
  }

  function setStatus(msg){
    const el = $("settingsStatus");
    if(el) el.textContent = msg;
  }

  async function loadProfiles(){
    const j = await fetchJson("/api/profiles");
    return j;
  }

  async function saveActive(active){
    const j = await fetchJson("/api/profiles/active", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ active })
    });
    return j;
  }

  function fillSelect(sel, profiles, active){
    sel.innerHTML = "";
    for(const [key, p] of Object.entries(profiles||{})){
      const opt = document.createElement("option");
      opt.value = key;
      opt.textContent = `${p.label || key} (${key})`;
      if(key === active) opt.selected = true;
      sel.appendChild(opt);
    }
  }

  function renderProfileDetails(p){
    const el = $("profileDetails");
    if(!el) return;
    if(!p){
      el.textContent = "No profile selected.";
      return;
    }
    const base = (p.base_url || "").trim();
    el.textContent = `Base URL: ${base || "(auto)"}\nNotes: ${p.notes || ""}`;
  }

  async function init(){
    const sel = $("profileSelect");
    if(!sel) return; // page not present
    try{
      setStatus("Loading…");
      const j = await loadProfiles();
      fillSelect(sel, j.profiles, j.active);
      renderProfileDetails(j.profiles?.[j.active] || null);
      setStatus("Ready");
    }catch(e){
      console.warn("settings init failed", e);
      setStatus("Failed to load profiles");
    }

    sel.addEventListener("change", async () => {
      try{
        setStatus("Saving…");
        const active = sel.value;
        const j = await saveActive(active);
        renderProfileDetails(j.profile || null);
        setStatus("Saved ✓");
      }catch(e){
        console.warn("save active failed", e);
        setStatus("Save failed");
      }
    });

    const btnReload = $("btnProfilesReload");
    if(btnReload){
      btnReload.addEventListener("click", init);
    }
  }

  window.addEventListener("DOMContentLoaded", init);
})();


// Paths & URLs settings (page-settings)
(() => {
  const $ = (id) => document.getElementById(id);

  async function fetchJson(url, opts){
    const r = await fetch(url, Object.assign({ cache:"no-store" }, opts||{}));
    const ct = r.headers.get("content-type")||"";
    const isJson = ct.includes("application/json");
    const body = isJson ? await r.json() : await r.text();
    if(!r.ok){
      const msg = (isJson && body && (body.detail||body.error)) ? (body.detail||body.error) : `${url} -> ${r.status}`;
      throw new Error(msg);
    }
    return body;
  }

  function setPill(text){
    const el = $("pathsStatus");
    if(el) el.textContent = text;
  }

  function loadToForm(obj){
    $("setWanDomain").value = obj.wan_domain || "";
    $("setBaseUrl").value = obj.base_url || "";
    $("setWorkspace").value = obj.workspace_mount || "";
    $("setIncoming").value = obj.incoming_dir || "";
    $("setToolUrl").value = obj.tool_url || "";
    $("setAgentUrl").value = obj.agent_url || "";
    $("setRaw").value = JSON.stringify(obj, null, 2);
  }

  function readFromForm(){
    let raw = {};
    try{ raw = JSON.parse($("setRaw").value || "{}"); }catch{ raw = {}; }
    // explicit fields override raw keys
    raw.wan_domain = $("setWanDomain").value.trim();
    raw.base_url = $("setBaseUrl").value.trim();
    raw.workspace_mount = $("setWorkspace").value.trim();
    raw.incoming_dir = $("setIncoming").value.trim();
    raw.tool_url = $("setToolUrl").value.trim();
    raw.agent_url = $("setAgentUrl").value.trim();
    return raw;
  }

  async function load(){
    setPill("Loading…");
    const obj = await fetchJson("/api/settings");
    loadToForm(obj || {});
    setPill("Ready");
  }

  async function save(){
    setPill("Saving…");
    const payload = readFromForm();
    await fetchJson("/api/settings", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(payload) });
    setPill("Saved ✓");
  }

  function init(){
    if(!$("pathsLoad")) return;
    $("pathsLoad").addEventListener("click", () => load().catch(e => { console.warn(e); setPill("Load failed"); }));
    $("pathsSave").addEventListener("click", () => save().catch(e => { console.warn(e); setPill("Save failed"); }));
    // auto-load once
    load().catch(e => { console.warn(e); setPill("Load failed"); });
  }

  window.addEventListener("DOMContentLoaded", init);
})();