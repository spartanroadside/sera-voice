// Voice client (runs inside the Voice page)
// Supports:
// - Browser STT via Web Speech API (SpeechRecognition)
// - Browser TTS via speechSynthesis
// - Sending recognized/typed text to /api/chat
// - Quick actions list (actions.json)
(() => {
  const outEl = document.getElementById("voiceOut");
  const btnStart = document.getElementById("btnStart");
  const btnPTT = document.getElementById("btnPTT");
  const pttRound = document.getElementById("pttRound");
  const btnStop = document.getElementById("btnStop");
  const btnStatus = document.getElementById("btnStatus");
  const btnSend = document.getElementById("btnSend");
  const promptEl = document.getElementById("voicePrompt");
  // Quick actions removed from Voice page (UI adjustment)
  const toolSearch = null;
  const toolList = null;

  // Not on the voice page.
  if (!outEl || !btnStart || !btnStop || !btnStatus || !btnSend || !promptEl) {
    console.warn("[voice_client] Voice UI missing required elements; voice client inactive.", {
      outEl: !!outEl, btnStart: !!btnStart, btnPTT: !!btnPTT, btnStop: !!btnStop, btnStatus: !!btnStatus, btnSend: !!btnSend, promptEl: !!promptEl
    });
    return;
  }

  const log = (m) => {
    const ts = new Date().toISOString().replace('T', ' ').replace('Z', '');
    outEl.textContent += `[${ts}] ${m}\n`;
    outEl.scrollTop = outEl.scrollHeight;
  };

  // --- STT (Web Speech) ---
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null;
  let recognizing = false;

  const setButtons = () => {
    btnStart.disabled = recognizing || !SR;
    btnStop.disabled = !recognizing;
  };

  function initRec() {
    if (!SR) return null;
    const r = new SR();
    r.continuous = false;
    r.interimResults = true;
    r.lang = navigator.language || 'en-US';

    r.onstart = () => { recognizing = true; setButtons(); log("mic: listening"); };
    r.onend = () => {
      recognizing = false;
      setButtons();
      log("mic: stopped");
      const t = String(promptEl.value || "").trim();
      if(t) autoSend(t, "end");
    };
    r.onerror = (e) => { recognizing = false; setButtons(); log(`mic error: ${e.error || e.message || e}`); };
    r.onresult = (ev) => {
      try {
        let finalText = "";
        let interim = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const txt = ev.results[i][0]?.transcript || "";
          if (ev.results[i].isFinal) finalText += txt;
          else interim += txt;
        }
        const merged = (finalText || interim || "").trim();
        if (merged) {
          promptEl.value = merged;
          if (finalText.trim()) {
            const ft = finalText.trim();
            log(`heard: ${ft}`);
            autoSend(ft, "final");
          }
        }
      } catch (e) {
        log("onresult failed: " + e);
      }
    };
    return r;
  }

  rec = initRec();
  setButtons();
  if (!SR) {
    log("Web Speech STT not available in this browser. Use Chrome/Edge desktop.");
  }

  btnStart.addEventListener("click", async () => {
    try {
      if (!SR) return;
      if (!rec) rec = initRec();
      // User gesture required by browsers.
      rec.start();
    } catch (e) {
      recognizing = false; setButtons();
      log("start failed: " + (e?.message || e));
    }
  });

  // Push-to-talk (hold) button
  function pttStart(){
    try{
      if (!SR) return;
      if (!rec) rec = initRec();
      if (recognizing) return;
      rec.start();
    }catch(e){
      recognizing = false; setButtons();
      log("ptt start failed: " + (e?.message || e));
    }
  }

  function pttStop(){
    try{
      if (rec && recognizing) rec.stop();
    }catch(e){
      log("ptt stop failed: " + (e?.message || e));
    }
  }

  // Legacy rectangular PTT
  if (btnPTT) {
    btnPTT.addEventListener('pointerdown', (e)=>{ e.preventDefault(); pttStart(); });
    btnPTT.addEventListener('pointerup',   (e)=>{ e.preventDefault(); pttStop(); });
    btnPTT.addEventListener('pointercancel', ()=>pttStop());
  }

  // Round PTT
  if (pttRound) {
    pttRound.addEventListener('pointerdown', (e)=>{ e.preventDefault(); pttRound.classList.add('is-armed'); pttStart(); });
    pttRound.addEventListener('pointerup',   (e)=>{ e.preventDefault(); pttRound.classList.remove('is-armed'); pttStop(); });
    pttRound.addEventListener('pointercancel', ()=>{ pttRound.classList.remove('is-armed'); pttStop(); });
  }

  btnStop.addEventListener("click", () => {
    try {
      if (rec && recognizing) rec.stop();
    } catch (e) {
      log("stop failed: " + (e?.message || e));
    }
  });

  btnStatus.addEventListener("click", async () => {
    try {
      const secure = window.isSecureContext;
      const hasMedia = !!navigator.mediaDevices;
      let micPerm = "(unknown)";
      try {
        micPerm = await navigator.permissions.query({ name: "microphone" }).then(r => r.state);
      } catch (_) {}
      log(`status: secureContext=${secure} speechRec=${!!SR} mediaDevices=${hasMedia} micPerm=${micPerm}`);
    } catch (e) {
      log("status failed: " + (e?.message || e));
    }
  });

  // --- Chat send + TTS ---
  async function sendToChat(text) {
    const payload = {
      user: String(text || "").trim(),
      project: "default",
      thread_id: "(auto)"
    };
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(j?.error || `HTTP ${res.status}`);
    return j;
  }


  // --- Auto-send logic ---
  let lastAutoSent = "";
  let autoSendInFlight = false;

  async function autoSend(text, source){
    const t = String(text || "").trim();
    if(!t) return;
    if(t === lastAutoSent) return;
    if(autoSendInFlight) return;

    autoSendInFlight = true;
    lastAutoSent = t;
    try{
      btnSend.disabled = true;
      log(`auto-send (${source || "stt"}): ${t}`);
      const j = await sendToChat(t);
      const reply = j?.reply || j?.raw?.reply || j?.raw?.message || JSON.stringify(j);
      log(`reply: ${reply}`);
      speak(reply);
      promptEl.value = "";
    }catch(e){
      log("auto-send failed: " + (e?.message || e));
    }finally{
      btnSend.disabled = false;
      autoSendInFlight = false;
    }
  }

  function speak(text) {
    try {
      if (!window.speechSynthesis) return;
      const u = new SpeechSynthesisUtterance(String(text || ""));
      u.lang = navigator.language || 'en-US';
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    } catch (e) {
      log("tts failed: " + (e?.message || e));
    }
  }

  btnSend.addEventListener("click", async () => {
    const text = String(promptEl.value || "").trim();
    if (!text) return;
    try {
      btnSend.disabled = true;
      log(`send: ${text}`);
      const j = await sendToChat(text);
      const reply = j?.reply || j?.raw?.reply || j?.raw?.message || JSON.stringify(j);
      log(`reply: ${reply}`);
      speak(reply);
    } catch (e) {
      log("send failed: " + (e?.message || e));
    } finally {
      btnSend.disabled = false;
    }
  });

  (async () => {
    log("voice ui ready (browser STT/TTS mode)");
  })();
})();

