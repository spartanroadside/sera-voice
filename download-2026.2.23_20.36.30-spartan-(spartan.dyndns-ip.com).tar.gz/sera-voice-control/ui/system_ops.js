(function(){
  const $ = (id)=>document.getElementById(id);

  async function fetchJson(url, opts){
    const r = await fetch(url, Object.assign({cache:'no-store'}, opts||{}));
    const ct = r.headers.get('content-type')||'';
    let body;
    if(ct.includes('application/json')) body = await r.json();
    else body = await r.text();
    if(!r.ok) throw new Error(`${url} -> ${r.status} ${String(body).slice(0,200)}`);
    return body;
  }

  // -------- Service control --------
  const SERVICES = [
    { id: "voice-ui", label: "voice-ui (caddy)" },
    { id: "voice-gateway", label: "voice-gateway" },
    { id: "tool-gateway", label: "tool-gateway" },
    { id: "sera-logic", label: "sera-logic" },
    { id: "agent-runner", label: "agent-runner" }
  ];

  function setSvcStatus(t){ const el=$('svcStatus'); if(el) el.textContent=t||''; }
  function setSvcOut(t){ const el=$('svcOut'); if(el) el.textContent=t||''; }

  // Critical: never allow status text to become part of the service id
  function cleanServiceName(name){
    const s = String(name||'').trim();
    // if something like "tool-gateway || inactive" ever appears, keep only left side
    return s.split('||')[0].trim();
  }

  function renderSvcList(statusMap){
    const wrap = $('svcList');
    if(!wrap) return;
    wrap.innerHTML = '';

    const saved = (()=> {
      try{ return localStorage.getItem('sera_sys_selected_service') || SERVICES[2].id; }
      catch(e){ return SERVICES[2].id; }
    })();

    SERVICES.forEach((s)=>{
      const st = (statusMap && statusMap[s.id]) ? String(statusMap[s.id]) : '—';

      const row = document.createElement('div');
      row.className = 'sideItem';
      row.style.display='flex';
      row.style.gap='10px';
      row.style.alignItems='center';

      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = 'sera_service_pick';
      radio.value = s.id;                 // <-- ALWAYS the pure id
      radio.checked = (s.id === saved);
      radio.addEventListener('change', ()=>{
        try{ localStorage.setItem('sera_sys_selected_service', s.id); }catch(e){}
      });

      const label = document.createElement('div');
      label.style.flex='1';
      label.innerHTML = `<div style="font-weight:650">${escapeHtml(s.label)}</div>
                         <div class="small" style="opacity:.8">${escapeHtml(st || '—')}</div>`;

      const btn = document.createElement('button');
      btn.className = 'ghost smallBtn';
      btn.textContent = 'Restart';
      btn.title = `Restart ${s.id}`;
      btn.addEventListener('click', ()=>restartService(s.id)); // <-- ALWAYS the pure id

      row.appendChild(radio);
      row.appendChild(label);
      row.appendChild(btn);
      wrap.appendChild(row);
    });
  }

  function getSelectedService(){
    const el = document.querySelector('input[name="sera_service_pick"]:checked');
    return cleanServiceName((el && el.value) ? el.value : SERVICES[0].id);
  }

  function statusSummary(j){
    // tool-gateway output seems to include "active/inactive" lines; keep it human-friendly
    if(!j) return '—';
    if(typeof j === 'string') return j.slice(0,120);
    if(j.ok && typeof j.output === 'string'){
      // pull something useful from output
      const o = j.output;
      if(/\bactive\b/.test(o) && !/\binactive\b/.test(o)) return 'active';
      if(/\binactive\b/.test(o)) return 'inactive';
      if(/\bfailed\b/.test(o)) return 'failed';
      return o.trim().split('\n').slice(0,2).join(' / ').slice(0,120) || 'ok';
    }
    if(j.ok) return 'ok';
    if(j.error) return `error: ${j.error}`;
    return JSON.stringify(j).slice(0,120);
  }

  async function refreshServices(){
    if(!$('svcList')) return;
    try{
      setSvcStatus('Loading…');
      const map = {};

      for(const s of SERVICES){
        try{
          const j = await fetchJson('/api/status_service', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ name: cleanServiceName(s.id) })
          });
          map[s.id] = statusSummary(j);
        }catch(e){
          map[s.id] = 'Unavailable';
        }
      }

      renderSvcList(map);
      setSvcStatus('Ready');
    }catch(e){
      setSvcStatus('Failed');
      setSvcOut('Service status failed: ' + String(e));
    }
  }

  async function restartService(name){
    const svc = cleanServiceName(name);
    try{
      setSvcStatus('Restarting…');
      setSvcOut(`Restarting ${svc}...\n`);
      const j = await fetchJson('/api/restart_service', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ name: svc })
      });
      setSvcOut(`Restart requested for ${svc}\n\n` + pretty(j));
      setSvcStatus('Ready');
      setTimeout(refreshServices, 1200);
    }catch(e){
      setSvcStatus('Failed');
      setSvcOut('Restart failed: ' + String(e));
    }
  }

  async function restartSelected(){
    const svc = getSelectedService();
    return restartService(svc);
  }

  async function tailLogs(){
    const svc = getSelectedService();
    const nEl = $('svcLogLines');
    let n = 120;
    try{ n = Math.min(Math.max(parseInt((nEl && nEl.value) || '120', 10) || 120, 10), 2000); }catch{}
    try{
      setSvcStatus('Tailing…');
      const j = await fetchJson('/api/logs_tail', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ service: svc, n })
      });
      setSvcOut(pretty(j));
      setSvcStatus('Ready');
    }catch(e){
      setSvcStatus('Failed');
      setSvcOut('Tail logs failed: ' + String(e));
    }
  }

  // -------- Shell runner --------
  function setShStatus(t){ const el=$('shStatus'); if(el) el.textContent=t||''; }
  function setShOut(t){ const el=$('shOut'); if(el) el.textContent=t||''; }

  const BLOCK_PATTERNS = [
    /\brm\s+-rf\b/i,
    /\bmkfs\b/i,
    /\bdd\s+if=/i,
    /\bshutdown\b/i,
    /\breboot\b/i,
    /\bpoweroff\b/i,
    /\binit\s+0\b/i,
    /\b:\s*\(\)\s*\{\s*:\s*\|\s*:\s*;\s*\}\s*;\s*:\b/i,
    /\bchmod\s+777\b/i,
    /\bchown\s+-R\b/i
  ];

  function isSafeCommand(cmd){
    const c = String(cmd||'').trim();
    if(!c) return false;
    for(const re of BLOCK_PATTERNS){
      if(re.test(c)) return false;
    }
    return true;
  }

  async function runShell(){
    const cmdEl = $('shCmd');
    const safeEl = $('shSafe');
    const cmd = (cmdEl && cmdEl.value) ? cmdEl.value.trim() : '';
    if(!cmd){ setShOut(''); setShStatus('Idle'); return; }

    const safe = !!(safeEl && safeEl.checked);
    if(safe && !isSafeCommand(cmd)){
      setShStatus('Blocked');
      setShOut('SAFE MODE blocked this command. If you really need it, uncheck SAFE and try again.\n\nCommand:\n' + cmd);
      return;
    }

    try{
      setShStatus('Running…');
      setShOut('Running...\n\n' + cmd + '\n');
      const j = await fetchJson('/api/run', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ cmd, timeout: 300 })
      });
      setShOut(pretty(j));
      setShStatus('Done');
    }catch(e){
      setShStatus('Failed');
      setShOut('Run failed: ' + String(e));
    }
  }

  function initShell(){
    if(!$('shRun')) return;
    const safeEl = $('shSafe');
    if(safeEl){
      try{
        const saved = localStorage.getItem('sera_shell_safe');
        if(saved !== null) safeEl.checked = (saved === '1');
      }catch(e){}
      safeEl.addEventListener('change', ()=>{
        try{ localStorage.setItem('sera_shell_safe', safeEl.checked ? '1' : '0'); }catch(e){}
      });
    }
    $('shRun').addEventListener('click', runShell);
    const cmdEl = $('shCmd');
    if(cmdEl){
      cmdEl.addEventListener('keydown', (e)=>{
        if((e.ctrlKey || e.metaKey) && e.key === 'Enter'){
          e.preventDefault();
          runShell();
        }
      });
    }
  }

  // -------- Preview --------
  function initPreview(){
    const urlEl = $('pvUrl') || $('pvUrlProjects');
    const loadBtn = $('pvLoad') || $('pvLoadProjects');
    const frame = $('pvFrame') || $('pvFrameProjects');
    const open = $('pvOpen');
    if(!urlEl || !loadBtn || !frame || !open) return;

    function guessDefault(){
      try{
        const u = new URL(window.location.href);
        const port = u.port || (u.protocol==='https:' ? '443' : '80');
        if(port !== '8080'){ u.port = '8080'; }
        u.pathname = '/';
        u.search = '';
        u.hash = '';
        return u.toString();
      }catch(e){
        return 'http://sera.lan:8080/';
      }
    }

    try{
      const saved = localStorage.getItem('sera_preview_url');
      urlEl.value = saved || guessDefault();
    }catch(e){
      urlEl.value = guessDefault();
    }

    function load(){
      const v = String(urlEl.value||'').trim();
      if(!v) return;
      frame.src = v;
      open.href = v;
      try{ localStorage.setItem('sera_preview_url', v); }catch(e){}
    }

    loadBtn.addEventListener('click', load);
    urlEl.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){ e.preventDefault(); load(); }
    });

    setTimeout(load, 200);
  }

  // -------- utils --------
  function pretty(j){
    try{ return typeof j === 'string' ? j : JSON.stringify(j, null, 2); }
    catch(e){ return String(j); }
  }
  function escapeHtml(s){
    return String(s||'').replace(/[&<>"']/g, (c)=>({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[c]));
  }



// -------- Logs + Docs viewers (System page) --------
let logsTimer = null;

async function loadLogsOnce(){
  const out = $('sysLogsOut');
  if(!out) return;
  const status = $('sysLogsStatus'); if(status) status.textContent = 'Loading…';
  try{
    const lines = parseInt(String(($('sysLogLines2')||{}).value||'200'),10) || 200;
    const source = String(($('sysLogSource')||{}).value||'actions');
    let text = '';
    if(source === 'actions'){
      const j = await fetchJson('/api/logs/actions/tail?n=' + encodeURIComponent(lines));
      text = (j && (j.lines || j.text)) ? (j.lines || j.text) : JSON.stringify(j, null, 2);
    }else{
      const svc = String(($('sysLogService')||{}).value||'tool-gateway');
      const j = await fetchJson('/api/logs_tail', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ service: svc, n: lines })
      });
      text = (j && (j.lines || j.text || j.out)) ? (j.lines || j.text || j.out) : JSON.stringify(j, null, 2);
    }
    out.textContent = String(text||'');
    if(status) status.textContent = 'Ready';
  }catch(e){
    out.textContent = String(e && e.message ? e.message : e);
    if(status) status.textContent = 'Failed';
  }
}

function syncLogSourceUI(){
  const source = String(($('sysLogSource')||{}).value||'actions');
  const svcSel = $('sysLogService');
  if(!svcSel) return;
  if(source === 'service'){
    svcSel.style.display = '';
  }else{
    svcSel.style.display = 'none';
  }
}

function setLogsAuto(on){
  if(logsTimer) { clearInterval(logsTimer); logsTimer = null; }
  if(on){
    logsTimer = setInterval(loadLogsOnce, 2500);
  }
}

async function initDocs(){
  const sel = $('sysDocSelect');
  const out = $('sysDocOut');
  const reload = $('sysDocReload');
  const raw = $('sysDocOpenRaw');
  if(!sel || !out) return;

  async function listDocs(){
    // prefer index.json if present
    try{
      const idx = await fetchJson('/docs/index.json');
      const docs = (idx && idx.docs) ? idx.docs : (Array.isArray(idx) ? idx : []);
      sel.innerHTML = '';
      (docs||[]).forEach(d=>{
        const opt = document.createElement('option');
        opt.value = d.path || d;
        opt.textContent = d.title || d.path || d;
        sel.appendChild(opt);
      });
      if(sel.options.length === 0){
        // fallback: known docs
        ['README.md','SERA_SYSTEM_GUIDE.md','BUILD_GUIDE.md','API_CONTRACT.md','CHANGELOG.md'].forEach(f=>{
          const opt = document.createElement('option');
          opt.value = f;
          opt.textContent = f;
          sel.appendChild(opt);
        });
      }
    }catch(e){
      sel.innerHTML = '';
      ['README.md','SERA_SYSTEM_GUIDE.md','BUILD_GUIDE.md','API_CONTRACT.md','CHANGELOG.md'].forEach(f=>{
        const opt = document.createElement('option');
        opt.value = f;
        opt.textContent = f;
        sel.appendChild(opt);
      });
    }
  }

  async function loadDoc(){
    const v = String(sel.value||'').trim();
    if(!v) return;
    const url = '/docs/' + v.replace(/^\/+/, '');
    if(raw) raw.href = url;
    try{
      const r = await fetch(url, { cache:'no-store' });
      out.textContent = await r.text();
    }catch(e){
      out.textContent = String(e && e.message ? e.message : e);
    }
  }

  reload && reload.addEventListener('click', async ()=>{ await listDocs(); await loadDoc(); });
  sel.addEventListener('change', loadDoc);
  await listDocs();
  await loadDoc();
}

function initLogsDocs(){
  const out = $('sysLogsOut');
  if(!out) return;

  const svcSel = $('sysLogService');
  if(svcSel){
    svcSel.innerHTML = '';
    SERVICES.forEach(s=>{
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = s.label;
      svcSel.appendChild(opt);
    });
    try{
      const saved = localStorage.getItem('sera_sys_selected_service') || 'tool-gateway';
      svcSel.value = saved;
    }catch(e){}
  }

  const src = $('sysLogSource');
  if(src) src.addEventListener('change', ()=>{ syncLogSourceUI(); loadLogsOnce(); });

  const btn = $('sysLogsRefresh');
  if(btn) btn.addEventListener('click', loadLogsOnce);

  const auto = $('sysLogsAuto');
  if(auto) auto.addEventListener('change', ()=> setLogsAuto(auto.checked));

  syncLogSourceUI();
  loadLogsOnce();
  initDocs();
}

  function init(){
    if($('svcList')){
      const r=$('svcRefresh'); if(r) r.addEventListener('click', refreshServices);
      const rs=$('svcRestartSelected'); if(rs) rs.addEventListener('click', restartSelected);
      const t=$('svcTail'); if(t) t.addEventListener('click', tailLogs);
      refreshServices();
    }
    initShell();
    initPreview();
    initLogsDocs();
  }

  window.addEventListener('DOMContentLoaded', init);
})();