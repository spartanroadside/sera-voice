// Router alias patch: keep friendly names working (Dashboard/Programmer/etc).
// Load after dashboard.js.
(function(){
  const alias = {
    "dashboard":"projects",
    "programmer":"project-workspace",
    "threads":"chat",
    "diagnostics":"troubleshoot",
  };

  const orig = window.showPage;
  if(typeof orig === "function"){
    window.showPage = function(page){
      const p = (page||"").toLowerCase();
      const mapped = alias[p] || page;
      window.__currentPage = (mapped||"").toLowerCase();
      return orig.call(this, mapped);
    };
  }

  // Normalize hashes like #voice to #/voice
  function normalize(){
    let h = (location.hash||"");
    if(/^#(voice|chat|settings|deploy|admin|system|dashboard|programmer|diagnostics|troubleshoot|projects)/i.test(h) && !h.startsWith("#/")){
      history.replaceState(null,"", "#/"+h.slice(1));
    }
  }
  normalize();
  window.addEventListener("hashchange", normalize);
})();
