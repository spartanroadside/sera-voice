// Chat UI wiring (v1.131.1)
// Supports two modes:
//  1) Simple ChatGPT-style page (index.html: #chatTranscript/#chatInput)
//  2) Legacy threaded scaffold (if #threadList exists)

// -----------------------------
// Mode 1: Simple chat
// -----------------------------
function _ctx(){
  const c = (window.SERA_CTX || {});
  const project = (c.project || 'default');
  const thread = (c.thread_id || '');
  return { project, thread_id: thread };
}

function _chatKey(){
  const c = _ctx();
  return `sera_simple_chat_v1:${c.project}:${c.thread_id || 'auto'}`;
}

function _sc_load(){
  try{ return JSON.parse(localStorage.getItem(_chatKey()) || "[]"); }catch{ return []; }
}
function _sc_save(list){
  localStorage.setItem(_chatKey(), JSON.stringify(list || []));
}
function _sc_uid(){ return "m_" + Math.random().toString(16).slice(2) + "_" + Date.now(); }

function _el(id){ return document.getElementById(id); }

function _renderSimple(list){
  const tr = _el("chatTranscript");
  if(!tr) return;
  tr.innerHTML = "";
  (list || []).forEach(m=>{
    const row = document.createElement("div");
    row.className = "chatMsg " + (m.role === "user" ? "user" : "assistant");
    const bubble = document.createElement("div");
    bubble.className = "bubble";

    const role = document.createElement("div");
    role.className = "role";
    role.textContent = (m.role === "user" ? "You" : "SERA");

    const txt = document.createElement("div");
    txt.className = "text";
    txt.textContent = (m.text || "");

    // Attachment chip (thread-stored file)
    if(m.attachment && m.attachment.file_id){
      const chip = document.createElement('div');
      chip.className = 'attachChip';
      const a = document.createElement('a');
      a.href = `/api/threads/file?project=${encodeURIComponent(m.attachment.project||_ctx().project)}&thread_id=${encodeURIComponent(m.attachment.thread_id||_ctx().thread_id||'')}&file_id=${encodeURIComponent(m.attachment.file_id)}`;
      a.textContent = `📎 ${m.attachment.name || 'file'}`;
      a.target = '_blank';
      chip.appendChild(a);
      bubble.appendChild(chip);
    }

    if(m.role === "assistant" && m.meta){
      const det = document.createElement("details");
      det.style.marginTop = "8px";
      const sum = document.createElement("summary");
      sum.textContent = "Details";
      const pre = document.createElement("pre");
      pre.className = "code";
      pre.textContent = JSON.stringify(m.meta, null, 2);
      det.appendChild(sum);
      det.appendChild(pre);
      bubble.appendChild(det);
    }

    // Confirmation UI for state-changing actions
    if(m.role === "assistant" && m.needs_confirm && m.confirm_for){
      const bar = document.createElement("div");
      bar.className = "row";
      bar.style.gap = "8px";
      bar.style.marginTop = "10px";

      const btnYes = document.createElement("button");
      btnYes.className = "primary";
      btnYes.textContent = "Confirm";
      btnYes.addEventListener("click", ()=>{
        _sendSimple(m.confirm_for, "yes");
      });

      const btnNo = document.createElement("button");
      btnNo.className = "ghost";
      btnNo.textContent = "Cancel";
      btnNo.addEventListener("click", ()=>{
        // Replace this assistant message with a cancelled note
        const cur = _sc_load();
        const idx = cur.findIndex(x=>x.id===m.id);
        if(idx >= 0){
          cur[idx] = { ...cur[idx], needs_confirm:false, confirm_for:null, text: (m.text||"").trim() + "\n\n(Cancelled)" };
          _sc_save(cur);
          _renderSimple(cur);
        }
      });

      bar.appendChild(btnYes);
      bar.appendChild(btnNo);
      bubble.appendChild(bar);
    }

    bubble.appendChild(role);
    bubble.appendChild(txt);
    row.appendChild(bubble);
    tr.appendChild(row);
  });
  tr.scrollTop = tr.scrollHeight;
}

function _setStatus(s){
  const el = _el("chatStatus");
  if(!el) return;
  el.textContent = s;
  el.className = "pill" + (s === "Sending" ? " warn" : (s === "Error" ? " bad" : ""));
}

async function _sendSimple(text, confirm){
  const list = _sc_load();
  const userMsg = { id: _sc_uid(), role: "user", text, ts: Date.now() };
  const botMsg  = { id: _sc_uid(), role: "assistant", text: "…", ts: Date.now(), pending: true };
  list.push(userMsg);
  list.push(botMsg);
  _sc_save(list);
  _renderSimple(list);

  _setStatus("Sending");
  try{
    const c = _ctx();
    const r = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user: text,
        confirm: confirm || undefined,
        project: c.project,
        thread_id: c.thread_id || undefined,
        processor: (document.getElementById("chatProcessor")?.value || undefined)
      })
    });
    const j = await r.json().catch(()=>({ ok:false, error:"Bad JSON from server" }));

    // If the server created a thread automatically, adopt it
    if(j && j.thread_id && window.SERA_CTX){
      try{
        window.SERA_CTX.thread_id = j.thread_id;
        // Update selector if present
        const tSel = document.getElementById('chatThread');
        if(tSel) tSel.value = j.thread_id;
        // persist last thread per project
        const p = (window.SERA_CTX.project || 'default');
        const m = JSON.parse(localStorage.getItem('sera_last_thread_v1') || '{}');
        m[p] = j.thread_id;
        localStorage.setItem('sera_last_thread_v1', JSON.stringify(m));
      }catch{}
    }

    // Replace pending message
    const cur = _sc_load();
    const idx = cur.findIndex(x=>x.id===botMsg.id);
    if(idx >= 0){
      const raw = j.raw || {};
      const needs_confirm = !!raw.needs_confirm;
      cur[idx] = {
        ...cur[idx],
        pending:false,
        text: (j.reply || j.error || "(no reply)"),
        needs_confirm,
        confirm_for: needs_confirm ? text : null,
        meta: (raw && (raw.intent || raw.result || raw.next_suggested)) ? { intent: raw.intent, result: raw.result, next_suggested: raw.next_suggested } : null
      };
    }
    _sc_save(cur);
    _renderSimple(cur);

    _setStatus("Idle");
  }catch(e){
    const cur = _sc_load();
    const idx = cur.findIndex(x=>x.id===botMsg.id);
    if(idx >= 0){
      cur[idx] = { ...cur[idx], pending:false, text: "ERROR: " + String(e) };
    }
    _sc_save(cur);
    _renderSimple(cur);

    _setStatus("Error");
  }
}

// Public hooks for other modules (projects_threads.js)
window.SERA_CHAT = window.SERA_CHAT || {};
window.SERA_CHAT.setMessages = function(msgs){
  const list = (msgs || []).map(m=>({ id:_sc_uid(), role:m.role, text:m.text, ts:m.ts||Date.now() }));
  _sc_save(list);
  _renderSimple(list);
};
window.SERA_CHAT.clear = function(){
  _sc_save([]);
  _renderSimple([]);
};

function _wireSimpleChat(){
  const input = _el("chatInput");
  const send = _el("chatSend");
  const clear = _el("chatClear");
  const mic = _el("chatMic");
  const attachBtn = _el("chatAttach");
  const attachInp = _el("chatAttachFile");

  if(!input || !send) return;

  // Load transcript
  _renderSimple(_sc_load());
  _setStatus("Idle");

  // Safe mode banner
  (async ()=>{
    try{
      const r = await fetch('/api/config', { cache:'no-store' });
      const j = await r.json().catch(()=>null);
      const b = _el('chatSafeBanner');
      if(!b || !j) return;
      if(j.safe_mode){
        b.style.display = 'block';
        b.textContent = 'SAFE MODE is ON: state-changing actions will be blocked or require confirmation.';
      }else{
        b.style.display = 'none';
      }
    }catch{/* ignore */}
  })();

  function doSend(){
    const text = (input.value || "").trim();
    if(!text) return;
    input.value = "";
    _sendSimple(text);
  }

  send.addEventListener("click", doSend);

  input.addEventListener("keydown", (e)=>{
    if(e.key === "Enter" && !e.shiftKey){
      e.preventDefault();
      doSend();
    }
  });

  if(clear){
    clear.addEventListener("click", ()=>{
      if(!confirm("Clear chat history on this browser?")) return;
      _sc_save([]);
      _renderSimple([]);
    });
  }

  // Attach (Phase2 stub): wiring only. Actual thread-file storage comes in Sprint 2.
  if(attachBtn && attachInp){
    attachBtn.addEventListener('click', ()=>{
      attachInp.value = "";
      attachInp.click();
    });
    attachInp.addEventListener('change', ()=>{
      const files = Array.from(attachInp.files || []);
      if(!files.length) return;
      alert('Attach-to-thread storage is coming next sprint. For now, use Workspace upload.');
    });
  }

  // PTT mic (Web Speech). Auto-sends on final text or on end if anything is present.
  (function wireMic(){
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if(!mic) return;
    if(!SR){
      mic.disabled = true;
      mic.title = 'Web Speech STT not available in this browser.';
      return;
    }
    let rec = null;
    let recognizing = false;

    function init(){
      const r = new SR();
      r.continuous = false;
      r.interimResults = true;
      r.lang = navigator.language || 'en-US';
      r.onstart = ()=>{
        recognizing = true;
        mic.classList.add('micOn');
      };
      r.onend = ()=>{
        recognizing = false;
        mic.classList.remove('micOn');
        const t = String(input.value || '').trim();
        if(t) doSend();
      };
      r.onerror = ()=>{
        recognizing = false;
        mic.classList.remove('micOn');
      };
      r.onresult = (ev)=>{
        let finalText = '';
        let interim = '';
        for(let i=ev.resultIndex;i<ev.results.length;i++){
          const txt = ev.results[i][0]?.transcript || '';
          if(ev.results[i].isFinal) finalText += txt;
          else interim += txt;
        }
        const merged = String(finalText || interim || '').trim();
        if(merged) input.value = merged;
        if(String(finalText||'').trim()){
          doSend();
        }
      };
      return r;
    }

    mic.addEventListener('click', ()=>{
      try{
        if(!rec) rec = init();
        if(!rec) return;
        if(recognizing){ rec.stop(); return; }
        rec.start();
      }catch(_){
        recognizing = false;
        mic.classList.remove('micOn');
      }
    });
  })();
}


// -----------------------------
// Mode 2: Legacy threaded scaffold
// -----------------------------
const CHAT_KEY = "sera_chat_v1";

function loadState(){
  try { return JSON.parse(localStorage.getItem(CHAT_KEY) || "{}"); } catch { return {}; }
}
function saveState(s){ localStorage.setItem(CHAT_KEY, JSON.stringify(s)); }
function uid(){ return "id_" + Math.random().toString(16).slice(2) + "_" + Date.now(); }

function ensureDefaults(s){
  s.threads = s.threads || [];
  s.projects = s.projects || [];
  if(!s.activeThreadId && s.threads[0]) s.activeThreadId = s.threads[0].id;
  return s;
}

function renderLists(s){
  const tList = document.getElementById("threadList");
  const pList = document.getElementById("projectList");
  if(!tList || !pList) return;

  tList.innerHTML = "";
  s.threads.forEach(t=>{
    const b = document.createElement("button");
    b.className = "sideItem" + (t.id===s.activeThreadId ? " active" : "");
    b.textContent = t.title || "Untitled";
    b.onclick = ()=>{ s.activeThreadId = t.id; saveState(s); renderAll(); };
    tList.appendChild(b);
  });

  pList.innerHTML = "";
  s.projects.forEach(p=>{
    const b = document.createElement("button");
    b.className = "sideItem";
    b.textContent = p.name || "Project";
    b.onclick = ()=>{ const eb = document.getElementById("echoBox"); if(eb) eb.textContent = `Project: ${p.name}`; };
    pList.appendChild(b);
  });

  // When project/thread changes (sidebar click), reload transcript for new ctx.
  window.addEventListener('sera:ctx', ()=>{
    try{
      _renderSimple(_sc_load());
      _setStatus('Idle');
    }catch{/* ignore */}
  });
}

function renderTranscript(s){
  const tr = document.getElementById("chatTranscript");
  const meta = document.getElementById("chatMeta");
  if(!tr || !meta) return;

  const th = s.threads.find(x=>x.id===s.activeThreadId);
  if(!th){
    meta.textContent = "No thread selected";
    tr.innerHTML = "";
    return;
  }
  meta.textContent = th.title || "Untitled thread";

  tr.innerHTML = "";
  (th.messages || []).forEach(m=>{
    const row = document.createElement("div");
    row.className = "msg " + (m.role==="me" ? "me" : "bot");
    row.innerHTML = `<div class="bubble"><div class="msgRole">${m.role}</div><div class="msgText"></div></div>`;
    row.querySelector(".msgText").textContent = m.text || "";
    tr.appendChild(row);
  });
  tr.scrollTop = tr.scrollHeight;
}

function addMessage(s, role, text){
  const th = s.threads.find(x=>x.id===s.activeThreadId);
  if(!th) return;
  th.messages = th.messages || [];
  th.messages.push({ role, text, ts: Date.now() });
}

function newThread(s){
  const title = prompt("Thread name:", "New thread");
  if(!title) return;
  const t = { id: uid(), title, messages: [] };
  s.threads.unshift(t);
  s.activeThreadId = t.id;
  saveState(s);
  renderAll();
}
function newProject(s){
  const name = prompt("Project name:", "New project");
  if(!name) return;
  s.projects.unshift({ id: uid(), name });
  saveState(s);
  renderAll();
}

function wireChat(){
  const btnSend = document.getElementById("btnSend");
  const btnClear = document.getElementById("btnClear");
  const input = document.getElementById("chatInput");
  const btnNewThread = document.getElementById("btnNewThread");
  const btnNewProject = document.getElementById("btnNewProject");

  if(btnNewThread) btnNewThread.onclick = ()=>{ const s=ensureDefaults(loadState()); newThread(s); };
  if(btnNewProject) btnNewProject.onclick = ()=>{ const s=ensureDefaults(loadState()); newProject(s); };

  if(btnSend && input){
    btnSend.onclick = ()=>{
      const text = (input.value||"").trim();
      if(!text) return;
      const s = ensureDefaults(loadState());
      if(!s.threads.length){ s.threads=[{id:uid(),title:"General",messages:[]}]; s.activeThreadId=s.threads[0].id; }
      addMessage(s, "me", text);
      addMessage(s, "bot", "Received. (AI wiring next)");
      saveState(s);
      input.value = "";
      renderAll();
    };
  }

  if(btnClear){
    btnClear.onclick = ()=>{
      const s = ensureDefaults(loadState());
      const th = s.threads.find(x=>x.id===s.activeThreadId);
      if(th){ th.messages=[]; saveState(s); renderAll(); }
    };
  }

  // Attachments (base64 upload into thread container)
  if(attachBtn && attachInp){
    attachBtn.title = 'Attach file';
    attachBtn.addEventListener('click', ()=>{
      attachInp.value = '';
      attachInp.click();
    });

    attachInp.addEventListener('change', async ()=>{
      const f = attachInp.files && attachInp.files[0];
      if(!f) return;
      const c = _ctx();
      if(!c.thread_id){
        // Create a thread implicitly by sending a small no-op message? Prefer create endpoint if present.
        try{
          const out = await fetch('/api/threads/create', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ project: c.project, title: 'New chat' }) }).then(r=>r.json());
          if(out && out.thread_id){
            window.SERA_CTX.thread_id = out.thread_id;
          }
        }catch{/* ignore */}
      }
      const ctxNow = _ctx();
      if(!ctxNow.thread_id){
        alert('No active thread yet. Create/open a chat first.');
        return;
      }

      // read file as base64
      const b64 = await new Promise((resolve, reject)=>{
        const r = new FileReader();
        r.onerror = ()=>reject(new Error('read failed'));
        r.onload = ()=>resolve(String(r.result||''));
        r.readAsDataURL(f);
      });

      _setStatus('Uploading');
      try{
        const up = await fetch('/api/threads/upload_b64', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ project: ctxNow.project, thread_id: ctxNow.thread_id, filename: f.name, b64, mime: f.type || undefined })
        }).then(r=>r.json());
        if(!up || !up.ok){ throw new Error(up?.error || 'upload failed'); }

        // Append a message into the transcript (local UI) and to the thread log
        const msgText = `Attached file: ${up.name}`;
        const list = _sc_load();
        const m = { id:_sc_uid(), role:'user', text: msgText, ts: Date.now(), attachment:{ project: ctxNow.project, thread_id: ctxNow.thread_id, file_id: up.file_id, name: up.name } };
        list.push(m);
        _sc_save(list);
        _renderSimple(list);

        // persist into thread
        try{
          await fetch('/api/threads/append', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ project: ctxNow.project, thread_id: ctxNow.thread_id, role:'user', content: msgText }) });
        }catch{/* ignore */}

        _setStatus('Idle');
      }catch(e){
        _setStatus('Error');
        alert('Upload failed: ' + (e?.message || e));
      }
    });
  }
}

function renderAll(){
  const s = ensureDefaults(loadState());
  renderLists(s);
  renderTranscript(s);
}


document.addEventListener("DOMContentLoaded", ()=>{
  // Prefer the new simple chat if present
  if(document.getElementById("chatInput") && document.getElementById("chatSend") && document.getElementById("chatTranscript") && !document.getElementById("threadList")){
    _wireSimpleChat();
    return;
  }

  // Legacy mode
  if(document.getElementById("threadList")){
    const s = ensureDefaults(loadState());
    if(!s.threads.length){
      s.threads = [{ id: uid(), title:"General", messages:[] }];
      s.activeThreadId = s.threads[0].id;
      saveState(s);
    }
    wireChat();
    renderAll();
  }
});

// -------- Server Threads mini-list (Chat sidebar) --------
function getActiveProject(){
  try{ return (localStorage.getItem("SERA_ACTIVE_PROJECT")||"").trim() || "default"; }catch{ return "default"; }
}

async function loadThreadsMini(){
  const box = document.getElementById("chatThreadsMini");
  if(!box) return;

  const proj = getActiveProject();
  box.innerHTML = "<div class='muted'>Loading…</div>";

  try{
    const r = await fetch("/api/threads/list", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ project: proj, limit: 20 })
    });
    if(!r.ok) throw new Error("threads/list " + r.status);
    const j = await r.json();
    const items = (j && j.threads) ? j.threads : [];
    if(!items.length){
      box.innerHTML = "<div class='muted'>No threads yet.</div>";
      return;
    }
    box.innerHTML = "";
    for(const t of items){
      const b = document.createElement("button");
      b.type = "button";
      b.className = "sideItem";
      b.textContent = t.title || t.id || t.thread_id || "thread";
      b.title = "Open in Threads";
      b.onclick = () => {
        try{ localStorage.setItem("SERA_ACTIVE_PROJECT", proj); }catch{}
        // allow threads page to focus a thread (optional)
        const tid = t.id || t.thread_id || "";
        if(tid){ try{ localStorage.setItem("SERA_ACTIVE_THREAD_ID", tid); }catch{} }
        window.location.hash = "#threads";
      };
      box.appendChild(b);
    }
  }catch(e){
    box.innerHTML = "<div class='muted'>Failed to load threads.</div>";
    console.warn("chat threads mini failed:", e);
  }
}

function wireThreadsMini(){
  const openBtn = document.getElementById("chatThreadsOpen");
  if(openBtn){
    openBtn.addEventListener("click", () => { window.location.hash = "#threads"; });
  }
  loadThreadsMini();
  // refresh on hash changes back to chat or project change elsewhere
  window.addEventListener("storage", (ev) => {
    if(ev.key === "SERA_ACTIVE_PROJECT") loadThreadsMini();
  });
}


// --- Threads-in-Chat: mount threads list into chat sidebar if present ---
document.addEventListener('DOMContentLoaded', ()=>{
  const mount = document.getElementById('chatThreadsList');
  if(mount && window.__SERA_THREADS && window.__SERA_THREADS.loadThreads){
    try{ window.__SERA_THREADS.loadThreads(); }catch(e){}
  }
});
