// ui/phase2/projects.js
(function(){
  const { getRootEl, h, clear, apiGet, apiPost, setHash } = window.SERA_P2.common;

  async function render(){
    const root = getRootEl();
    clear(root);

    const header = h("div", {class:"seraP2Card"}, [
      h("div", {style:"font-weight:700;font-size:18px"}, ["Projects"]),
      h("div", {style:"opacity:0.8;margin-top:6px"}, ["Create a project, then open Workspace."]),
    ]);

    const errBox = h("div", {style:"color:salmon;margin-top:10px;display:none"}, [""]);
    header.appendChild(errBox);

    const nameInput = h("input", {class:"seraP2Input", value:"demo", placeholder:"project name"});
    const tplInput  = h("input", {class:"seraP2Input", value:"web-hello", placeholder:"template (web-hello)"});

    const createBtn = h("button", {class:"seraP2Btn"}, ["Create"]);
    const refreshBtn = h("button", {class:"seraP2Btn"}, ["Refresh"]);

    const row = h("div", {class:"seraP2Row", style:"margin-top:12px"}, [nameInput, tplInput, createBtn, refreshBtn]);
    header.appendChild(row);

    const listCard = h("div", {class:"seraP2Card"}, [
      h("div", {style:"font-weight:600"}, ["Existing"]),
      h("div", {id:"seraP2ProjectsList", style:"margin-top:10px"}, ["Loading..."]),
    ]);

    root.appendChild(h("div", {class:"seraP2Wrap"}, [
      h("div", {style:"flex:1"}, [header, listCard])
    ]));

    async function refresh(){
      errBox.style.display = "none";
      const list = listCard.querySelector("#seraP2ProjectsList");
      list.textContent = "Loading...";
      try{
        const data = await apiGet("/api/projects");
        const projects = data.projects || [];
        if (!projects.length){
          list.textContent = "No projects yet.";
          return;
        }
        clear(list);
        projects.forEach(p => {
          const item = h("div", {class:"seraP2ListItem", title:p.path || ""}, [
            h("div", {style:"font-weight:600"}, [p.name || p.id]),
            h("div", {class:"seraP2Mono", style:"opacity:0.75"}, [p.id]),
          ]);
          item.addEventListener("click", () => setHash(`/project/${encodeURIComponent(p.id)}`));
          list.appendChild(item);
        });
      }catch(e){
        errBox.textContent = (e.data && (e.data.detail || e.data.error)) || e.message;
        errBox.style.display = "block";
        list.textContent = "Failed to load.";
      }
    }

    createBtn.addEventListener("click", async () => {
      errBox.style.display = "none";
      createBtn.disabled = true;
      try{
        const out = await apiPost("/api/projects", { name: nameInput.value.trim(), template: tplInput.value.trim() || "web-hello" });
        const id = out && out.project && out.project.id;
        await refresh();
        if (id) setHash(`/project/${encodeURIComponent(id)}`);
      }catch(e){
        errBox.textContent = (e.data && (e.data.detail || e.data.error)) || e.message;
        errBox.style.display = "block";
      }finally{
        createBtn.disabled = false;
      }
    });

    refreshBtn.addEventListener("click", refresh);
    await refresh();
  }

  window.SERA_P2 = window.SERA_P2 || {};
  window.SERA_P2.renderProjects = render;
})();
