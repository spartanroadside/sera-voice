// ui/phase2/workspace.js
(function(){
  const { getRootEl, h, clear, apiGet, apiPost, setHash } = window.SERA_P2.common;

  function fileNode(node, activePath, onPick, level=0){
    const isDir = node.type === "dir";
    const row = h("div", {
      class: "seraP2ListItem " + (activePath === node.path ? "seraP2ListItemActive" : ""),
      style: "padding-left:" + (10 + level*10) + "px;display:flex;justify-content:space-between;"
    }, [
      h("span", {class:"seraP2Mono"}, [(isDir ? "📁 " : "📄 ") + node.name]),
      (!isDir && typeof node.bytes === "number") ? h("span", {class:"seraP2Mono", style:"opacity:0.6"}, [String(node.bytes)]) : null
    ]);

    if (!isDir){
      row.addEventListener("click", () => onPick(node.path));
    }

    const wrap = h("div", {}, [row]);
    if (isDir && Array.isArray(node.children)){
      node.children.forEach(c => wrap.appendChild(fileNode(c, activePath, onPick, level+1)));
    }
    return wrap;
  }

  async function render(projectId){
    const root = getRootEl();
    clear(root);

    const top = h("div", {class:"seraP2Card"}, [
      h("div", {style:"font-weight:700;font-size:18px"}, ["Workspace"]),
      h("div", {class:"seraP2Mono", style:"opacity:0.75;margin-top:6px"}, [projectId]),
      h("div", {class:"seraP2Row", style:"margin-top:10px"}, [
        h("button", {class:"seraP2Btn", id:"p2Back"}, ["← Projects"]),
        h("button", {class:"seraP2Btn", id:"p2Refresh"}, ["Refresh Files"]),
      ]),
      h("div", {id:"p2Err", style:"color:salmon;margin-top:10px;display:none"}, [""])
    ]);

    const treePanel = h("div", {class:"seraP2Panel", id:"p2Tree"}, ["Loading..."]);
    const editorPath = h("div", {class:"seraP2Mono", style:"opacity:0.75"}, ["(pick a file)"]);
    const editor = h("textarea", {class:"seraP2Textarea seraP2Mono", id:"p2Editor", disabled:"true"}, [""]);
    const saveBtn = h("button", {class:"seraP2Btn", id:"p2Save", disabled:"true"}, ["Save"]);
    const tarOpenBtn = h("button", {class:"seraP2Btn", id:"p2TarOpen", style:"display:none"}, ["Open inner"]);
    const tarExtractBtn = h("button", {class:"seraP2Btn", id:"p2TarExtract", style:"display:none"}, ["Extract"]);
    const reloadBtn = h("button", {class:"seraP2Btn", id:"p2Reload", disabled:"true"}, ["Reload"]);

    const editorCard = h("div", {class:"seraP2Card"}, [
      h("div", {class:"seraP2Row", style:"justify-content:space-between"}, [
        h("div", {style:"font-weight:600"}, ["Editor"]),
        h("div", {class:"seraP2Row"}, [tarOpenBtn, tarExtractBtn, reloadBtn, saveBtn])
      ]),
      editorPath,
      editor
    ]);

    const threadsCard = h("div", {class:"seraP2Card"}, [
      h("div", {class:"seraP2Row", style:"justify-content:space-between"}, [
        h("div", {style:"font-weight:600"}, ["Threads"]),
        h("button", {class:"seraP2Btn", id:"p2ThreadsRefresh"}, ["Refresh"])
      ]),
      h("div", {class:"seraP2Row", style:"margin-top:10px"}, [
        h("input", {class:"seraP2Input", id:"p2ThreadTitle", value:"General", placeholder:"New thread title"}),
        h("button", {class:"seraP2Btn", id:"p2ThreadCreate"}, ["Create"])
      ]),
      h("div", {id:"p2ThreadsList", style:"margin-top:10px"}, ["Loading..."])
    ]);

    const chatCard = h("div", {class:"seraP2Card"}, [
      h("div", {class:"seraP2Row", style:"justify-content:space-between"}, [
        h("div", {style:"font-weight:600"}, ["Chat"]),
        h("button", {class:"seraP2Btn", id:"p2ChatRefresh", disabled:"true"}, ["Refresh"]),
      ]),
      h("div", {class:"seraP2Mono", id:"p2ThreadLabel", style:"opacity:0.75;margin-top:6px"}, ["(select a thread)"]),
      h("div", {id:"p2ChatBox", style:"margin-top:10px;max-height:260px;overflow:auto;border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:10px"}, [""]),
      h("div", {class:"seraP2Row", style:"margin-top:10px"}, [
        h("input", {class:"seraP2Input", id:"p2ChatInput", placeholder:"Type message...", disabled:"true"}),
        h("button", {class:"seraP2Btn", id:"p2ChatSend", disabled:"true"}, ["Send"])
      ])
    ]);

    const aiConsolePre = h("pre",{class:"seraP2Mono", id:"p2AiConsole", style:"margin-top:10px;white-space:pre-wrap;max-height:320px;overflow:auto;border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:10px;background:rgba(0,0,0,0.15)"}, [""]);
    const aiHost = h("div",{id:"p2AiConsoleHost"}, [aiConsolePre]);

    const aiCard = h("div", {class:"seraP2Card", id:"p2AiDock"}, [
      h("div",{class:"seraP2Row", style:"justify-content:space-between;align-items:center"}, [
        h("div",{style:"font-weight:600"}, ["AI Console"]),
        h("div",{class:"seraP2Row", style:"gap:8px"}, [
          h("button",{class:"seraP2Btn", id:"p2AiUndock"}, ["Undock"]),
          h("button",{class:"seraP2Btn ghost", id:"p2AiClear"}, ["Clear"]),
        ])
      ]),
      h("div",{class:"seraP2Mono", id:"p2AiDesc", style:"opacity:0.75;margin-top:6px"}, ["(tool + reasoning console output will appear here)"]),
      aiHost
    ]);

    const runCard = h("div", {class:"seraP2Card"}, [
      h("div",{class:"seraP2Row", style:"justify-content:space-between;align-items:center"}, [
        h("div",{style:"font-weight:600"}, ["Running Console"]),
        h("div",{class:"seraP2Row", style:"gap:8px"}, [
          h("button",{class:"seraP2Btn ghost", id:"p2RunClear"}, ["Clear"]),
        ])
      ]),
      h("div",{class:"seraP2Mono", style:"opacity:0.75;margin-top:6px"}, ["(live system calls + activities)"]),
      h("pre",{class:"seraP2Mono", id:"p2RunConsole", style:"margin-top:10px;white-space:pre-wrap;max-height:320px;overflow:auto;border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:10px;background:rgba(0,0,0,0.15)"}, [""])
    ]);

    const filesCard = h("div", {class:"seraP2Card"}, [
      h("div",{style:"font-weight:600;margin-bottom:10px"},["Files (repo)"]),
      treePanel
    ]);

    const projectCard = h("div", {class:"seraP2Card"}, [
      h("div",{style:"font-weight:600;margin-bottom:10px"},["Project Viewer"]),
      threadsCard
    ]);

    // Main workbench grid
    const layout = h("div", {class:"seraP2Wrap"}, [
      h("div", {style:"flex:1;min-height:0"}, [
        top,
        h("div",{class:"seraP2Workbench"}, [
          h("div",{class:"seraP2LeftStack"}, [filesCard, projectCard]),
          h("div",{class:"seraP2VSplit", "data-split":"lc", title:"Drag to resize"}, [""]),
          h("div",{class:"seraP2Center"}, [editorCard]),
          h("div",{class:"seraP2VSplit", "data-split":"cr", title:"Drag to resize"}, [""]),
          h("div",{class:"seraP2RightStack"}, [aiCard, runCard]),
        ]),
        h("div",{class:"seraP2HSplit", "data-split":"chat", title:"Drag to resize"}, [""]),
        h("div",{class:"seraP2ChatDock"}, [chatCard])
      ])
    ]);

    root.appendChild(layout);

    // ----- Splitter behavior (stores sizes in localStorage) -----
    (function initSplitters(){
      const key = "sera.p2.workbench.v1";
      const defaults = { left: 340, right: 320, chatH: 220 };
      let st = defaults;
      try { st = Object.assign({}, defaults, JSON.parse(localStorage.getItem(key) || "{}")); } catch(e){}

      function apply(){
        document.documentElement.style.setProperty("--p2-left", st.left + "px");
        document.documentElement.style.setProperty("--p2-right", st.right + "px");
        document.documentElement.style.setProperty("--p2-chat-h", st.chatH + "px");
      }
      function save(){ try { localStorage.setItem(key, JSON.stringify(st)); } catch(e){} }
      apply();

      function clamp(n, lo, hi){ return Math.max(lo, Math.min(hi, n)); }

      const wb = root.querySelector(".seraP2Workbench");
      const rect0 = ()=>wb.getBoundingClientRect();

      function onDrag(split, startX, startY){
        const rect = rect0();
        function move(ev){
          const x = (ev.touches?ev.touches[0].clientX:ev.clientX);
          const y = (ev.touches?ev.touches[0].clientY:ev.clientY);
          const r = rect0();
          const totalW = r.width;

          if (split === "lc"){
            st.left = clamp(Math.round(x - r.left), 240, Math.round(totalW*0.6));
          } else if (split === "cr"){
            st.right = clamp(Math.round(r.right - x), 240, Math.round(totalW*0.5));
          } else if (split === "chat"){
            // chat height based on viewport area under wb top
            const container = root.querySelector(".seraP2Wrap").getBoundingClientRect();
            const maxH = Math.round(container.height * 0.6);
            st.chatH = clamp(Math.round(container.bottom - y), 140, maxH);
          }
          apply();
          ev.preventDefault?.();
        }
        function up(){
          window.removeEventListener("mousemove", move);
          window.removeEventListener("mouseup", up);
          window.removeEventListener("touchmove", move);
          window.removeEventListener("touchend", up);
          save();
        }
        window.addEventListener("mousemove", move);
        window.addEventListener("mouseup", up);
        window.addEventListener("touchmove", move, {passive:false});
        window.addEventListener("touchend", up);
      }

      root.querySelectorAll(".seraP2VSplit, .seraP2HSplit").forEach(el=>{
        el.addEventListener("mousedown", (ev)=>{ ev.preventDefault(); onDrag(el.getAttribute("data-split"), ev.clientX, ev.clientY); });
        el.addEventListener("touchstart", (ev)=>{ ev.preventDefault(); const t=ev.touches[0]; onDrag(el.getAttribute("data-split"), t.clientX, t.clientY); }, {passive:false});
      });
    })();

    // ----- AI Console Dock/Undock -----
    (function initAiDock(){
      const dock = root.querySelector("#p2AiDock");
      const undockBtn = dock.querySelector("#p2AiUndock");
      const clearBtn = dock.querySelector("#p2AiClear");
      const pre = dock.querySelector("#p2AiConsole");
      const host = dock.querySelector("#p2AiConsoleHost");

      function clear(){ pre.textContent = ""; }
      clearBtn.addEventListener("click", clear);

      let floating = null;

      function makeFloating(){
        const wrap = document.createElement("div");
        wrap.className = "seraP2Float";
        wrap.style.left = "60px";
        wrap.style.top = "80px";
        wrap.innerHTML = `
          <div class="seraP2FloatBar">
            <div style="font-weight:600">AI Console</div>
            <div class="seraP2Row" style="gap:8px">
              <button class="seraP2Btn ghost" data-act="clear">Clear</button>
              <button class="seraP2Btn" data-act="dock">Dock</button>
            </div>
          </div>
          <div class="seraP2FloatBody"></div>
        `;
        const body = wrap.querySelector(".seraP2FloatBody");
        body.appendChild(pre); // move console pre into floating window

        wrap.querySelector('[data-act="clear"]').addEventListener("click", clear);
        wrap.querySelector('[data-act="dock"]').addEventListener("click", ()=>dockBack());

        // drag support
        const bar = wrap.querySelector(".seraP2FloatBar");
        let sx=0, sy=0, ox=0, oy=0, dragging=false;
        function down(ev){
          dragging=true;
          const x=ev.touches?ev.touches[0].clientX:ev.clientX;
          const y=ev.touches?ev.touches[0].clientY:ev.clientY;
          sx=x; sy=y;
          const r=wrap.getBoundingClientRect();
          ox=r.left; oy=r.top;
          ev.preventDefault();
          window.addEventListener("mousemove", move);
          window.addEventListener("mouseup", up);
          window.addEventListener("touchmove", move, {passive:false});
          window.addEventListener("touchend", up);
        }
        function move(ev){
          if(!dragging) return;
          const x=ev.touches?ev.touches[0].clientX:ev.clientX;
          const y=ev.touches?ev.touches[0].clientY:ev.clientY;
          wrap.style.left = (ox + (x - sx)) + "px";
          wrap.style.top  = (oy + (y - sy)) + "px";
          ev.preventDefault();
        }
        function up(){
          dragging=false;
          window.removeEventListener("mousemove", move);
          window.removeEventListener("mouseup", up);
          window.removeEventListener("touchmove", move);
          window.removeEventListener("touchend", up);
        }
        bar.addEventListener("mousedown", down);
        bar.addEventListener("touchstart", down, {passive:false});

        document.body.appendChild(wrap);
        return wrap;
      }

      function dockBack(){
        if(!floating) return;
        host.appendChild(pre);
        floating.remove();
        floating=null;
        undockBtn.textContent="Undock";
      }

      function undock(){
        if(floating) return;
        floating = makeFloating();
        undockBtn.textContent="Dock";
      }

      undockBtn.addEventListener("click", ()=>{
        if(floating) dockBack(); else undock();
      });
    })();


    const errEl = top.querySelector("#p2Err");
    function showErr(msg){
      errEl.textContent = msg;
      errEl.style.display = msg ? "block" : "none";
    }

    let activeFile = "";
    let activeThread = "";

    let tarCtx = null;

    async function loadTree(){
      showErr("");
      treePanel.textContent = "Loading...";
      try{
        const data = await apiGet("/api/projects/" + encodeURIComponent(projectId) + "/tree?scope=repo&path=%2F&depth=4");
        const tree = data.tree;
        clear(treePanel);
        treePanel.appendChild(fileNode(tree, activeFile, async (p) => {
          activeFile = p;
          await loadFile();
          await loadTree();
        }));
      }catch(e){
        showErr((e.data && (e.data.detail || e.data.error)) || e.message);
        treePanel.textContent = "Failed to load tree.";
      }
    }

    async function loadFile(){
      if (!activeFile) return;
      showErr("");
      const rel = activeFile.replace(/^\/+/, "");
      editorPath.textContent = activeFile;
      // Tar support: show tar contents list instead of raw preview
      if(/\.(tar|tgz|tar\.gz)$/i.test(rel)){
        tarCtx = { scope:'repo', tar_path: rel }; 
        tarOpenBtn.style.display='';
        tarExtractBtn.style.display='';
        editor.disabled = true;
        saveBtn.disabled = true;
        reloadBtn.disabled = false;
        try{
          const data = await apiGet('/api/projects/' + encodeURIComponent(projectId) + '/tar/list?scope=repo&path=' + encodeURIComponent(rel));
          const entries = data.entries || data.items || []; // server may use entries
          const lines = (entries||[]).map(e=>{
            const typ = e.type || '';
            const sz = (typeof e.size==='number') ? e.size : (typeof e.bytes==='number') ? e.bytes : '';
            const name = e.name || e.path || '';
            return [typ, sz, name].filter(Boolean).join('\t');
          });
          editor.value = lines.join('\n') || '(empty tar)';
          return;
        }catch(e){
          showErr((e.data && (e.data.detail || e.data.error)) || e.message);
        }
      }
      tarCtx = null;
      tarOpenBtn.style.display='none';
      tarExtractBtn.style.display='none';
      editor.disabled = true;
      saveBtn.disabled = true;
      reloadBtn.disabled = true;
      try{
        const data = await apiGet("/api/projects/" + encodeURIComponent(projectId) + "/file?scope=repo&path=" + encodeURIComponent(rel) + "&mode=preview");
        if (data.redacted){
          editor.value = "";
          editor.disabled = true;
          showErr("Redacted: " + (data.reason || "secret_pattern"));
          return;
        }
        editor.value = data.content || "";
        editor.disabled = false;
        saveBtn.disabled = false;
        reloadBtn.disabled = false;
      }catch(e){
        showErr((e.data && (e.data.detail || e.data.error)) || e.message);
      }
    }

    
tarOpenBtn.addEventListener("click", async () => {
  if(!tarCtx) return;
  const inner = prompt("Inner file path inside tar:", "");
  if(!inner) return;
  showErr("");
  try{
    const qs = new URLSearchParams({ scope: tarCtx.scope, tar_path: tarCtx.tar_path, inner_path: inner });
    const data = await apiGet('/api/projects/' + encodeURIComponent(projectId) + '/tar/file?' + qs.toString());
    editor.value = (data && (data.content || data.data || "")) || "";
  }catch(e){
    showErr((e.data && (e.data.detail || e.data.error)) || e.message);
  }
});

tarExtractBtn.addEventListener("click", async () => {
  if(!tarCtx) return;
  const dest = prompt("Extract to folder (relative to repo):", "imports/");
  if(!dest) return;
  showErr("");
  try{
    await apiPost('/api/projects/' + encodeURIComponent(projectId) + '/tar/extract', {
      scope: tarCtx.scope,
      tar_path: tarCtx.tar_path,
      dest: dest.replace(/^\/+/, '')
    });
    await loadTree();
    showErr("Extracted ✓");
  }catch(e){
    showErr((e.data && (e.data.detail || e.data.error)) || e.message);
  }
});

saveBtn.addEventListener("click", async () => {
      if (!activeFile) return;
      showErr("");
      saveBtn.disabled = true;
      try{
        const rel = activeFile.replace(/^\/+/, "");
        await apiPost("/api/projects/" + encodeURIComponent(projectId) + "/write", { scope:"repo", path: rel, content: editor.value, mode:"overwrite" });
        await loadTree();
      }catch(e){
        showErr((e.data && (e.data.detail || e.data.error)) || e.message);
      }finally{
        saveBtn.disabled = false;
      }
    });

    reloadBtn.addEventListener("click", loadFile);
    top.querySelector("#p2Refresh").addEventListener("click", loadTree);
    top.querySelector("#p2Back").addEventListener("click", () => setHash("/projects"));

    const threadsList = threadsCard.querySelector("#p2ThreadsList");
    const threadTitle = threadsCard.querySelector("#p2ThreadTitle");
    const threadCreate = threadsCard.querySelector("#p2ThreadCreate");
    const threadsRefresh = threadsCard.querySelector("#p2ThreadsRefresh");

    const threadLabel = chatCard.querySelector("#p2ThreadLabel");
    const chatBox = chatCard.querySelector("#p2ChatBox");
    const chatRefresh = chatCard.querySelector("#p2ChatRefresh");
    const chatInput = chatCard.querySelector("#p2ChatInput");
    const chatSend = chatCard.querySelector("#p2ChatSend");

    function renderThreads(threads){
      clear(threadsList);
      if (!threads.length){
        threadsList.textContent = "No threads yet.";
        return;
      }
      threads.forEach(t => {
        const item = h("div", {class:"seraP2ListItem " + (t.id === activeThread ? "seraP2ListItemActive" : "")}, [
          h("div", {class:"seraP2Mono"}, [t.id])
        ]);
        item.addEventListener("click", async () => {
          activeThread = t.id;
          await loadThreads();
          await loadChat();
        });
        threadsList.appendChild(item);
      });
    }

    async function loadThreads(){
      showErr("");
      threadsList.textContent = "Loading...";
      try{
        const data = await apiGet("/api/projects/" + encodeURIComponent(projectId) + "/threads");
        renderThreads(data.threads || []);
      }catch(e){
        showErr((e.data && (e.data.detail || e.data.error)) || e.message);
        threadsList.textContent = "Failed to load threads.";
      }
    }

    async function createThread(){
      showErr("");
      threadCreate.disabled = true;
      try{
        const out = await apiPost("/api/projects/" + encodeURIComponent(projectId) + "/threads", { title: threadTitle.value || "General" });
        const tid = out && out.thread && out.thread.id;
        await loadThreads();
        if (tid){
          activeThread = tid;
          await loadThreads();
          await loadChat();
        }
      }catch(e){
        showErr((e.data && (e.data.detail || e.data.error)) || e.message);
      }finally{
        threadCreate.disabled = false;
      }
    }

    async function loadChat(){
      if (!activeThread){
        threadLabel.textContent = "(select a thread)";
        chatRefresh.disabled = true;
        chatInput.disabled = true;
        chatSend.disabled = true;
        clear(chatBox);
        return;
      }
      threadLabel.textContent = activeThread;
      chatRefresh.disabled = false;
      chatInput.disabled = false;
      chatSend.disabled = false;

      showErr("");
      chatBox.textContent = "Loading...";
      try{
        const data = await apiGet("/api/projects/" + encodeURIComponent(projectId) + "/threads/" + encodeURIComponent(activeThread) + "/messages?tail=200");
        const msgs = data.messages || [];
        clear(chatBox);
        if (!msgs.length){
          chatBox.textContent = "No messages yet.";
          return;
        }
        msgs.forEach(m => {
          chatBox.appendChild(h("div", {style:"margin-bottom:10px"}, [
            h("div", {class:"seraP2Mono", style:"opacity:0.7"}, [(m.role || "") + " • " + (m.ts || "")]),
            h("div", {style:"white-space:pre-wrap"}, [m.text || ""])
          ]));
        });
        chatBox.scrollTop = chatBox.scrollHeight;
      }catch(e){
        showErr((e.data && (e.data.detail || e.data.error)) || e.message);
        chatBox.textContent = "Failed to load chat.";
      }
    }

    async function sendChat(){
      if (!activeThread) return;
      const text = (chatInput.value || "").trim();
      if (!text) return;
      chatSend.disabled = true;
      try{
        await apiPost("/api/projects/" + encodeURIComponent(projectId) + "/threads/" + encodeURIComponent(activeThread) + "/messages", { role:"user", text: text });
        chatInput.value = "";
        await loadChat();
      }catch(e){
        showErr((e.data && (e.data.detail || e.data.error)) || e.message);
      }finally{
        chatSend.disabled = false;
      }
    }

    threadCreate.addEventListener("click", createThread);
    threadsRefresh.addEventListener("click", loadThreads);
    chatRefresh.addEventListener("click", loadChat);
    chatSend.addEventListener("click", sendChat);
    chatInput.addEventListener("keydown", (e) => { if (e.key === "Enter") sendChat(); });

    await loadTree();
    await loadThreads();
    await loadChat();
  }

  window.SERA_P2 = window.SERA_P2 || {};
  window.SERA_P2.renderWorkspace = render;
})();