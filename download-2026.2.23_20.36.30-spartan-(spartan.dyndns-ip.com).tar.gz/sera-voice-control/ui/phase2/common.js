// ui/phase2/common.js
(function(){
  'use strict';

  var ROOT_IDS = ["main","content","app","page","workspace","root"];

  function getRootEl(){
    for (var i=0;i<ROOT_IDS.length;i++){
      var el = document.getElementById(ROOT_IDS[i]);
      if (el) return el;
    }
    var el2 = document.querySelector("[data-page-root]");
    if (el2) return el2;
    return document.body;
  }

  function h(tag, attrs, children){
    if (!attrs) attrs = {};
    if (!children) children = [];
    var el = document.createElement(tag);
    Object.keys(attrs).forEach(function(k){
      var v = attrs[k];
      if (k === "class") el.className = v;
      else if (k === "style") el.setAttribute("style", v);
      else if (k.indexOf("on") === 0 && typeof v === "function") el.addEventListener(k.slice(2), v);
      else if (v !== undefined && v !== null) el.setAttribute(k, String(v));
    });
    children.forEach(function(c){
      if (c === null || c === undefined) return;
      if (typeof c === "string") el.appendChild(document.createTextNode(c));
      else el.appendChild(c);
    });
    return el;
  }

  function clear(el){
    while (el && el.firstChild) el.removeChild(el.firstChild);
  }

  function _parseJsonOrRaw(text){
    try { return JSON.parse(text); } catch(e){ return { raw: text }; }
  }

  function apiGet(path){
    return fetch(path, { credentials:"include" }).then(function(res){
      return res.text().then(function(text){
        var data = _parseJsonOrRaw(text);
        if (!res.ok){
          var err = new Error("API error");
          err.status = res.status;
          err.data = data;
          throw err;
        }
        return data;
      });
    });
  }

  function apiPost(path, body){
    return fetch(path, {
      method:"POST",
      headers:{ "content-type":"application/json" },
      body: JSON.stringify(body || {}),
      credentials:"include"
    }).then(function(res){
      return res.text().then(function(text){
        var data = _parseJsonOrRaw(text);
        if (!res.ok){
          var err = new Error("API error");
          err.status = res.status;
          err.data = data;
          throw err;
        }
        return data;
      });
    });
  }

  function apiPut(path, body){
    return fetch(path, {
      method:"PUT",
      headers:{ "content-type":"application/json" },
      body: JSON.stringify(body || {}),
      credentials:"include"
    }).then(function(res){
      return res.text().then(function(text){
        var data = _parseJsonOrRaw(text);
        if (!res.ok){
          var err = new Error("API error");
          err.status = res.status;
          err.data = data;
          throw err;
        }
        return data;
      });
    });
  }

  function setHash(hash){
    if (hash && hash.charAt(0) !== "#") hash = "#" + hash;
    window.location.hash = hash || "#";
  }

  window.SERA_P2 = window.SERA_P2 || {};
  window.SERA_P2.common = {
    getRootEl: getRootEl,
    h: h,
    clear: clear,
    apiGet: apiGet,
    apiPost: apiPost,
    apiPut: apiPut,
    setHash: setHash
  };
})();