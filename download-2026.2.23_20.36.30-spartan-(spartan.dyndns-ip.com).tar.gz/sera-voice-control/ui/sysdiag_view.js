(() => {
  // ---- per-script version marker (DEV) ----
  const SCRIPT_VERSION = "ui/sysdiag_view.js@BUNDLE084.1";
  window.__SERA_SCRIPTS = window.__SERA_SCRIPTS || {};
  window.__SERA_SCRIPTS["sysdiag_view.js"] = SCRIPT_VERSION;

  const $ = (id) => document.getElementById(id);

  async function fetchJson(url, opts){
    const r = await fetch(url, Object.assign({ cache:"no-store" }, opts||{}));
    const ct = r.headers.get("content-type")||"";
    const isJson = ct.includes("application/json");
    const body = isJson ? await r.json() : await r.text();
    if(!r.ok) throw new Error(`${url} -> ${r.status}`);
    return body;
  }

  function setStatus(msg){
    const el = $("sysdiagStatus");
    if(el) el.textContent = msg || "";
  }

  async function loadSystem(){
    // Preferred endpoint (via /api -> tool-gateway)
    try{
      const j = await fetchJson("/api/sysdiag/system");
      if(j && j.ok) return j;
    }catch(e){ /* fallback below */ }

    // Fallback: direct public sysdiag route (no /api prefix)
    const j2 = await fetchJson("/sysdiag/system.json");
    if(!j2 || !j2.ok) throw new Error("bad sysdiag");
    return j2;
  }

  async function loadLast(){
    try{
      const j = await fetchJson("/api/sysdiag/last");
      if(j && j.ok) return j.last || null;
    }catch(e){ /* ignore */ }

    // Fallback: try direct public sysdiag last
    try{
      const j2 = await fetchJson("/sysdiag/last");
      if(j2 && j2.ok) return j2.last || null;
    }catch(e){ /* ignore */ }

    return null;
  }

  function renderJson(preId, obj){
    const el = $(preId);
    if(!el) return;
    el.textContent = obj ? JSON.stringify(obj, null, 2) : "(none)";
  }

  async function init(){
    if(!$("sysdiagOut")) return;

    try{
      setStatus("Loading…");
      const system = await loadSystem();
      const last = await loadLast();
      renderJson("sysdiagOut", system);
      renderJson("sysdiagLastOut", last);
      setStatus("Ready");
    }catch(e){
      console.warn("sysdiag init failed", e);
      setStatus("Failed");
    }
  }

  window.addEventListener("DOMContentLoaded", init);
})();