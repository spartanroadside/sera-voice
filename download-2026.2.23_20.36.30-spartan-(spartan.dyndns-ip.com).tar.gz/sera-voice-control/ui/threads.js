(() => {
  // ---- per-script version marker (DEV) ----
  const SCRIPT_VERSION = "ui/threads.js@BUNDLE084.1";
  window.__SERA_SCRIPTS = window.__SERA_SCRIPTS || {};
  window.__SERA_SCRIPTS["threads.js"] = SCRIPT_VERSION;

  const $ = (id) => document.getElementById(id);

  function getActiveProject(){
    try{
      const p = (localStorage.getItem("SERA_ACTIVE_PROJECT")||"").trim();
      return p || "default";
    }catch{ return "default"; }
  }

  function setActiveProject(p){
    try{ localStorage.setItem("SERA_ACTIVE_PROJECT", (p||"").trim()); }catch{}
  }

  async function fetchJson(url, opts){
    const r = await fetch(url, Object.assign({ cache:"no-store" }, opts||{}));
    const ct = r.headers.get("content-type") || "";
    const isJson = ct.includes("application/json");
    const body = isJson ? await r.json() : await r.text();
    if(!r.ok){
      throw new Error(`${url} -> ${r.status}`);
    }
    return body;
  }

  function setStatus(msg){
    const el = $("threadsStatus");
    if(el) el.textContent = msg || "";
  }

  function escapeHtml(s){
    return (s||"").replace(/[&<>"']/g, (m)=>({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;" }[m]));
  }

  async function loadThreads(){
    const listEl = $("threadsList") || $("chatThreadsList");
    if(!listEl) return;

    const projSel = $("threadsProject");
    const proj = (((projSel && (projSel.value||"")) || "").trim() || getActiveProject());
    const limit = parseInt(($("threadsLimit")?.value || "50"), 10) || 50;

    setStatus("Loading…");
    listEl.innerHTML = "<div class='muted'>Loading…</div>";

    try{
      const j = await fetchJson("/api/threads/list", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ project: proj, project_id: proj, limit })
      });

      if(!j || !j.ok){
        throw new Error("threads list failed");
      }

      setActiveProject(proj);
      listEl.innerHTML = "";

      const threads = j.threads || [];
      if(!threads.length){
        listEl.innerHTML = "<div class='muted'>No threads.</div>";
        setStatus("Ready");
        return;
      }

      for(const t of threads){
        const id = t.thread_id || t.id;
        const title = t.title || id;
        const row = document.createElement("div");
        row.className = "threadRow";
        row.innerHTML = `
          <div class="threadTitle">${escapeHtml(title)}</div>
          <div class="threadMeta">${escapeHtml(id || "")}</div>
        `;
        row.addEventListener("click", () => {
          if(window.SERA_CHAT && typeof window.SERA_CHAT.openThread === "function"){
            window.SERA_CHAT.openThread(id);
          }else{
            console.warn("SERA_CHAT.openThread missing");
          }
        });
        listEl.appendChild(row);
      }

      setStatus("Ready");
    }catch(e){
      console.warn("loadThreads failed", e);
      listEl.innerHTML = "<div class='muted'>Failed to load threads.</div>";
      setStatus("Error");
      throw e;
    }
  }

  function init(){
    const btn = $("btnThreadsReload");
    if(btn) btn.addEventListener("click", () => loadThreads().catch(()=>{}));

    // auto-load once
    loadThreads().catch(()=>{});
  }

  window.addEventListener("DOMContentLoaded", init);
  window.__SERA_THREADS = window.__SERA_THREADS || {};
  window.__SERA_THREADS.loadThreads = loadThreads;

})();