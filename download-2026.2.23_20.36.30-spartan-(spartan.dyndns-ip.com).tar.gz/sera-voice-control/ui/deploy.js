async function getBundles(){
  const r = await fetch('/api/bundles/list');
  const j = await r.json();
  const sel = document.getElementById('bundleSelect');
  sel.innerHTML = '';
  const bundles = (j && j.bundles) ? j.bundles : [];
  if(bundles.length===0){
    const o=document.createElement('option'); o.value=''; o.textContent='(no bundles found)';
    sel.appendChild(o);
  } else {
    bundles.forEach(b=>{
      const o=document.createElement('option');
      o.value=b.name;
      o.textContent = `${b.name} (${Math.round((b.bytes||0)/1024)} KB)`;
      sel.appendChild(o);
    });
  }
}

async function apiPost(path, body){
  const r = await fetch(path, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});
  const j = await r.json().catch(()=>({}));
  if(!r.ok) throw new Error((j && (j.error||j.detail)) || ('HTTP '+r.status));
  return j;
}

// This script may be loaded on multiple pages. Only wire UI if elements exist.
document.addEventListener('DOMContentLoaded', ()=>{
  const refreshBtn = document.getElementById('refreshBtn');
  const deployBtn = document.getElementById('deployBtn');
  const outEl = document.getElementById('out');

  if(refreshBtn){
    refreshBtn.addEventListener('click', ()=>getBundles().catch(e=>{ if(outEl) outEl.textContent = String(e); }));
  }
  if(deployBtn){
    deployBtn.addEventListener('click', async ()=>{
      if(outEl) outEl.textContent = '';
      const sel = document.getElementById('bundleSelect');
      const bundle_name = sel ? sel.value : '';
      const project = ((document.getElementById('project')?.value) || 'voice-stage').trim();
      const target_root = ((document.getElementById('targetRoot')?.value) || '/home/spartan/sera/sera-ai/projects').trim();
      if(!bundle_name){ if(outEl) outEl.textContent='Select a bundle first.'; return; }
      try{
        const j = await apiPost('/api/deploy/bundle', { bundle_name, project, target_root });
        if(outEl) outEl.textContent = j.output || JSON.stringify(j,null,2);
      }catch(e){
        if(outEl) outEl.textContent = 'Error: ' + String(e);
      }
    });
  }

  // Only fetch bundles if bundleSelect exists on page
  if(document.getElementById('bundleSelect')){
    getBundles().catch(()=>{});
  }

  // --- Health report viewer (safe no-op if API not present) ---
  const hRefresh = document.getElementById('healthRefresh');
  const hLoad = document.getElementById('healthLoad');
  const hSel = document.getElementById('healthSelect');
  const hOut = document.getElementById('healthOut');

  async function healthList(){
    if(!hSel) return;
    const r = await fetch('/api/debug/health/list', {cache:'no-store'});
    const j = await r.json().catch(()=>({}));
    hSel.innerHTML='';
    const files = (j && j.files) ? j.files : [];
    if(!files.length){
      const o=document.createElement('option'); o.value=''; o.textContent='(no health reports found)';
      hSel.appendChild(o);
      return;
    }
    files.forEach(f=>{
      const o=document.createElement('option');
      o.value=f.name;
      const kb = (f.bytes!=null) ? Math.round((f.bytes||0)/1024) : '?';
      o.textContent=`${f.name} (${kb} KB)`;
      hSel.appendChild(o);
    });
  }

  async function healthRead(){
    if(!hSel || !hOut) return;
    const name = hSel.value;
    if(!name){ hOut.textContent = 'Select a report first.'; return; }
    hOut.textContent = 'Loading…';
    const r = await fetch('/api/debug/health/read?name=' + encodeURIComponent(name), {cache:'no-store'});
    const j = await r.json().catch(()=>({}));
    if(!r.ok){ hOut.textContent = (j && (j.error||j.detail)) || ('HTTP '+r.status); return; }
    hOut.textContent = j.content || '';
  }

  if(hRefresh) hRefresh.addEventListener('click', ()=>healthList().catch(e=>{ if(hOut) hOut.textContent=String(e); }));
  if(hLoad) hLoad.addEventListener('click', ()=>healthRead().catch(e=>{ if(hOut) hOut.textContent=String(e); }));
  if(hSel) healthList().catch(()=>{});
});


function setFooter(text){
  const el = document.getElementById('seraFooter');
  if(el) el.textContent = text;
}
async function updateFooterStatus(){
  try{
    const r = await fetch('/api/status', {cache:'no-store'});
    const j = await r.json();
    const run = j.run || 'UNKNOWN';
    setFooter(`${run} | VG:${j.voice?'ok':'down'} | TG:${j.tool?'ok':'down'} | AR:${j.agent?'ok':'down'}`);
  }catch{
    setFooter('UNKNOWN | status unavailable');
  }
}
updateFooterStatus();
setInterval(updateFooterStatus, 8000);

// --- 1.038: extra deploy controls (safe no-op if API not present) ---
document.addEventListener('DOMContentLoaded', ()=>{
  const byId = (id)=>document.getElementById(id);
  const btnLatest = byId('btnDeployLatest');
  const btnCascade = byId('btnCascade');
  const out = byId('deployOut');

  async function postJson(url, body){
    const r = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body||{}) });
    const t = await r.text();
    try { return JSON.parse(t); } catch { return { raw:t, ok:r.ok, status:r.status }; }
  }

  if(btnLatest){
    btnLatest.addEventListener('click', async ()=>{
      try{
        if(out) out.textContent = 'Deploying latest…';
        const j = await postJson('/api/bundles/deploy_latest', {});
        if(out) out.textContent = JSON.stringify(j, null, 2);
      }catch(e){
        if(out) out.textContent = String(e);
      }
    });
  }

  if(btnCascade){
    btnCascade.addEventListener('click', async ()=>{
      try{
        if(out) out.textContent = 'Starting cascade…';
        const j = await postJson('/api/bundles/cascade', {});
        if(out) out.textContent = JSON.stringify(j, null, 2);
      }catch(e){
        if(out) out.textContent = String(e);
      }
    });
  }
});


async function renderBundleList(){
  const el = document.getElementById("bundleList");
  if (!el) return;
  el.innerHTML = "Loading…";
  try{
    const r = await fetch("/api/bundles/list", {cache:"no-store"});
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || r.status);
    const bundles = j.bundles || [];
    if (!bundles.length){ el.innerHTML = "<div class='muted'>No bundles found in incoming.</div>"; return; }
    el.innerHTML = bundles.map(b=>`<div class="bundleRow"><code>${b}</code></div>`).join("");
  }catch(e){
    el.innerHTML = `<div class='muted'>Bundle list unavailable: ${e}</div>`;
  }
}
document.addEventListener("DOMContentLoaded", () => { setTimeout(renderBundleList, 300); });
