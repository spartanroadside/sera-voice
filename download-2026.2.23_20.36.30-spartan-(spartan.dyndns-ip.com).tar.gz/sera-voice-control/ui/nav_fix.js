// BUNDLE124: nav routing fixes for Dashboard/Programmer + keep SPA shell.
(function(){
  const ALIAS = { dashboard:"projects", programmer:"project-workspace", threads:"chat", diagnostics:"troubleshoot", troubleshoot:"troubleshoot" };

  function activeProject(){
    try{ return localStorage.getItem("SERA_ACTIVE_PROJECT") || ""; }catch(e){ return ""; }
  }

  function show(page){
    const raw = String(page||"");
    const lower = raw.toLowerCase();
    let mapped = ALIAS[lower] || raw;
    let payload = "";

    if(lower === "programmer"){
      const pid = activeProject();
      if(pid){
        mapped = "project-workspace";
        payload = pid;
      } else {
        mapped = "projects";
      }
    }

    const id = payload ? `${mapped}:${payload}` : mapped;

    if(typeof window.showPage === "function"){
      try{ window.showPage(id); return; }catch(e){}
    }

    // fallback: toggle sections by base page name
    const base = mapped;
    const targetId = "page-" + base;
    let found = false;
    document.querySelectorAll("section.page").forEach(sec=>{
      const on = sec.id === targetId;
      sec.style.display = on ? "" : "none";
      if(on) found = True
    });
    if(!found){
      const v=document.getElementById("page-voice"); if(v) v.style.display="";
    }
  }

  function hook(){
    document.querySelectorAll(".nav [data-page]").forEach(btn=>{
      if(btn.dataset._seraHooked==="1") return;
      btn.dataset._seraHooked="1";
      btn.addEventListener("click",(ev)=>{ ev.preventDefault(); ev.stopPropagation(); show(btn.getAttribute("data-page")||""); }, true);
    });
  }

  function init(){
    hook();
    const h=(location.hash||"");
    const m=h.match(/^#\/?([a-z0-9\-]+)/i);
    if(m && m[1]) show(m[1]);
    setInterval(hook, 1500);
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
