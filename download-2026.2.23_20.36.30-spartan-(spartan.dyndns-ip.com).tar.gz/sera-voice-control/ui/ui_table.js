// Simple table renderer (v1) — sorting/filtering handled by caller.
// Keeps dependencies minimal.

(function(){
  function esc(s){
    return String(s ?? '').replace(/[&<>\"']/g, (c)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  window.SeraTable = {
    render: function(tableEl, columns, rows){
      if(!tableEl) return;
      const thead = '<thead><tr>' + columns.map(c=>`<th>${esc(c.label||c.key)}</th>`).join('') + '</tr></thead>';
      const tbody = '<tbody>' + (rows||[]).map(r=>{
        return '<tr>' + columns.map(c=>`<td>${esc(typeof c.value==='function'?c.value(r):r[c.key])}</td>`).join('') + '</tr>';
      }).join('') + '</tbody>';
      tableEl.innerHTML = thead + tbody;
    }
  };
})();
