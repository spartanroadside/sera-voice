// ui/projects_threads.js
// Chat sidebar v2: grouped chats (Connected/Recent/Project/Independent)
//
// Assumptions:
// - "Independent" chats live in project "default".
// - Project chats live in projects other than "default".
// - All chats are threads.
//
// Backend endpoints used:
//   GET  /api/projects/list
//   POST /api/threads/list    { project }
//   POST /api/threads/read    { project, thread_id }
//   POST /api/threads/create  { project, title? }  (optional; fallback to auto thread on /api/chat)
//   GET  /api/projects/current (optional)
//   POST /api/projects/set_current (optional)

(function(){
  const el = (id)=>document.getElementById(id);

  window.SERA_CTX = window.SERA_CTX || { project: 'default', thread_id: '' };

  async function fetchJson(url, opts){
    const r = await fetch(url, { cache:'no-store', ...(opts||{}) });
    const t = await r.text();
    let j; try{ j = t ? JSON.parse(t) : null; }catch{ j = { error:t }; }
    if(!r.ok) throw new Error(j?.error || j?.message || r.statusText);
    return j;
  }

  function setCtx(project, thread_id){
    if(project != null) window.SERA_CTX.project = project;
    if(thread_id != null) window.SERA_CTX.thread_id = thread_id;
    try{ localStorage.setItem('sera_ctx_v1', JSON.stringify(window.SERA_CTX)); }catch{}
    try{ window.dispatchEvent(new CustomEvent('sera:ctx', { detail:{...window.SERA_CTX} })); }catch{}
    renderContext();
  }

  function loadCtx(){
    try{
      const j = JSON.parse(localStorage.getItem('sera_ctx_v1') || '{}');
      if(j && typeof j === 'object'){
        window.SERA_CTX.project = j.project || window.SERA_CTX.project || 'default';
        window.SERA_CTX.thread_id = j.thread_id || '';
      }
    }catch{}
  }

  function renderContext(){
    const line = el('chatContextLine');
    if(!line) return;
    const p = window.SERA_CTX.project || 'default';
    const t = window.SERA_CTX.thread_id ? `thread: ${window.SERA_CTX.thread_id}` : 'thread: (auto)';
    line.textContent = `project: ${p} • ${t}`;
  }

  function normalizeThreads(projectId, list){
    return (list||[]).map(t=>({
      project: projectId,
      id: t.thread_id || t.id || '',
      title: t.title || '(untitled)',
      updated: t.updated_at || t.updated || t.created_at || '',
      archived: !!(t.archived)
    })).filter(x=>x.id);
  }

  function parseUpdated(u){
    // Accept ISO, epoch seconds, epoch ms, or empty
    if(!u) return 0;
    if(typeof u === 'number') return u > 3e12 ? u : (u * 1000);
    const n = Number(u);
    if(!Number.isNaN(n)) return n > 3e12 ? n : (n * 1000);
    const d = Date.parse(u);
    return Number.isFinite(d) ? d : 0;
  }

  async function listProjects(){
    try{
      const j = await fetchJson('/api/projects/list');
      if(Array.isArray(j)) return j.map(x=>typeof x==='string'?x:(x.id||x.project||x.name||'')).filter(Boolean);
      const raw = j?.projects || [];
      return (raw||[]).map(x=>typeof x==='string'?x:(x.id||x.project||x.name||'')).filter(Boolean);
    }catch{
      return ['default'];
    }
  }

  async function listThreadsForProject(project){
    try{
      const j = await fetchJson('/api/threads/list', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ project, project_id: project })
      });
      return normalizeThreads(project, j?.threads || []);
    }catch{
      return [];
    }
  }

  function makeItem(t, active){
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'sideItemV2' + (active ? ' active' : '') + (t.archived ? ' archived' : '');

    const label = document.createElement('span');
    label.className = 'sideLabel';
    label.textContent = t.title;

    const right = document.createElement('span');
    right.className = 'sideRight';

    const meta = document.createElement('span');
    meta.className = 'sideMeta';
    meta.textContent = t.project === 'default' ? 'ind' : 'proj';

    const dots = document.createElement('button');
    dots.type = 'button';
    dots.className = 'ghost iconDots';
    dots.textContent = '⋯';
    dots.title = 'Thread actions';
    dots.addEventListener('click', (ev)=>{
      ev.preventDefault();
      ev.stopPropagation();
      openThreadActions(t);
    });

    right.appendChild(meta);
    right.appendChild(dots);

    b.appendChild(label);
    b.appendChild(right);

    b.title = `${t.project} • ${t.id}`;
    b.addEventListener('click', ()=>selectThread(t.project, t.id));
    return b;
  }

  

  async function openThreadActions(t){
    // Simple prompt-based menu (fast + no UI dependency)
    // r=rename, a=archive toggle, d=delete, p=attach/detach
    const hint = `Actions for: ${t.title}

[r] rename
[a] ${t.archived ? 'unarchive' : 'archive'}
[d] delete
[p] attach/detach to project

Enter letter:`;
    const choice = (window.prompt(hint, '') || '').trim().toLowerCase();
    if(!choice) return;

    try{
      if(choice === 'r'){
        const title = (window.prompt('New thread name:', t.title) || '').trim();
        if(!title) return;
        await fetchJson('/api/threads/rename', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ project: t.project, thread_id: t.id, title })
        });
      }else if(choice === 'a'){
        await fetchJson('/api/threads/archive', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ project: t.project, thread_id: t.id, archived: !t.archived })
        });
      }else if(choice === 'd'){
        if(!window.confirm(`Delete thread "${t.title}"? This cannot be undone.`)) return;
        await fetchJson('/api/threads/delete', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ project: t.project, thread_id: t.id })
        });
        // If we deleted the active thread, clear ctx
        if(window.SERA_CTX.thread_id === t.id && window.SERA_CTX.project === t.project){
          setCtx(t.project, '');
          if(window.SERA_CHAT?.setMessages) window.SERA_CHAT.setMessages([]);
        }
      }else if(choice === 'p'){
        const to = (window.prompt('Attach to project id (blank = default/independent):', (t.project==='default'?'':t.project)) || '').trim();
        const to_project = to || 'default';
        await fetchJson('/api/threads/attach', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ project: t.project, thread_id: t.id, to_project })
        });
        // if moved, update ctx
        if(window.SERA_CTX.thread_id === t.id){
          setCtx(to_project, t.id);
        }
      }
    }catch(e){
      alert('Action failed: ' + (e?.message || e));
    }

    await renderSidebar();
  }
async function renderSidebar(){
    const connectedEl = el('chatConnectedList');
    const recentEl = el('chatRecentList');
    const projEl = el('chatProjectChats');
    const indepEl = el('chatIndependentList');
    if(!connectedEl || !recentEl || !projEl || !indepEl) return;

    const projects = await listProjects();
    if(!projects.includes('default')) projects.unshift('default');

    // Pull threads for each project
    const all = [];
    for(const p of projects){
      const ts = await listThreadsForProject(p);
      all.push(...ts);
    }

    // Connected: placeholder (future)
    connectedEl.innerHTML = '';
    const ph = document.createElement('div');
    ph.className = 'small';
    ph.style.opacity = '0.7';
    ph.textContent = '—';
    connectedEl.appendChild(ph);

    // Recent: top 12 across all projects
    const recent = [...all].sort((a,b)=>parseUpdated(b.updated)-parseUpdated(a.updated)).slice(0,12);
    recentEl.innerHTML = '';
    if(!recent.length){
      const d=document.createElement('div'); d.className='small'; d.style.opacity='0.7'; d.textContent='(none yet)'; recentEl.appendChild(d);
    }else{
      recent.forEach(t=>{
        const active = (t.project === (window.SERA_CTX.project||'default')) && (t.id === (window.SERA_CTX.thread_id||''));
        recentEl.appendChild(makeItem(t, active));
      });
    }

    // Independent = default
    const indep = all.filter(t=>t.project === 'default').sort((a,b)=>parseUpdated(b.updated)-parseUpdated(a.updated));
    indepEl.innerHTML = '';
    if(!indep.length){
      const d=document.createElement('div'); d.className='small'; d.style.opacity='0.7'; d.textContent='(none yet)'; indepEl.appendChild(d);
    }else{
      indep.forEach(t=>{
        const active = (window.SERA_CTX.project||'default')==='default' && (t.id === (window.SERA_CTX.thread_id||''));
        indepEl.appendChild(makeItem(t, active));
      });
    }

    // Project chats grouped
    const byP = {};
    all.filter(t=>t.project !== 'default').forEach(t=>{ (byP[t.project] = byP[t.project] || []).push(t); });
    Object.keys(byP).forEach(p=> byP[p].sort((a,b)=>parseUpdated(b.updated)-parseUpdated(a.updated)));

    projEl.innerHTML = '';
    const ps = Object.keys(byP).sort();
    if(!ps.length){
      const d=document.createElement('div'); d.className='small'; d.style.opacity='0.7'; d.textContent='(none yet)'; projEl.appendChild(d);
    }else{
      ps.forEach(p=>{
        const wrap = document.createElement('div');
        wrap.style.marginBottom = '8px';
        const hdr = document.createElement('div');
        hdr.className = 'small';
        hdr.style.opacity = '.8';
        hdr.style.padding = '4px 2px';
        hdr.textContent = p;
        wrap.appendChild(hdr);
        byP[p].forEach(t=>{
          const active = (p === (window.SERA_CTX.project||'default')) && (t.id === (window.SERA_CTX.thread_id||''));
          wrap.appendChild(makeItem(t, active));
        });
        projEl.appendChild(wrap);
      });
    }

    renderContext();
  }

  async function loadThread(project, thread_id){
    const j = await fetchJson('/api/threads/read', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ project, thread_id, max_lines: 400 })
    });

    const msgs = (j?.messages || []).map(m=>({
      role: m.role || 'assistant',
      text: m.content ?? m.text ?? '',
      ts: m.ts ? (typeof m.ts === 'number' ? m.ts*1000 : Date.parse(m.ts)) : Date.now()
    }));

    if(window.SERA_CHAT && typeof window.SERA_CHAT.setMessages === 'function'){
      window.SERA_CHAT.setMessages(msgs);
    }
  }

  async function selectThread(project, thread_id){
    setCtx(project, thread_id);

    // persist last thread per project
    try{
      const m = JSON.parse(localStorage.getItem('sera_last_thread_v1') || '{}');
      m[project] = thread_id || '';
      localStorage.setItem('sera_last_thread_v1', JSON.stringify(m));
    }catch{}

    if(thread_id){
      try{ await loadThread(project, thread_id); }catch(e){ console.warn('loadThread failed', e); }
    }else{
      if(window.SERA_CHAT && typeof window.SERA_CHAT.clear === 'function') window.SERA_CHAT.clear();
    }

    await renderSidebar();
  }

  async function createThread(project){
    try{
      const j = await fetchJson('/api/threads/create', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ project, title: 'New chat' })
      });
      const tid = j?.thread_id || j?.id || '';
      if(tid){
        await selectThread(project, tid);
        return;
      }
    }catch{
      // fallback below
    }

    // Fallback: clear thread id and let /api/chat create on first send
    await selectThread(project, '');
  }

  function wireTopButtons(){
    const btnNewChat = el('chatNewChat');
    const btnNewProject = el('chatNewProject');
    if(btnNewChat) btnNewChat.addEventListener('click', ()=>createThread(window.SERA_CTX.project || 'default'));
    if(btnNewProject) btnNewProject.addEventListener('click', ()=>{
      // existing UI opens Projects dashboard via router
      try{ window.location.hash = '#/projects'; }catch{ window.location.href = '/#projects'; }
    });

    const attach = el('chatAttach');
    if(attach) attach.addEventListener('click', ()=>alert('Attach is planned next (Sprint 2).'));
  }

  document.addEventListener('DOMContentLoaded', async ()=>{
    loadCtx();
    wireTopButtons();
    renderContext();
    await renderSidebar();

    // If we have a remembered last thread for this project, select it (best-effort)
    try{
      const p = window.SERA_CTX.project || 'default';
      const m = JSON.parse(localStorage.getItem('sera_last_thread_v1') || '{}');
      const last = m[p];
      if(last && !window.SERA_CTX.thread_id){
        setCtx(p, last);
      }
    }catch{}

    // If ctx has a thread, load it
    if(window.SERA_CTX.thread_id){
      try{ await loadThread(window.SERA_CTX.project || 'default', window.SERA_CTX.thread_id); }catch{}
    }
  });
})();
