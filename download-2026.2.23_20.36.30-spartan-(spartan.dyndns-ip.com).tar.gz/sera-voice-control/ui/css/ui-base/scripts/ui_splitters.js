/*
  Resize a 3-column grid with two vertical splitters:
  grid-template-columns: [left] [s] [center] [s] [right]
  We update left/right widths while keeping center flexible.
*/
export function bindWorkbenchSplitters(gridEl, leftSplitterEl, rightSplitterEl){
  const minLeft = 220;
  const minRight = 220;

  const dragX = (splitterEl, which) => {
    let dragging=false, startX=0, startCols=null;

    const readCols = () => {
      const cs = getComputedStyle(gridEl).gridTemplateColumns.split(" ");
      // [0]=left, [2]=center, [4]=right
      return { left: parseFloat(cs[0]), right: parseFloat(cs[4]) };
    };

    const down = (e)=>{
      dragging=true;
      startX = e.clientX;
      startCols = readCols();
      document.body.style.cursor = "col-resize";
      e.preventDefault();
    };

    const move = (e)=>{
      if(!dragging) return;
      const dx = e.clientX - startX;
      let left = startCols.left;
      let right = startCols.right;

      if(which === "left"){
        left = Math.max(minLeft, startCols.left + dx);
      }else{
        right = Math.max(minRight, startCols.right - dx);
      }

      gridEl.style.gridTemplateColumns = `${left}px var(--splitter-hit,10px) minmax(0,1fr) var(--splitter-hit,10px) ${right}px`;
    };

    const up = ()=>{
      dragging=false;
      document.body.style.cursor = "";
    };

    splitterEl.addEventListener("mousedown", down);
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  dragX(leftSplitterEl, "left");
  dragX(rightSplitterEl, "right");
}
