export function ensureToastHost(){
  let host = document.querySelector(".toastHost");
  if(!host){
    host = document.createElement("div");
    host.className = "toastHost";
    document.body.appendChild(host);
  }
  return host;
}

export function toast(title, msg, ms=2800){
  const host = ensureToastHost();
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = `
    <div class="toast__row">
      <div class="toast__title"></div>
      <button class="ghost">✕</button>
    </div>
    <div class="toast__msg"></div>
  `;
  el.querySelector(".toast__title").textContent = title;
  el.querySelector(".toast__msg").textContent = msg;

  el.querySelector("button").addEventListener("click", ()=> el.remove());
  host.appendChild(el);

  setTimeout(()=> el.remove(), ms);
}
