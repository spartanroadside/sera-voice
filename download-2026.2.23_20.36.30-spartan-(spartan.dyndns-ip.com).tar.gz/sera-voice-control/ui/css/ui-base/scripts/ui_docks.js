/*
  Minimal dock/undock:
  - A floating .win can be "docked" into a .dockZone by moving its body into a .dockPanel
  - Keeps it simple: we treat docking as reparenting content.
*/

export function dockWin(winEl, dockZoneEl){
  const body = winEl.querySelector(".win__body");
  const title = winEl.querySelector(".win__title")?.textContent || "Docked";

  // create a dockPanel
  const panel = document.createElement("div");
  panel.className = "dockPanel";
  panel.dataset.fromWin = winEl.id || "";

  const hdr = document.createElement("div");
  hdr.className = "dockPanel__hdr";

  const t = document.createElement("div");
  t.className = "dockPanel__title";
  t.textContent = title;

  const actions = document.createElement("div");
  actions.style.display = "flex";
  actions.style.gap = "8px";

  const undockBtn = document.createElement("button");
  undockBtn.className = "ghost";
  undockBtn.textContent = "Undock";
  undockBtn.addEventListener("click", ()=> undockWin(winEl, panel));

  actions.appendChild(undockBtn);
  hdr.appendChild(t);
  hdr.appendChild(actions);

  const dockBody = document.createElement("div");
  dockBody.className = "dockPanel__body";
  dockBody.appendChild(body);

  panel.appendChild(hdr);
  panel.appendChild(dockBody);

  dockZoneEl.innerHTML = "";
  dockZoneEl.appendChild(panel);

  winEl.classList.add("is-hidden");
}

export function undockWin(winEl, dockPanelEl){
  const dockBody = dockPanelEl.querySelector(".dockPanel__body");
  const body = dockBody?.firstElementChild;
  if(!body) return;

  const winBody = document.createElement("div");
  winBody.className = "win__body";
  winBody.appendChild(body);

  const old = winEl.querySelector(".win__body");
  old?.replaceWith(winBody);

  winEl.classList.remove("is-hidden");
  dockPanelEl.remove();
}
