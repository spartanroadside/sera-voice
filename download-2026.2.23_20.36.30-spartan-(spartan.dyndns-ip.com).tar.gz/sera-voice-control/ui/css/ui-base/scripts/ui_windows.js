let z = 1000;

export function focusWin(win){
  z += 1;
  win.style.zIndex = z;
  document.querySelectorAll(".win.is-focused").forEach(el=>el.classList.remove("is-focused"));
  win.classList.add("is-focused");
}

export function makeDraggable(win, handle){
  let dragging=false, sx=0, sy=0, ox=0, oy=0;

  const down = (e)=>{
    dragging=true;
    focusWin(win);
    const r = win.getBoundingClientRect();
    ox = r.left; oy = r.top;
    sx = e.clientX; sy = e.clientY;
    e.preventDefault();
  };

  const move = (e)=>{
    if(!dragging) return;
    const dx = e.clientX - sx;
    const dy = e.clientY - sy;
    win.style.left = (ox + dx) + "px";
    win.style.top  = (oy + dy) + "px";
  };

  const up = ()=> dragging=false;

  handle.addEventListener("mousedown", down);
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}

export function snapTo(win, where){
  const pad = 12;
  const W = window.innerWidth;
  const H = window.innerHeight;

  win.style.position = "fixed";

  if(where === "right"){
    win.style.left = (W - pad - Math.min(420, W*0.34)) + "px";
    win.style.top = pad + "px";
  }else if(where === "left"){
    win.style.left = pad + "px";
    win.style.top = pad + "px";
  }else if(where === "bottom"){
    win.style.left = pad + "px";
    win.style.top  = (H - pad - Math.min(360, H*0.35)) + "px";
  }
}
