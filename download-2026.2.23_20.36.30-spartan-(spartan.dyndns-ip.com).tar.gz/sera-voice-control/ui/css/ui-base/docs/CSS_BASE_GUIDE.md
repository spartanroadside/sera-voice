# UI Base Guide (Resizable + Dockable + Floating windows)

This package is built to match your existing global tokens in `app.css` (e.g. `--bg`, `--panel`, `--border`, `--text`, `--radius`):contentReference[oaicite:5]{index=5}.

## CSS load order (recommended)
1) app.css
2) scrollbars.css
3) forms.css
4) buttons.css / new-buttons.css
5) utilities.css
6) panels.css
7) splitters.css
8) docks.css
9) windows.css
10) modals.css
11) ide-layout.css
12) page-specific CSS (project_builder.css)

## Concept mapping
- Panels (reusable containers): `.panel`
- Docks (persistent edge zones): `.dockZone` + `.dockPanel`
- Floating windows (detachable AI tools): `.win`
- Modals (blocking dialogs): `.modalOverlay` + `.modalWin`
- Splitters (resizers): `.splitter` + JS that adjusts grid columns

## Workbench skeleton
Use `.workbench__main` with two vertical splitters:
grid-template-columns: left / splitter / center / splitter / right

JS: `bindWorkbenchSplitters(...)` will resize left and right.
