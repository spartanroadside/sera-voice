import re
import uuid
from typing import Dict, Any, Optional, Tuple, List

# SERA Command Framework v1.0 (see SERA_COMMAND_FRAMEWORK_v1.md)
# Parser normalizes user text into an intent object:
# { intent, args, confidence, source }

_CMD_PATTERNS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"^(?:[:/])help\b", re.I), "ui.help"),
    (re.compile(r"^(?:[:/])status(?:\s+(?P<name>[\w@.:-]+))?\b", re.I), "system.status"),
    (re.compile(r"^(?:[:/])doctor\b", re.I), "sysdiag.doctor"),
    (re.compile(r"^(?:[:/])ports\b", re.I), "sysdiag.ports"),
    (re.compile(r"^(?:[:/])logs\s+(?P<service>[\w.-]+)(?:\s+(?P<n>\d+))?\b", re.I), "sysdiag.logs.tail"),
    (re.compile(r"^(?:[:/])bundles\b", re.I), "bundle.list"),
    (re.compile(r"^(?:[:/])new\b", re.I), "chat.thread.create"),
    (re.compile(r"^(?:[:/])export\b", re.I), "chat.thread.export"),
    (re.compile(r"^(?:[:/])list\s+(?P<dir>.+)$", re.I), "fs.dir.list"),
    (re.compile(r"^(?:[:/])open\s+(?P<path>.+)$", re.I), "fs.file.open"),
    (re.compile(r"^(?:[:/])search\s+(?P<pattern>.+)$", re.I), "fs.search"),
    (re.compile(r"^(?:[:/])create\s+file\s+(?P<path>\S+)(?:\s+(?P<content>.*))?$", re.I), "fs.file.create"),
]

def parse_user_input(text: str) -> Dict[str, Any]:
    raw = (text or "").strip()
    if not raw:
        return {"intent": "ui.help", "args": {}, "confidence": 0.2, "source": "verb"}

    # classify
    source = "natural_language"
    if raw.startswith(":"):
        source = "colon"
    elif raw.startswith("/"):
        source = "slash"

    for pat, intent in _CMD_PATTERNS:
        m = pat.match(raw)
        if m:
            args = {k: v for k, v in (m.groupdict() or {}).items() if v is not None}
            # normalize
            if "n" in args:
                try: args["n"] = int(args["n"])
                except Exception: pass
            return {"intent": intent, "args": args, "confidence": 0.98, "source": source}

    # verb form (no : or /)
    if re.match(r"^(help|status|doctor|ports|bundles|new|export)\b", raw, re.I):
        # re-run with virtual colon to reuse patterns
        return parse_user_input(":" + raw)

    return {"intent": "agent.plan_only", "args": {"text": raw}, "confidence": 0.35, "source": "natural_language"}

def new_confirm_token() -> str:
    return "c_" + uuid.uuid4().hex
