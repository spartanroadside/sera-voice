from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from agent.core.config import settings


class SessionContextMiddleware(BaseHTTPMiddleware):
    """Parse session id from headers.

    - Accepts header: x-session-id
    - Stores on request.state.session_id
    - Does not enforce validity yet (handled by endpoints / logic)
    """

    async def dispatch(self, request: Request, call_next):
        session_id = request.headers.get("x-session-id")
        if session_id:
            request.state.session_id = session_id.strip()
        else:
            request.state.session_id = None

        # Hard gate for environments that require a session id
        if settings.REQUIRE_SESSION and request.url.path.startswith("/api/"):
            if request.url.path.startswith("/api/session/"):
                # allow create/validate without an existing session header
                pass
            elif not request.state.session_id:
                # Return early (manual Response to avoid circular import with envelope)
                return Response(
                    content='{"status":"error","code":"UNAUTHORIZED","message":"Missing x-session-id","trace_id":"' + getattr(request.state, "trace_id", "") + '","run_id":null,"data":{}}',
                    status_code=401,
                    media_type="application/json",
                )

        response: Response = await call_next(request)
        if request.state.session_id:
            response.headers.setdefault("x-session-id", request.state.session_id)
        return response
