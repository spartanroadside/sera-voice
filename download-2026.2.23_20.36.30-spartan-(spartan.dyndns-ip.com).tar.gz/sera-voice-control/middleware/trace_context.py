from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from agent.core.trace import ensure_trace_id


class TraceContextMiddleware(BaseHTTPMiddleware):
    """Ensure each request has a trace id and echo it in response headers."""

    async def dispatch(self, request: Request, call_next):
        trace_id = ensure_trace_id(request.headers.get("x-trace-id"))
        request.state.trace_id = trace_id

        response: Response = await call_next(request)
        response.headers.setdefault("x-trace-id", trace_id)
        return response
