import os
from fastapi import APIRouter

from agent.core.envelope import ok, err

try:
    from agent.db.migrate import current_version, apply_all
except Exception:
    current_version = None
    apply_all = None

router = APIRouter()


@router.get("/api/db/status")
def db_status():
    if current_version is None:
        return err("DB_NOT_AVAILABLE", "Database module not available", data={})
    try:
        return ok({"backend": os.getenv("SERA_DB_BACKEND", "sqlite"), "version": current_version()})
    except Exception as e:
        return err("DB_STATUS_FAILED", str(e), data={})


@router.post("/api/db/migrate")
def db_migrate():
    # Dev-only: only enabled if explicitly allowed.
    if os.getenv("SERA_DB_ALLOW_HTTP_MIGRATE", "0") != "1":
        return err("FORBIDDEN", "HTTP migrate is disabled", data={"hint": "Set SERA_DB_ALLOW_HTTP_MIGRATE=1"})
    if apply_all is None:
        return err("DB_NOT_AVAILABLE", "Database module not available", data={})
    try:
        applied = apply_all()
        return ok({"applied": applied, "version": current_version()})
    except Exception as e:
        return err("DB_MIGRATION_FAILED", str(e), data={})
