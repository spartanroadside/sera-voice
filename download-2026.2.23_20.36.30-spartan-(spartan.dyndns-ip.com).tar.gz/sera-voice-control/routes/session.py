from __future__ import annotations

import time
import uuid
from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from agent.core.envelope import ok, error
from agent.core.trace import trace_header
from agent.db.connection import db


router = APIRouter(prefix="/api/session", tags=["session"])


class CreateSessionReq(BaseModel):
    label: Optional[str] = None


@router.post("/create")
def create_session(req: CreateSessionReq, trace_id: str = Depends(trace_header)):
    session_id = str(uuid.uuid4())
    now = int(time.time())
    with db() as conn:
        conn.execute(
            "INSERT INTO sessions (id, created_at, last_seen_at, label) VALUES (?, ?, ?, ?)",
            (session_id, now, now, req.label),
        )
    return ok({"session_id": session_id, "created_at": now, "label": req.label}, trace_id=trace_id)


class ValidateSessionReq(BaseModel):
    session_id: str


@router.post("/validate")
def validate_session(req: ValidateSessionReq, trace_id: str = Depends(trace_header)):
    sid = (req.session_id or "").strip()
    if not sid:
        return error(code="BAD_REQUEST", message="session_id is required", trace_id=trace_id)

    now = int(time.time())
    with db() as conn:
        row = conn.execute("SELECT id, created_at, last_seen_at, label FROM sessions WHERE id = ?", (sid,)).fetchone()
        if not row:
            return error(code="NOT_FOUND", message="Session not found", trace_id=trace_id)
        conn.execute("UPDATE sessions SET last_seen_at = ? WHERE id = ?", (now, sid))

    return ok(
        {
            "session_id": row["id"],
            "created_at": row["created_at"],
            "last_seen_at": now,
            "label": row["label"],
            "valid": True,
        },
        trace_id=trace_id,
    )
