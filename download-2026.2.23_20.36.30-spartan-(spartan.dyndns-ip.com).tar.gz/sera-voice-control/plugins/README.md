# Plugins

Plugins are optional modules that can be enabled by the user. Default is **disabled**.

A plugin folder contains:
- `plugin.json` manifest
- docs under `docs/plugins/...`

Future: UI to enable/disable plugins and store required secrets.
