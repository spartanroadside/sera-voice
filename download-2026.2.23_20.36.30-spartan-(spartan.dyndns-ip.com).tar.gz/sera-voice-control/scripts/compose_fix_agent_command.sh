#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${SERA_APP_DIR:-/home/spartan/sera/sera-ai/sera-voice-control}"
COMPOSE="$APP_DIR/docker-compose.yml"
[[ -f "$COMPOSE" ]] || { echo "ERROR: $COMPOSE not found" >&2; exit 1; }

ts="$(date +%Y%m%d_%H%M%S)"
cp -a "$COMPOSE" "$COMPOSE.bak_cmd_$ts"

python3 - <<'PY' "$COMPOSE"
import sys, yaml
from pathlib import Path

p = Path(sys.argv[1])
doc = yaml.safe_load(p.read_text())
svc = doc.get("services", {}).get("agent-runner")
if not svc:
    raise SystemExit("agent-runner service not found in compose")

# Force command to run correct app
svc["command"] = ["uvicorn","agent.app:app","--host","0.0.0.0","--port","3200"]
p.write_text(yaml.safe_dump(doc, sort_keys=False))
print("OK: set agent-runner command to uvicorn agent.app:app")
PY

echo "Backup saved to: $COMPOSE.bak_cmd_$ts"
