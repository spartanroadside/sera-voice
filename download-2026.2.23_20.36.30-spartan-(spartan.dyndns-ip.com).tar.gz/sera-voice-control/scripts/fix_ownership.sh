#!/usr/bin/env bash
set -euo pipefail
USER_NAME="${1:-spartan}"
if ! id "$USER_NAME" >/dev/null 2>&1; then
  echo "ERROR: user '$USER_NAME' not found" >&2
  exit 2
fi
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
uid=$(id -u "$USER_NAME")
gid=$(id -g "$USER_NAME")

echo "Fixing ownership under: $ROOT_DIR -> ${USER_NAME} (${uid}:${gid})"
chown -R "$uid:$gid" "$ROOT_DIR"

echo "Done. Root-owned files now (should be empty):"
find "$ROOT_DIR" -xdev -uid 0 -print | head || true
