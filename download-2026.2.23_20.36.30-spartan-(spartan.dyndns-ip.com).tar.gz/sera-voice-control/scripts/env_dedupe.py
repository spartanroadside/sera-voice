#!/usr/bin/env python3
"""
Deduplicate .env-style files while preserving the LAST value for any key.

Usage:
  python3 scripts/env_dedupe.py /path/to/.env

It will:
- keep comments / blank lines
- for KEY=VALUE lines, ensure only the last occurrence remains
- write back in-place (creates .bak)
"""
from __future__ import annotations
import sys, re, shutil, pathlib

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: env_dedupe.py /path/to/.env", file=sys.stderr)
        return 2
    p = pathlib.Path(sys.argv[1])
    if not p.exists():
        print(f"not found: {p}", file=sys.stderr)
        return 2

    lines = p.read_text().splitlines(True)

    key_re = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)=')
    # identify last occurrence index per key
    last = {}
    for i, line in enumerate(lines):
        m = key_re.match(line)
        if m:
            last[m.group(1)] = i

    out = []
    for i, line in enumerate(lines):
        m = key_re.match(line)
        if not m:
            out.append(line)
            continue
        key = m.group(1)
        if last.get(key) == i:
            out.append(line)

    bak = p.with_suffix(p.suffix + ".bak")
    shutil.copy2(p, bak)
    p.write_text("".join(out))
    print(f"Wrote {p} (backup: {bak})")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
