#!/usr/bin/env bash
set -euo pipefail

# Enable Home Assistant via docker-compose.ha.yml
#
# Run from the project install directory.
# Example:
#   cd /home/spartan/sera/sera-ai/projects/voice
#   ./scripts/enable_ha.sh voice

PROJECT="${1:-${COMPOSE_PROJECT:-sera-voice-control}}"
WORKSPACE_DIR="${WORKSPACE_DIR:-/home/spartan/sera/sera-ai/workspaces/${PROJECT}}"
HA_CONFIG_DIR="${HA_CONFIG_DIR:-${WORKSPACE_DIR}/ha/config}"

mkdir -p "${HA_CONFIG_DIR}"

echo "Starting Home Assistant (project=${PROJECT})"
echo "HA config dir: ${HA_CONFIG_DIR}"
echo

docker compose -p "${PROJECT}" -f docker-compose.yml -f docker-compose.ha.yml up -d homeassistant
docker ps --filter "name=homeassistant" || true

echo
echo "Home Assistant should be available on http://127.0.0.1:8123"
