#!/usr/bin/env bash
set -euo pipefail

# Convenience wrapper so the path is easy to remember.
exec "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/smoke_tests/run_smoke_tests.sh" "$@"
