#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${SERA_APP_DIR:-/home/spartan/sera/sera-ai/sera-voice-control}"
cd "$APP_DIR"

export DB_TYPE="${DB_TYPE:-sqlite}"
export DB_PATH="${DB_PATH:-/home/spartan/sera/sera-ai/data/sera.db}"

python3 - <<'PY'
import os
from agent.db import get_db

db = get_db()
print("OK: DB initialized")
print("DB_TYPE =", os.getenv("DB_TYPE"))
print("DB_PATH =", os.getenv("DB_PATH"))
PY
