#!/usr/bin/env bash
set -euo pipefail

# Build a clean bundle of the current repo directory.
# Output:   $SERA_ROOT/outgoing
# Manifest: $SERA_ROOT/backups/_manifests

log(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"          # repo root
SERA_ROOT="${SERA_ROOT:-/home/spartan/sera/sera-ai}"             # program root
PROJECT_DIR="$HERE"                                              # what we bundle
TOPDIR_NAME="$(basename "$HERE")"                                # should be sera-voice-control

OUTDIR="$SERA_ROOT/outgoing"
MANIFEST_DIR="$SERA_ROOT/backups/_manifests"
TS="$(date +%Y-%m-%d_%H%M%S)"

mkdir -p "$OUTDIR" "$MANIFEST_DIR"

OUT="$OUTDIR/${TOPDIR_NAME}_${TS}.tar.gz"
SHA="${OUT}.sha256"
MANIFEST="$MANIFEST_DIR/manifest_${TOPDIR_NAME}_${TS}.tsv"
META="$MANIFEST_DIR/manifest_${TOPDIR_NAME}_${TS}.meta"

log "=== Make bundle start: $TS ==="
log "Repo:      $PROJECT_DIR"
log "Topdir:    $TOPDIR_NAME"
log "Output:    $OUT"
log "Manifest:  $MANIFEST"
log

[[ -d "$PROJECT_DIR" ]] || die "Project dir not found: $PROJECT_DIR"

# Ensure VERSION exists (installer/dashboard depends on it)
if [[ ! -f "$PROJECT_DIR/VERSION" ]]; then
  die "VERSION missing at $PROJECT_DIR/VERSION (create it before bundling)"
fi

# Build manifest (exact snapshot of included files)
find "$PROJECT_DIR" \
  \( -path "*/.git/*" -o -path "*/node_modules/*" -o -path "*/__pycache__/*" \) -prune -o \
  -type f \
  \( -name ".env" -o -name "*.pem" -o -name "*.key" -o -name "*.p12" -o -name "*.pfx" \) -prune -o \
  -printf "%s\t%TY-%Tm-%Td %TH:%TM:%TS\t%p\n" \
  | sort -k3 > "$MANIFEST"

{
  echo "timestamp=$TS"
  echo "host=$(hostname)"
  echo "repo=$PROJECT_DIR"
  echo "bundle=$OUT"
  echo "manifest=$MANIFEST"
  echo "version=$(head -n1 "$PROJECT_DIR/VERSION" | tr -d '[:space:]')"
} > "$META"

# Create bundle with correct top-level dir name
tar -czf "$OUT" \
  --exclude='**/.git' \
  --exclude='**/node_modules' \
  --exclude='**/__pycache__' \
  --exclude='**/.env' \
  --exclude='**/*.pem' \
  --exclude='**/*.key' \
  --exclude='**/*.p12' \
  --exclude='**/*.pfx' \
  -C "$(dirname "$PROJECT_DIR")" "$TOPDIR_NAME"

# Verify top-level directory
TOP="$(tar -tzf "$OUT" | head -n 1 | cut -d/ -f1)"
[[ "$TOP" == "$TOPDIR_NAME" ]] || die "Bundle top-level dir is '$TOP' (expected '$TOPDIR_NAME')"

sha256sum "$OUT" > "$SHA"

log
log "Bundle created:"
ls -lah "$OUT" "$SHA"
log
log "Manifests created:"
ls -lah "$MANIFEST" "$META"
log "=== Make bundle complete: $TS ==="
