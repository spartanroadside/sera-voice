#!/usr/bin/env bash
set -euo pipefail
# 1.070A helper: fix .env perms, start stack, verify, and (re)apply stable proxy if needed.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "== Fixing .env permissions (required for docker compose)"
if [[ -f ".env" ]]; then
  sudo chown "${USER}:${USER}" .env || true
  sudo chmod 640 .env || true
fi

echo "== Bringing stack up"
docker compose up -d

echo "== Quick status"
docker compose ps

echo "== Smoke tests (HTTP)"
curl -fsS http://127.0.0.1:8080/__ping >/dev/null && echo "OK: __ping"

echo "== Optional: apply stable caddyfile via updater"
if [[ -x tools/proxy/update_caddyfile.sh && -f caddy/Caddyfile.devstable ]]; then
  tools/proxy/update_caddyfile.sh caddy/Caddyfile.devstable || true
fi

echo "Done."
