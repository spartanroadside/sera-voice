#!/usr/bin/env bash
set -euo pipefail
echo "Placeholder: migrations not implemented yet."
echo "For now, schema is created automatically by SQLiteAdapter.init_schema()."
