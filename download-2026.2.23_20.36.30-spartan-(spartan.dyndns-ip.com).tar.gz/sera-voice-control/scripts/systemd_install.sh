#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${SERA_APP_DIR:-/home/spartan/sera/sera-ai/sera-voice-control}"
UNIT_SRC="$APP_DIR/scripts/systemd/sera-voice-control.service"
UNIT_DST="/etc/systemd/system/sera-voice-control.service"

if [[ ! -f "$UNIT_SRC" ]]; then
  echo "ERROR: unit file not found: $UNIT_SRC" >&2
  exit 1
fi

sudo cp -f "$UNIT_SRC" "$UNIT_DST"
sudo systemctl daemon-reload
sudo systemctl enable --now sera-voice-control.service

echo "OK: enabled and started sera-voice-control.service"
sudo systemctl --no-pager status sera-voice-control.service | sed -n '1,25p' || true
