#!/usr/bin/env bash
set -euo pipefail
# Trust Caddy internal TLS root CA so curl/apt/etc can verify https://sera.lan:8443
# Usage: sudo ./scripts/trust_caddy_internal_ca.sh

ROOT="/home/spartan/sera/sera-ai/sera-voice-control"
CRT1="$ROOT/ui/caddy-root.crt"
CRT2="$ROOT/ui/tls/root.crt"

CRT=""
if [[ -f "$CRT1" ]]; then CRT="$CRT1"; fi
if [[ -z "$CRT" && -f "$CRT2" ]]; then CRT="$CRT2"; fi

if [[ -z "$CRT" ]]; then
  echo "ERROR: Could not find caddy root cert at $CRT1 or $CRT2"
  exit 1
fi

DEST="/usr/local/share/ca-certificates/sera-caddy-internal.crt"
cp "$CRT" "$DEST"
update-ca-certificates
echo "OK: Installed CA cert to $DEST"
