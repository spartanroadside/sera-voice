#!/usr/bin/env bash
set -euo pipefail

# SERA Installer v5 (Fresh | Update | Patch) with robust menu + backups + env merge
#
# Requirements implemented:
# - Bundles pulled from: /home/spartan/sera/sera-ai/incoming (configurable via SERA_INCOMING)
# - Launched from:       /home/spartan/sera/sera-ai/sera-voice-control/./install.sh
# - Interactive menu (reads from /dev/tty to avoid stdin weirdness)
# - Backup existing install BEFORE changes (offer: Backup only, Backup+Deploy)
# - Fresh install: wipe target dir so only bundle content remains (clean install)
# - Update: backup then overwrite install with bundle (keeps env tail lines)
# - Patch: overlay only files in patch bundle; does NOT delete other files
# - env handling:
#     - Backup existing env file
#     - After deploy, restore env by:
#         first 6 lines = from NEW env (version data)
#         lines 7+      = from OLD env (preserves local settings)
# - Quick install vs install with tests (verify + health)
#
# Notes:
# - FULL bundles should contain top-level folder: sera-voice-control/...
# - PATCH bundles should also contain top-level folder with only changed files.
#
# Env vars:
#   SERA_ROOT=/home/spartan/sera/sera-ai
#   SERA_PROJECT=sera-voice-control
#   SERA_INCOMING=/home/spartan/sera/sera-ai/incoming
#   SERA_TARGET_ROOT=/home/spartan/sera/sera-ai
#   SERA_BACKUP_DIR=/home/spartan/sera/sera-ai/backups
#   SERA_NO_RESTART=1
#   SERA_SKIP_TESTS=1
#
# CLI:
#   install.sh --menu
#   install.sh --fresh --bundle /path/to/FULL.tar.gz
#   install.sh --update --bundle /path/to/FULL.tar.gz
#   install.sh --patch  --bundle /path/to/PATCH.tar.gz

log(){ local lvl="${1:-INFO}"; shift || true; printf '%s [%s] %s\n' "$(date +'%Y-%m-%d %H:%M:%S')" "$lvl" "$*"; }
die(){ log ERROR "$*"; exit 1; }
warn(){ log WARN "$*"; }

need_cmd(){ command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"; }

ROOT="${SERA_ROOT:-/home/spartan/sera/sera-ai}"
PROJECT="${SERA_PROJECT:-sera-voice-control}"
INCOMING="${SERA_INCOMING:-$ROOT/incoming}"
TARGET_ROOT="${SERA_TARGET_ROOT:-$ROOT}"
APP_DIR="$TARGET_ROOT/$PROJECT"
BACKUP_DIR="${SERA_BACKUP_DIR:-$ROOT/backups}"

SNAPSHOT_SH_APP="$APP_DIR/tools/sera_snapshot.sh"
SNAPSHOT_SH_ROOT="$ROOT/tools/sera_snapshot.sh"
SNAPSHOT_SH=""

VERIFY_SH_APP="$APP_DIR/tools/verify_install.sh"
VERIFY_SH_ROOT="$ROOT/tools/verify_install.sh"
VERIFY_SH=""

# Health endpoints (adjust as needed)
HEALTH_URLS=(
  "http://127.0.0.1:3000/health"
  "http://127.0.0.1:3100/health"
  "http://127.0.0.1:3200/health"
  "http://127.0.0.1:8080/__ping"
)

# ---------- TTY-safe input ----------
TTY_IN=""
if [[ -r /dev/tty ]]; then TTY_IN="/dev/tty"; fi
is_interactive(){ [[ -n "$TTY_IN" ]] && [[ -t 0 ]] && [[ -t 1 ]]; }

read_choice(){
  local dflt="${1:-}"
  local ans=""
  if [[ -n "$TTY_IN" ]]; then
    IFS= read -r ans < "$TTY_IN" || true
  else
    IFS= read -r ans || true
  fi
  [[ -n "$ans" ]] || ans="$dflt"
  printf "%s" "$ans"
}

prompt(){
  local msg="$1" dflt="${2:-}"
  if ! is_interactive; then
    printf "%s" "$dflt"; return 0
  fi
  printf "%s" "$msg" > "$TTY_IN"
  read_choice "$dflt"
}

pause(){
  is_interactive || return 0
  printf "%s" "Press ENTER to continue..." > "$TTY_IN"
  IFS= read -r _ < "$TTY_IN" || true
}

# ---------- tools ----------
select_snapshot_sh(){
  if [[ -x "$SNAPSHOT_SH_APP" ]]; then SNAPSHOT_SH="$SNAPSHOT_SH_APP"
  elif [[ -x "$SNAPSHOT_SH_ROOT" ]]; then SNAPSHOT_SH="$SNAPSHOT_SH_ROOT"
  else SNAPSHOT_SH=""
  fi
  [[ -n "$SNAPSHOT_SH" ]] && log INFO "Using snapshot tool: $SNAPSHOT_SH" || warn "Snapshot tool not found; will use tar backups"
}

select_verify_sh(){
  if [[ -x "$VERIFY_SH_APP" ]]; then VERIFY_SH="$VERIFY_SH_APP"
  elif [[ -x "$VERIFY_SH_ROOT" ]]; then VERIFY_SH="$VERIFY_SH_ROOT"
  else VERIFY_SH=""
  fi
  [[ -n "$VERIFY_SH" ]] && log INFO "Using verify tool: $VERIFY_SH" || warn "Verify tool not found; verification skipped"
}

# ---------- bundle helpers ----------
is_full_bundle(){ [[ "$(basename "$1")" =~ _BUNDLE[0-9]{3}.*_FULL.*\.tar\.gz$ ]] || [[ "$(basename "$1")" =~ _FULL.*\.tar\.gz$ ]]; }
is_patch_bundle(){ [[ "$(basename "$1")" =~ _BUNDLE[0-9]{3}.*_PATCH.*\.tar\.gz$ ]] || [[ "$(basename "$1")" =~ _PATCH.*\.tar\.gz$ ]]; }

bundle_number(){
  local b; b="$(basename "$1")"
  if [[ "$b" =~ _BUNDLE([0-9]{3}) ]]; then printf '%d' "${BASH_REMATCH[1]#0}"
  else printf '%d' -1
  fi
}

find_latest(){
  local kind="$1" best="" best_n=-1 f n
  shopt -s nullglob
  for f in "$INCOMING"/*.tar.gz; do
    case "$kind" in
      full)  is_full_bundle "$f" || continue ;;
      patch) is_patch_bundle "$f" || continue ;;
      *) die "internal: unknown kind=$kind" ;;
    esac
    n="$(bundle_number "$f")"
    if (( n > best_n )); then best_n="$n"; best="$f"; fi
  done
  shopt -u nullglob
  [[ -n "$best" ]] || die "No ${kind^^} bundles found in: $INCOMING"
  printf '%s' "$best"
}

list_bundles(){
  mkdir -p "$INCOMING"
  shopt -s nullglob
  local arr=("$INCOMING"/*.tar.gz)
  shopt -u nullglob
  ((${#arr[@]})) || { echo "(no bundles found)"; return 0; }
  local i=1
  for f in "${arr[@]}"; do
    local tag="OTHER"
    is_full_bundle "$f" && tag="FULL"
    is_patch_bundle "$f" && tag="PATCH"
    printf '%2d) [%s] %s\n' "$i" "$tag" "$(basename "$f")"
    ((i++))
  done
}

pick_bundle(){
  mkdir -p "$INCOMING"
  shopt -s nullglob
  local arr=("$INCOMING"/*.tar.gz)
  shopt -u nullglob
  ((${#arr[@]})) || die "No .tar.gz bundles found in: $INCOMING"

  echo
  echo "Available bundles in: $INCOMING"
  local i=1
  for f in "${arr[@]}"; do
    local tag="OTHER"
    is_full_bundle "$f" && tag="FULL"
    is_patch_bundle "$f" && tag="PATCH"
    printf '%2d) [%s] %s\n' "$i" "$tag" "$(basename "$f")"
    ((i++))
  done

  printf "%s" $'\nPick bundle number: ' > "$TTY_IN"
  local choice; choice="$(read_choice "1")"
  [[ "$choice" =~ ^[0-9]+$ ]] || die "Invalid selection."
  (( choice >= 1 && choice <= ${#arr[@]} )) || die "Selection out of range."
  printf '%s' "${arr[$((choice-1))]}"
}

verify_sha(){
  local bundle="$1" sha="${bundle}.sha256"
  if [[ -f "$sha" ]]; then
    log INFO "Verifying sha256: $(basename "$sha")"
    (cd "$(dirname "$bundle")" && sha256sum -c "$(basename "$sha")") || die "SHA256 verification failed: $bundle"
  else
    warn "No sha256 sidecar found (ok): $(basename "$bundle")"
  fi
}

# ---------- backups ----------
backup_tar(){
  mkdir -p "$BACKUP_DIR"
  local ts; ts="$(date +%Y-%m-%d_%H%M%S)"
  local out="$BACKUP_DIR/${PROJECT}_backup_${ts}.tar.gz"
  log INFO "Creating tar backup: $out"
  tar -czf "$out" -C "$TARGET_ROOT" "$PROJECT"
  log INFO "Backup complete."
}

backup_snapshot(){
  [[ -n "${SNAPSHOT_SH:-}" ]] || return 1
  log INFO "Creating installable snapshot..."
  (SERA_ROOT="$ROOT" SERA_PROJECT="$PROJECT" bash "$SNAPSHOT_SH" installable)
}

backup_now(){
  if [[ -d "$APP_DIR" ]]; then
    if backup_snapshot; then
      : # snapshot ok
    else
      backup_tar
    fi
  else
    warn "No existing install at $APP_DIR (skipping backup)"
  fi
}

# ---------- env merge ----------
ENV_PATH="$APP_DIR/env"

save_env_copy(){
  local label="$1"
  [[ -f "$ENV_PATH" ]] || return 0
  mkdir -p "$BACKUP_DIR/env"
  local ts; ts="$(date +%Y-%m-%d_%H%M%S)"
  cp -a "$ENV_PATH" "$BACKUP_DIR/env/${PROJECT}_env_${label}_${ts}"
  log INFO "Backed up env -> $BACKUP_DIR/env/${PROJECT}_env_${label}_${ts}"
}

merge_env_after_deploy(){
  # Rule:
  # - Take first 6 lines from NEW env (from bundle)
  # - Take lines 7+ from OLD env (pre-deploy)
  local old_env_tmp="$1"
  local new_env="$ENV_PATH"

  [[ -f "$new_env" ]] || { warn "No new env found at $new_env (skip merge)"; return 0; }
  [[ -f "$old_env_tmp" ]] || { warn "No old env temp found (skip merge)"; return 0; }

  local tmp; tmp="$(mktemp)"
  head -n 6 "$new_env" > "$tmp" || true
  tail -n +7 "$old_env_tmp" >> "$tmp" || true
  cp -f "$tmp" "$new_env"
  rm -f "$tmp"
  log INFO "Merged env: new lines 1-6 + old lines 7+"
}

# ---------- deploy helpers ----------
restart_services(){
  [[ "${SERA_NO_RESTART:-0}" == "1" ]] && { warn "SERA_NO_RESTART=1 (skipping restart)"; return 0; }
  [[ -f "$APP_DIR/docker-compose.yml" ]] || { warn "No docker-compose.yml in $APP_DIR (skipping restart)"; return 0; }
  need_cmd docker
  log INFO "Restarting services via docker compose..."
  (cd "$APP_DIR" && docker compose -p "$PROJECT" up -d --remove-orphans) || die "docker compose up failed"
}

curl_ok(){ curl -fsS --max-time 3 "$1" >/dev/null 2>&1; }

health_check(){
  need_cmd curl
  local fail=0 url
  for url in "${HEALTH_URLS[@]}"; do
    if curl_ok "$url"; then log INFO "HEALTH OK: $url"
    else log WARN "HEALTH FAIL: $url"; fail=1
    fi
  done
  return "$fail"
}

run_tests(){
  [[ "${SERA_SKIP_TESTS:-0}" == "1" ]] && { warn "SERA_SKIP_TESTS=1 (skipping tests)"; return 0; }
  if [[ -n "${VERIFY_SH:-}" ]]; then
    log INFO "Running verify_install..."
    (bash "$VERIFY_SH" "$APP_DIR" "${1:-}") || die "verify_install failed"
  fi
  log INFO "Running health checks..."
  health_check || die "Health check failed"
}

# ---------- extract + sync ----------
stage_extract(){
  local bundle="$1"
  need_cmd tar
  local ts; ts="$(date +%Y-%m-%d_%H%M%S)"
  local stage="$ROOT/debug/tmp/install_stage_${PROJECT}_${ts}"
  mkdir -p "$stage"
  log INFO "Extracting bundle to: $stage"
  tar -xzf "$bundle" -C "$stage"
  [[ -d "$stage/$PROJECT" ]] || die "Bundle must contain top-level directory '$PROJECT/'"
  printf '%s' "$stage"
}

sync_full_replace(){
  # rsync bundle contents into APP_DIR with --delete (clean target)
  local src="$1"   # stage/$PROJECT
  local old_env_tmp="$2"

  mkdir -p "$APP_DIR"

  # Keep env during rsync; we'll merge afterwards
  local rsync_excludes=(--exclude "/env")
  # You may add more excludes here if needed (logs, data, etc.)
  # rsync_excludes+=(--exclude "/logs" --exclude "/data")

  if command -v rsync >/dev/null 2>&1; then
    rsync -a --delete "${rsync_excludes[@]}" "$src"/ "$APP_DIR"/
  else
    warn "rsync not found; using tar streaming (still deletes by wipe on fresh only)"
    # For update without rsync, we cannot reliably delete; we do a best-effort copy.
    (cd "$src" && tar -cf - .) | (cd "$APP_DIR" && tar -xf -)
  fi

  # Restore env: merge new header + old tail
  merge_env_after_deploy "$old_env_tmp"
}

sync_patch_overlay(){
  # rsync overlay WITHOUT --delete (patch only touches included files)
  local src="$1"
  if command -v rsync >/dev/null 2>&1; then
    rsync -a "$src"/ "$APP_DIR"/
  else
    (cd "$src" && tar -cf - .) | (cd "$APP_DIR" && tar -xf -)
  fi
}

# ---------- operations ----------
fresh_install(){
  local bundle="$1" with_tests="$2"
  is_full_bundle "$bundle" || warn "Bundle doesn't look like FULL; continuing anyway"
  verify_sha "$bundle"

  log INFO "Fresh install selected."

  # Backup existing (if any)
  backup_now
  save_env_copy "pre"

  local old_env_tmp=""
  if [[ -f "$ENV_PATH" ]]; then
    old_env_tmp="$(mktemp)"
    cp -a "$ENV_PATH" "$old_env_tmp"
  fi

  # Wipe directory completely to ensure clean install
  if [[ -d "$APP_DIR" ]]; then
    log WARN "WIPING install dir for fresh install: $APP_DIR"
    rm -rf "$APP_DIR"
  fi
  mkdir -p "$APP_DIR"

  local stage; stage="$(stage_extract "$bundle")"
  sync_full_replace "$stage/$PROJECT" "${old_env_tmp:-/dev/null}"
  rm -rf "$stage" || true
  [[ -n "$old_env_tmp" ]] && rm -f "$old_env_tmp" || true

  restart_services
  [[ "$with_tests" == "1" ]] && run_tests "$bundle" || true
  log INFO "Fresh install complete."
}

update_install(){
  local bundle="$1" with_tests="$2"
  is_full_bundle "$bundle" || warn "Bundle doesn't look like FULL; continuing anyway"
  verify_sha "$bundle"

  [[ -d "$APP_DIR" ]] || warn "No existing install found; update will behave like install."

  backup_now
  save_env_copy "pre"

  local old_env_tmp=""
  if [[ -f "$ENV_PATH" ]]; then
    old_env_tmp="$(mktemp)"
    cp -a "$ENV_PATH" "$old_env_tmp"
  fi

  local stage; stage="$(stage_extract "$bundle")"
  sync_full_replace "$stage/$PROJECT" "${old_env_tmp:-/dev/null}"
  rm -rf "$stage" || true
  [[ -n "$old_env_tmp" ]] && rm -f "$old_env_tmp" || true

  restart_services
  [[ "$with_tests" == "1" ]] && run_tests "$bundle" || true
  log INFO "Update complete."
}

patch_install(){
  local bundle="$1" with_tests="$2"
  is_patch_bundle "$bundle" || warn "Bundle doesn't look like PATCH; continuing anyway"
  verify_sha "$bundle"

  [[ -d "$APP_DIR" ]] || die "PATCH requires existing install at: $APP_DIR"

  backup_now
  save_env_copy "pre"

  local stage; stage="$(stage_extract "$bundle")"
  log INFO "Applying PATCH overlay (no deletes)..."
  sync_patch_overlay "$stage/$PROJECT"
  rm -rf "$stage" || true

  # env: patches may include env; if they do, keep same merge rule (version header new, tail old)
  if [[ -f "$ENV_PATH" ]]; then
    # We saved a copy already; merge against that last backup copy is tricky.
    # Here: do nothing by default; patch should explicitly change env if desired.
    :
  fi

  restart_services
  [[ "$with_tests" == "1" ]] && run_tests "$bundle" || true
  log INFO "Patch complete."
}

# ---------- menu ----------
menu(){
  select_snapshot_sh
  select_verify_sh
  mkdir -p "$INCOMING" "$BACKUP_DIR" "$ROOT/debug/tmp"

  while true; do
    echo
    echo "SERA Installer (project=$PROJECT)"
    echo "  ROOT:       $ROOT"
    echo "  INCOMING:   $INCOMING"
    echo "  APP_DIR:    $APP_DIR"
    echo "  BACKUP_DIR: $BACKUP_DIR"
    echo
    echo "1) Backup only"
    echo "2) Fresh install (FULL) - Quick"
    echo "3) Fresh install (FULL) - With tests"
    echo "4) Update (FULL) - Quick"
    echo "5) Update (FULL) - With tests"
    echo "6) Patch (PATCH) - Quick"
    echo "7) Patch (PATCH) - With tests"
    echo "8) Pick any bundle (auto-detect) - Quick"
    echo "9) List bundles"
    echo "10) Exit"
    echo
    printf "%s" "Select: " > "$TTY_IN"
    local choice; choice="$(read_choice "10")"

    case "$choice" in
      1)
        backup_now
        pause
        ;;
      2)
        local b; b="$(pick_bundle)"; fresh_install "$b" 0; pause ;;
      3)
        local b; b="$(pick_bundle)"; fresh_install "$b" 1; pause ;;
      4)
        local b; b="$(pick_bundle)"; update_install "$b" 0; pause ;;
      5)
        local b; b="$(pick_bundle)"; update_install "$b" 1; pause ;;
      6)
        local b; b="$(pick_bundle)"; patch_install "$b" 0; pause ;;
      7)
        local b; b="$(pick_bundle)"; patch_install "$b" 1; pause ;;
      8)
        local b; b="$(pick_bundle)"
        if is_patch_bundle "$b"; then patch_install "$b" 0; else update_install "$b" 0; fi
        pause
        ;;
      9)
        list_bundles
        pause
        ;;
      10)
        break
        ;;
      *)
        warn "Unknown selection: $choice"
        pause
        ;;
    esac
  done
}

usage(){
  cat <<EOF
Usage:
  $0 --menu
  $0 --fresh --bundle /path/to/FULL.tar.gz [--tests]
  $0 --update --bundle /path/to/FULL.tar.gz [--tests]
  $0 --patch  --bundle /path/to/PATCH.tar.gz [--tests]
Env:
  SERA_ROOT=$ROOT
  SERA_INCOMING=$INCOMING
  SERA_TARGET_ROOT=$TARGET_ROOT
  SERA_BACKUP_DIR=$BACKUP_DIR
  SERA_NO_RESTART=1
  SERA_SKIP_TESTS=1
EOF
}

main(){
  select_snapshot_sh
  select_verify_sh
  mkdir -p "$INCOMING" "$BACKUP_DIR" "$ROOT/debug/tmp"

  local mode="" bundle="" tests=0
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --menu) menu; exit 0;;
      --fresh) mode="fresh";;
      --update) mode="update";;
      --patch) mode="patch";;
      --bundle) shift; bundle="${1:-}";;
      --tests) tests=1;;
      --help|-h) usage; exit 0;;
      *) die "Unknown option: $1";;
    esac
    shift || true
  done

  [[ -n "$mode" ]] || { usage; exit 1; }
  [[ -n "$bundle" ]] || die "Missing --bundle PATH"
  [[ -f "$bundle" ]] || die "Bundle not found: $bundle"

  case "$mode" in
    fresh)  fresh_install "$bundle" "$tests" ;;
    update) update_install "$bundle" "$tests" ;;
    patch)  patch_install "$bundle" "$tests" ;;
    *) die "Unknown mode: $mode" ;;
  esac
}

main "$@"
