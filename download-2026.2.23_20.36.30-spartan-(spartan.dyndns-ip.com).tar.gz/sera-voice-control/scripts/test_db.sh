#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://127.0.0.1:3200}"
SID="test_$(date +%s)"

echo "==> DB health:"
curl -sS "$BASE/db/health" | python3 -m json.tool

payload="$(SID="$SID" python3 - <<'PY'
import json, os
sid=os.environ["SID"]
print(json.dumps({"session_id": sid, "meta": {"hello": "world"}}, separators=(",",":")))
PY
)"

echo "==> Create session:"
echo "$payload" | curl -sS -X POST "$BASE/session/create" -H 'Content-Type: application/json' --data-binary @- | python3 -m json.tool

echo "==> Get session:"
curl -sS "$BASE/session/get/$SID" | python3 -m json.tool

echo "==> List sessions:"
curl -sS "$BASE/session/list?limit=5" | python3 -m json.tool
