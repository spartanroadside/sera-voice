#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="${ROOT_DIR:-/home/spartan/sera}"
APP_DIR="${APP_DIR:-$ROOT_DIR/sera-voice-control}"
cd "$APP_DIR"

# Restart stack then run tests (tests handle retries)
docker compose down || true
docker compose up -d --remove-orphans --force-recreate

# Allow a brief grace before tests (mostly for initial socket binds)
sleep 2

"$ROOT_DIR/tools/test.sh" || true
