#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${SERA_APP_DIR:-/home/spartan/sera/sera-ai/sera-voice-control}"
cd "$APP_DIR"

export DB_TYPE="${DB_TYPE:-sqlite}"
export DB_PATH="${DB_PATH:-/home/spartan/sera/sera-ai/data/sera.db}"

python3 - <<'PY'
from agent.db import get_db
db = get_db()
row = db.query_one("SELECT name FROM sqlite_master WHERE type='table' AND name='sessions';")
print("sessions table:", "OK" if row else "MISSING")
PY
