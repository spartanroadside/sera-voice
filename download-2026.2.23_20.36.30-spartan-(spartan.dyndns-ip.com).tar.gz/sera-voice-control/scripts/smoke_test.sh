#!/usr/bin/env bash
set -euo pipefail

# SERA Smoke Test (RUN20+)
# Fast checks that should pass on a healthy deployment.
# Usage:
#   ./scripts/smoke_test.sh
# Optional env:
#   HOST_HTTP=127.0.0.1 TIMEOUT_SECS=3 QDRANT_URL=http://127.0.0.1:6333

TIMEOUT_SECS=${TIMEOUT_SECS:-3}
HOST_HTTP=${HOST_HTTP:-127.0.0.1}

VOICE_GATEWAY_URL=${VOICE_GATEWAY_URL:-"http://${HOST_HTTP}:3000"}
TOOL_GATEWAY_URL=${TOOL_GATEWAY_URL:-"http://${HOST_HTTP}:3100"}
AGENT_RUNNER_URL=${AGENT_RUNNER_URL:-"http://${HOST_HTTP}:3200"}
UI_HTTPS_URL=${UI_HTTPS_URL:-"https://${HOST_HTTP}:8443"}
QDRANT_URL=${QDRANT_URL:-"http://${HOST_HTTP}:6333"}
HOME_ASSISTANT_URL=${HOME_ASSISTANT_URL:-"http://${HOST_HTTP}:8123"}

ok()   { echo "OK: $*"; }
warn() { echo "WARN: $*"; }
fail() { echo "FAIL: $*"; exit 1; }

req() {
  local url="$1"
  local code
  code=$(curl -sS -m "$TIMEOUT_SECS" -o /dev/null -w "%{http_code}" "$url" || true)
  echo "$code"
}

header() {
  echo ""
  echo "=== $* ==="
}

header "Containers"
if ! command -v docker >/dev/null 2>&1; then
  fail "docker not found"
fi

docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
ok "docker ps"

header "Core health endpoints"
code=$(req "${TOOL_GATEWAY_URL}/health")
[[ "$code" == "200" ]] || fail "tool-gateway /health expected 200 got $code"
ok "tool-gateway /health"

code=$(req "${AGENT_RUNNER_URL}/health")
[[ "$code" == "200" ]] || fail "agent-runner /health expected 200 got $code"
ok "agent-runner /health"

# voice gateway may expose /api/health depending on run
code=$(req "${VOICE_GATEWAY_URL}/api/health")
if [[ "$code" != "200" ]]; then
  warn "voice-gateway /api/health expected 200 got $code (may be /health in some runs)"
else
  ok "voice-gateway /api/health"
fi

header "UI"
code=$(curl -k -sS -m "$TIMEOUT_SECS" -o /dev/null -w "%{http_code}" "${UI_HTTPS_URL}/" || true)
[[ "$code" == "200" ]] || warn "UI https / expected 200 got $code"
ok "UI reachable (https)"

header "Optional services"
code=$(req "${QDRANT_URL}/")
if [[ "$code" == "200" ]]; then
  ok "qdrant reachable"
else
  warn "qdrant not reachable on ${QDRANT_URL} (got $code)"
fi

code=$(req "${HOME_ASSISTANT_URL}/")
if [[ "$code" == "200" || "$code" == "302" ]]; then
  ok "homeassistant reachable"
else
  warn "homeassistant not reachable on ${HOME_ASSISTANT_URL} (got $code)"
fi

echo ""
echo "Smoke test complete."
