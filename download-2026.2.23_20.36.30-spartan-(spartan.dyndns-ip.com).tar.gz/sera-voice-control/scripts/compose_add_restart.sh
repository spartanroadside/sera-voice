#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${SERA_APP_DIR:-/home/spartan/sera/sera-ai/sera-voice-control}"
COMPOSE="$APP_DIR/docker-compose.yml"

if [[ ! -f "$COMPOSE" ]]; then
  echo "ERROR: docker-compose.yml not found at $COMPOSE" >&2
  exit 1
fi

ts="$(date +%Y%m%d_%H%M%S)"
cp -a "$COMPOSE" "$COMPOSE.bak_$ts"

python3 - <<'PY'
import sys, yaml
from pathlib import Path

compose_path = Path(sys.argv[1])
doc = yaml.safe_load(compose_path.read_text())
services = doc.get("services", {})
changed = False
for name, cfg in services.items():
    # Don't force restart if user already set one
    if "restart" not in cfg:
        cfg["restart"] = "unless-stopped"
        changed = True
if changed:
    compose_path.write_text(yaml.safe_dump(doc, sort_keys=False))
    print("OK: added restart: unless-stopped to services missing it")
else:
    print("OK: no changes needed (restart already present on all services)")
PY "$COMPOSE"

echo "Backup saved to: $COMPOSE.bak_$ts"
