#!/usr/bin/env bash
set -euo pipefail
sudo systemctl --no-pager status sera-voice-control.service || true
echo
cd "${SERA_APP_DIR:-/home/spartan/sera/sera-ai/sera-voice-control}"
docker compose ps || true
