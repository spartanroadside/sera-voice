#!/usr/bin/env bash
set -euo pipefail

# SERA deploy_bundle.sh (root-aware, metadata-preserving)
# - Deploys a bundle tar.gz into <ROOT>/<PROJECT>
# - Preserves installer-written metadata across rm -rf target:
#     .env, VERSION, BUILD_DATE, CHANNEL, build_meta.json
# - Verifies sha256 sidecar if present.

log(){ printf '%s\n' "$*"; }
fatal(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

infer_root(){
  local d="$SCRIPT_DIR"
  if [[ -d "$d" && "$(basename "$d")" == "scripts" ]]; then
    # .../sera-voice-control/scripts -> root is parent of project dir
    echo "$(cd "$d/.." && pwd)"
    return 0
  fi
  if [[ -d "$d" && "$(basename "$d")" == "tools" ]]; then
    echo "$(cd "$d/.." && pwd)"
    return 0
  fi
  return 1
}

ROOT_DEFAULT="/home/spartan/sera/sera-ai"
ROOT="${SERA_ROOT:-$ROOT_DEFAULT}"

PROJECT_DEFAULT="sera-voice-control"
PROJECT="${SERA_PROJECT:-$PROJECT_DEFAULT}"

LOG_DIR_DEFAULT="$ROOT/logs/$PROJECT"
LOG_DIR="${SERA_LOG_DIR:-$LOG_DIR_DEFAULT}"
mkdir -p "$LOG_DIR" || true

BUNDLE="${1:-}"
[[ -n "$BUNDLE" ]] || fatal "Usage: deploy_bundle.sh <bundle.tar.gz>"
[[ -f "$BUNDLE" ]] || fatal "Bundle not found: $BUNDLE"

verify_sha_portable(){
  local bundle="$1"
  local sha_side="${bundle}.sha256"
  [[ -f "$sha_side" ]] || { log "WARN: No sha256 sidecar found; skipping hash verify"; return 0; }
  command -v sha256sum >/dev/null 2>&1 || { log "WARN: sha256sum not found; skipping hash verify"; return 0; }

  log "Verifying sha256: $(basename "$sha_side")"
  local dir tmp
  dir="$(dirname "$bundle")"
  tmp="$dir/.sha256.normalized.$$"

  if grep -qE '(^|[[:space:]])/' "$sha_side"; then
    # normalize absolute path -> basename (supports optional leading '*')
    sed -E 's#^([0-9a-fA-F]{64}[[:space:]]+\*?)(.*/)?([^/[:space:]]+)$#\1\3#' "$sha_side" > "$tmp"
    (cd "$dir" && sha256sum -c "$(basename "$tmp")") || { rm -f "$tmp"; return 2; }
    rm -f "$tmp"
  else
    (cd "$dir" && sha256sum -c "$(basename "$sha_side")") || return 2
  fi
  log "sha256 OK"
}

verify_sha_portable "$BUNDLE" || fatal "sha256 FAILED"

TS="$(date +%Y-%m-%d_%H%M%S)"
LOG_FILE="$LOG_DIR/deploy_${TS}.log"

TARGET_ROOT="${SERA_TARGET_ROOT:-$ROOT}"
TARGET="$TARGET_ROOT/$PROJECT"

# Bundle must contain top-level project dir
TOPDIR="$(tar -tzf "$BUNDLE" | head -n1 | cut -d/ -f1)"
[[ "$TOPDIR" == "$PROJECT" ]] || fatal "Bundle missing top-level '$PROJECT' directory"

log "=== Deploy start: ${TS} ===" | tee "$LOG_FILE"
log "Bundle: $BUNDLE" | tee -a "$LOG_FILE"
log "Target: $TARGET" | tee -a "$LOG_FILE"
log "Root:   $ROOT"   | tee -a "$LOG_FILE"
log "Log:    $LOG_FILE" | tee -a "$LOG_FILE"

# --- preserve installer-written metadata (critical) ---
META_KEEP=( ".env" "VERSION" "BUILD_DATE" "CHANNEL" "build_meta.json" )
META_TMP="$TARGET_ROOT/.deploy_meta_keep_${TS}"
mkdir -p "$META_TMP" || true

if [[ -d "$TARGET" ]]; then
  for f in "${META_KEEP[@]}"; do
    if [[ -f "$TARGET/$f" ]]; then
      cp -af "$TARGET/$f" "$META_TMP/$f" || true
    fi
  done
fi

# Remove old install
if [[ -d "$TARGET" ]]; then
  log "Removing old install: $TARGET" | tee -a "$LOG_FILE"
  rm -rf "$TARGET"
fi

# Extract into target root
mkdir -p "$TARGET_ROOT"
( cd "$TARGET_ROOT" && tar -xzf "$BUNDLE" )

# Restore metadata after extract (so installer values win)
for f in "${META_KEEP[@]}"; do
  if [[ -f "$META_TMP/$f" ]]; then
    cp -af "$META_TMP/$f" "$TARGET/$f" || true
  fi
done
rm -rf "$META_TMP" || true

# Validate expected files
[[ -f "$TARGET/docker-compose.yml" ]] || fatal "docker-compose.yml missing after extract"

# Bring services up (force recreate so env_file is re-read)
(
  cd "$TARGET"
  docker compose up -d --build --force-recreate
) | tee -a "$LOG_FILE"

log "=== Deploy complete: ${TS} ===" | tee -a "$LOG_FILE"