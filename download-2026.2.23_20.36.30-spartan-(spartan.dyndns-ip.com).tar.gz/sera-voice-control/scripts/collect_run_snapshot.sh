#!/usr/bin/env bash
set -euo pipefail

# Collects a lightweight snapshot of the current runtime state for troubleshooting.
# Output: /home/spartan/sera/sera-ai/outgoing/sera_snapshot_<host>_<ts>.tar.gz

ROOT=${SERA_ROOT:-/home/spartan/sera}
OUT_DIR="${ROOT}/outgoing"
NAME_PREFIX=${NAME_PREFIX:-sera_snapshot}
TS=$(date +%F_%H%M%S)
HOSTNAME_SAFE=$(hostname | tr -c 'a-zA-Z0-9._-' '_' )
WORK_DIR="${OUT_DIR}/${NAME_PREFIX}_${HOSTNAME_SAFE}_${TS}"
TAR_PATH="${WORK_DIR}.tar.gz"
MANIFEST="${WORK_DIR}_manifest.txt"

mkdir -p "$OUT_DIR"
rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"

# 1) docker
{
  echo "# docker ps"; docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' || true
  echo
  echo "# docker compose ps (if possible)"; (cd "${ROOT}/sera-voice-control" 2>/dev/null && docker compose ps) || true
} > "${WORK_DIR}/docker_status.txt"

# 2) recent logs (tail)
for c in voice-gateway voice-ui tool-gateway agent-runner; do
  docker logs --tail=300 "$c" > "${WORK_DIR}/docker_logs_${c}.txt" 2>&1 || true
 done

# 3) health checks
{
  echo "tool-gateway:"; curl -sS -m 3 http://127.0.0.1:3100/health || true; echo
  echo "agent-runner:"; curl -sS -m 3 http://127.0.0.1:3200/health || true; echo
  echo "ui:"; curl -k -sS -m 3 -I https://127.0.0.1:8443/ | head -n 20 || true; echo
} > "${WORK_DIR}/health_checks.txt"

# 4) config (redacted)
if [[ -f "${ROOT}/sera-voice-control/.env" ]]; then
  sed -E 's/(OPENAI_API_KEY|TOOLGATEWAY_SECRET|VOICE_GATEWAY_TOKEN|CADDY_AUTH_TOKEN|.*TOKEN|.*KEY)=.*/\1=<REDACTED>/' \
    "${ROOT}/sera-voice-control/.env" > "${WORK_DIR}/env_redacted.txt" || true
fi

# 5) versions
{
  echo "date: $(date -Is)";
  echo "uname: $(uname -a)";
  echo "docker: $(docker --version 2>/dev/null || true)";
  echo "docker compose: $(docker compose version 2>/dev/null || true)";
  echo "python3: $(python3 --version 2>/dev/null || true)";
} > "${WORK_DIR}/versions.txt"

# manifest
{
  echo "Snapshot: ${TAR_PATH}";
  echo "Created: $(date -Is)";
  echo "Contents:";
  (cd "${OUT_DIR}" && ls -lah "$(basename "$WORK_DIR")" || true)
} > "${MANIFEST}"

# pack
 tar -czf "$TAR_PATH" -C "$OUT_DIR" "$(basename "$WORK_DIR")" 
 sha256sum "$TAR_PATH" > "${TAR_PATH}.sha256"

# clean temp folder (keep tar + sha)
rm -rf "$WORK_DIR"

echo "OK: wrote $TAR_PATH"
echo "OK: sha  $(cat "${TAR_PATH}.sha256")"
