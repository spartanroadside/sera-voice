#!/usr/bin/env bash
set -euo pipefail
BASE="${SERA_BASE:-/home/spartan/sera/sera-ai}"

mkdir -p "$BASE/logs/sera-voice-control" "$BASE/data" "$BASE/incoming" "$BASE/config" "$BASE/workspaces" "$BASE/share" "$BASE/debug" || true
chown -R "${SUDO_USER:-$USER}:${SUDO_USER:-$USER}" "$BASE/logs" "$BASE/data" "$BASE/incoming" "$BASE/config" "$BASE/workspaces" "$BASE/share" "$BASE/debug" 2>/dev/null || true

echo "OK: ensured host dirs under $BASE"
ls -la "$BASE/logs/sera-voice-control" | sed -n '1,20p' || true
