#!/usr/bin/env bash
set -euo pipefail

# sera_snapshot.sh --tier dev|deploy|program|root [--project sera-voice-control] [--root /home/spartan/sera]

TIER="dev"
ROOT="${SERA_ROOT:-/home/spartan/sera/sera-ai}"
PROJECT="${SERA_PROJECT:-sera-voice-control}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --tier) TIER="${2:-}"; shift 2;;
    --root) ROOT="${2:-}"; shift 2;;
    --project) PROJECT="${2:-}"; shift 2;;
    -h|--help)
      echo "Usage: $0 --tier dev|deploy|program|root [--root PATH] [--project SLUG]"; exit 0;;
    *) echo "Unknown arg: $1" >&2; exit 2;;
  esac
done

[[ "$TIER" =~ ^(dev|deploy|program|root)$ ]] || { echo "Invalid --tier" >&2; exit 2; }

TS="$(date +%Y-%m-%d_%H%M%S)"
OUT_DIR="${SERA_OUT_DIR:-$ROOT/outgoing}"
SNAP_ROOT="$OUT_DIR/snapshots"
SNAP_DIR="$SNAP_ROOT/${PROJECT}_${TIER}_${TS}"
APP_DIR="$ROOT/$PROJECT"

mkdir -p "$SNAP_DIR" "$OUT_DIR"

redact_env(){
  local src="$1" dst="$2"
  [[ -f "$src" ]] || return 0
  mkdir -p "$(dirname "$dst")"
  sed -E \
    -e 's/^(OPENAI_API_KEY=).*/\1REDACTED/' \
    -e 's/^(TOOLGATEWAY_SECRET=).*/\1REDACTED/' \
    -e 's/^(HOME_ASSISTANT_TOKEN=).*/\1REDACTED/' \
    -e 's/^(MYSQL_PASSWORD=).*/\1REDACTED/' \
    -e 's/^(POSTGRES_PASSWORD=).*/\1REDACTED/' \
    -e 's/^(JWT_SECRET=).*/\1REDACTED/' \
    -e 's/^(SESSION_SECRET=).*/\1REDACTED/' \
    "$src" > "$dst"
  chmod 600 "$dst" 2>/dev/null || true
}

copy_if_exists(){
  local src="$1" dst="$2"
  [[ -e "$src" ]] || return 0
  mkdir -p "$(dirname "$dst")"
  cp -a "$src" "$dst"
}

meta(){
  cat > "$SNAP_DIR/meta.json" <<META
{
  "timestamp": "${TS}",
  "tier": "${TIER}",
  "root": "${ROOT}",
  "project": "${PROJECT}",
  "host": "$(hostname)",
  "user": "$(whoami)",
  "version_file": "$(cat "$APP_DIR/VERSION" 2>/dev/null || echo "")"
}
META
}

meta

# Common essentials (all tiers)
copy_if_exists "$APP_DIR/VERSION" "$SNAP_DIR/app/VERSION"
copy_if_exists "$APP_DIR/RUN_INFO.txt" "$SNAP_DIR/app/RUN_INFO.txt"
copy_if_exists "$APP_DIR/docker-compose.yml" "$SNAP_DIR/app/docker-compose.yml"
copy_if_exists "$APP_DIR/.env.example" "$SNAP_DIR/app/.env.example"
redact_env "$APP_DIR/.env" "$SNAP_DIR/app/.env.redacted"
copy_if_exists "$APP_DIR/scripts/install.sh" "$SNAP_DIR/app/scripts/install.sh"
copy_if_exists "$APP_DIR/scripts/deploy_bundle.sh" "$SNAP_DIR/app/scripts/deploy_bundle.sh"
copy_if_exists "$APP_DIR/scripts/set_version.sh" "$SNAP_DIR/app/scripts/set_version.sh"
copy_if_exists "$ROOT/tools/deploy_bundle.sh" "$SNAP_DIR/root_tools/deploy_bundle.sh"
copy_if_exists "$ROOT/install.sh" "$SNAP_DIR/root_tools/install.sh"

# Docker state (if available)
mkdir -p "$SNAP_DIR/docker"
if command -v docker >/dev/null 2>&1; then
  docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}' > "$SNAP_DIR/docker/ps.txt" 2>&1 || true
  (cd "$APP_DIR" && docker compose -p "$PROJECT" ps) > "$SNAP_DIR/docker/compose_ps.txt" 2>&1 || true
  (cd "$APP_DIR" && docker compose -p "$PROJECT" logs --tail=300) > "$SNAP_DIR/docker/compose_logs_tail.txt" 2>&1 || true
fi

# Tier-specific
LOG_ROOT="$ROOT/logs"
case "$TIER" in
  dev)
    mkdir -p "$SNAP_DIR/logs"
    if [[ -d "$LOG_ROOT/$PROJECT" ]]; then
      ls -1t "$LOG_ROOT/$PROJECT"/deploy_*.log 2>/dev/null | head -n 5 | while read -r f; do
        tail -n 300 "$f" > "$SNAP_DIR/logs/$(basename "$f").tail" || true
      done
    fi
    ;;
  deploy)
    mkdir -p "$SNAP_DIR/logs"
    if [[ -d "$LOG_ROOT" ]]; then
      tar -czf "$SNAP_DIR/logs/logs_partial.tgz" -C "$LOG_ROOT" "$PROJECT" installer 2>/dev/null || true
    fi
    copy_if_exists "$ROOT/backups/$PROJECT" "$SNAP_DIR/backups_index"
    ;;
  program)
    mkdir -p "$SNAP_DIR/program"
    # Full program snapshot excluding large dirs
    tar -czf "$SNAP_DIR/program/${PROJECT}.tgz" -C "$ROOT" "$PROJECT" \
      --exclude="$PROJECT/.git" \
      --exclude="$PROJECT/node_modules" \
      --exclude="$PROJECT/**/__pycache__" \
      --exclude="$PROJECT/**/.cache" 2>/dev/null || true
    ;;
  root)
    mkdir -p "$SNAP_DIR/root"
    tar -czf "$SNAP_DIR/root/${PROJECT}_root.tgz" -C "$ROOT" . \
      --exclude="./backups" \
      --exclude="./workspaces" \
      --exclude="./services/qdrant" \
      --exclude="./**/node_modules" \
      --exclude="./**/.git" 2>/dev/null || true
    ;;
 esac

TAR="$OUT_DIR/${PROJECT}_${TIER}snapshot_${TS}.tar.gz"
tar -czf "$TAR" -C "$SNAP_ROOT" "$(basename "$SNAP_DIR")"
sha256sum "$TAR" > "$TAR.sha256" 2>/dev/null || true

echo "Snapshot created: $TAR"
