    #!/usr/bin/env bash
    set -euo pipefail

    if [[ ! -f ".env.example" ]]; then
      echo "ERROR: .env.example not found (run from repo root)."
      exit 1
    fi

    if [[ -f ".env" ]]; then
      echo ".env already exists; not overwriting."
      exit 0
    fi

    cp .env.example .env

    # Generate TOOLGATEWAY_SECRET if still placeholder
    if grep -q '^TOOLGATEWAY_SECRET=CHANGE_ME' .env; then
      secret="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(48))
PY
)"
      # shellcheck disable=SC2002
      sed -i "s/^TOOLGATEWAY_SECRET=.*/TOOLGATEWAY_SECRET=${secret}/" .env
      echo "Generated TOOLGATEWAY_SECRET."
    fi

    echo
    echo "Now edit .env and set OPENAI_API_KEY (required) and WORKSPACE_DIR (required)."
