#!/usr/bin/env bash
set -euo pipefail

sudo systemctl disable --now sera-voice-control.service || true
sudo rm -f /etc/systemd/system/sera-voice-control.service
sudo systemctl daemon-reload

echo "OK: removed sera-voice-control.service"
