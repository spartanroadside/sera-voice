#!/usr/bin/env bash
set -euo pipefail
LINES="${1:-200}"
sudo journalctl -u sera-voice-control.service -n "$LINES" --no-pager || true
