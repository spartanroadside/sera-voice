#!/usr/bin/env bash
# SERA comprehensive smoke test (non-destructive)
# - Always completes; summarizes PASS/WARN/FAIL at end
# - Saves a log to /home/spartan/sera/sera-ai/debug/tests/

set -u

ROOT_DIR="${ROOT_DIR:-/home/spartan/sera}"
APP_DIR="${APP_DIR:-$ROOT_DIR/sera-voice-control}"
COMPOSE_FILE="$APP_DIR/docker-compose.yml"
LOG_DIR="$ROOT_DIR/debug/tests"
STAMP="$(date +%F_%H%M%S)"
LOG="$LOG_DIR/test_${STAMP}.log"

mkdir -p "$LOG_DIR"

PASS=0
WARN=0
FAIL=0

log(){ echo "$*" | tee -a "$LOG"; }
pass(){ PASS=$((PASS+1)); log "[PASS] $*"; }
warn(){ WARN=$((WARN+1)); log "[WARN] $*"; }
fail(){ FAIL=$((FAIL+1)); log "[FAIL] $*"; }

run(){
  # run <desc> <cmd...>
  local desc="$1"; shift
  log ">>> $desc"
  if "$@" >>"$LOG" 2>&1; then
    pass "$desc"
    return 0
  else
    fail "$desc"
    return 1
  fi
}

http_json(){
  # http_json <url> <name>
  local url="$1"; local name="$2"
  local out
  out="$(curl -fsS --max-time 3 "$url" 2>>"$LOG" || true)"
  if [[ -n "$out" ]]; then
    echo "$out" | tee -a "$LOG" >/dev/null
    pass "$name ($url)"
    return 0
  fi
  fail "$name ($url)"
  return 1
}

http_retry(){
  # http_retry <url> <name> [attempts] [sleep]
  local url="$1"; local name="$2"; local attempts="${3:-20}"; local delay="${4:-1}"
  local i out
  for ((i=1;i<=attempts;i++)); do
    out="$(curl -fsS --max-time 3 "$url" 2>>"$LOG" || true)"
    if [[ -n "$out" ]]; then
      echo "$out" | tee -a "$LOG" >/dev/null
      pass "$name ($url)"
      return 0
    fi
    sleep "$delay"
  done
  fail "$name ($url)"
  return 1
}

log "=== SERA TEST start $STAMP ==="
log "App dir: $APP_DIR"
log "Log: $LOG"
log ""

[[ -d "$ROOT_DIR" ]] && pass "Root exists: $ROOT_DIR" || fail "Root missing: $ROOT_DIR"
[[ -d "$APP_DIR" ]] && pass "App exists: $APP_DIR" || fail "App missing: $APP_DIR"
[[ -f "$COMPOSE_FILE" ]] && pass "docker-compose.yml present" || fail "docker-compose.yml missing"

# Version checks
if [[ -f "$APP_DIR/VERSION" ]]; then
  VER="$(cat "$APP_DIR/VERSION" 2>/dev/null || true)"
  [[ -n "$VER" ]] && pass "VERSION=$VER" || warn "VERSION empty"
else
  warn "VERSION missing"
fi

if [[ -f "$APP_DIR/.env" ]]; then
  RT="$(grep -E '^RUN_TAG=' "$APP_DIR/.env" 2>/dev/null | head -n1 | cut -d= -f2- || true)"
  SV="$(grep -E '^SERA_VERSION=' "$APP_DIR/.env" 2>/dev/null | head -n1 | cut -d= -f2- || true)"
  [[ -n "$RT" ]] && pass ".env RUN_TAG=$RT" || warn ".env RUN_TAG missing"
  [[ -n "$SV" ]] && pass ".env SERA_VERSION=$SV" || warn ".env SERA_VERSION missing"
else
  warn ".env missing"
fi

# Python syntax check (tool-gateway)
if [[ -f "$APP_DIR/tools/server.py" ]]; then
  if python3 -m py_compile "$APP_DIR/tools/server.py" >>"$LOG" 2>&1; then
    pass "py_compile OK (tools/server.py)"
  else
    fail "py_compile FAILED (tools/server.py)"
  fi
else
  warn "tools/server.py missing"
fi

# Docker / compose
command -v docker >/dev/null 2>&1 && pass "docker present" || { fail "docker missing"; }

if command -v docker >/dev/null 2>&1; then
  (cd "$APP_DIR" && docker compose ps) >>"$LOG" 2>&1 || true
fi

# Health checks with retries (services may take a moment)
http_retry "http://127.0.0.1:3000/api/health" "voice-gateway healthy"
http_retry "http://127.0.0.1:3100/health" "tool-gateway healthy"
http_retry "http://127.0.0.1:3200/health" "agent-runner healthy"

# Config + plugins endpoints (try both legacy and /api)
http_json "http://127.0.0.1:3000/api/config" "config endpoint ok" || true

# plugins list (preferred)
http_json "http://127.0.0.1:3000/api/plugins/list" "plugins/api list ok" || true
# legacy fallback
http_json "http://127.0.0.1:3000/plugins/list" "plugins legacy list ok" || true

# plugin safe test
http_json "http://127.0.0.1:3000/api/plugins/test?slug=webmin_virtualmin" "plugins/api test ok" || true
http_json "http://127.0.0.1:3000/plugins/test?slug=webmin_virtualmin" "plugins legacy test ok" || true

log ""
log "=== SUMMARY ==="
log "PASS=$PASS WARN=$WARN FAIL=$FAIL"
log "Log file: $LOG"

# exit non-zero if fails
[[ "$FAIL" -eq 0 ]] || exit 2
