#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="${SERA_LOG_DIR:-/home/spartan/sera/sera-ai/logs/sera-voice-control}"
ARCHIVE="$LOG_DIR/archive"
mkdir -p "$ARCHIVE"

ts="$(date +%Y%m%d_%H%M%S)"
for f in actions.jsonl agent.jsonl; do
  if [[ -f "$LOG_DIR/$f" ]]; then
    mv "$LOG_DIR/$f" "$ARCHIVE/${f%.jsonl}_$ts.jsonl"
    echo "Archived $f -> $ARCHIVE/${f%.jsonl}_$ts.jsonl"
  fi
done

echo "OK: log rotate complete"
ls -la "$ARCHIVE" | tail -n 20 || true
