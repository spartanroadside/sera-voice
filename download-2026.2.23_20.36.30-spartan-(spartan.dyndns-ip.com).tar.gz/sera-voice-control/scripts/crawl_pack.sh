#!/usr/bin/env bash
set -euo pipefail

# --- Config (edit if you want) ---
PROJECT_NAME="sera-voice-control"
DEFAULT_ROOT="/home/spartan/sera/sera-ai/sera-voice-control"
OUT_DIR_DEFAULT="/home/spartan/sera/sera-ai/_bundles"
STAMP="$(date +%F_%H%M%S)"
HOST="$(hostname -s 2>/dev/null || hostname)"

ROOT="${1:-$DEFAULT_ROOT}"
OUT_DIR="${2:-$OUT_DIR_DEFAULT}"

if [[ ! -d "$ROOT" ]]; then
  echo "ERROR: root path not found: $ROOT" >&2
  exit 1
fi

mkdir -p "$OUT_DIR"

WORK_DIR="$(mktemp -d)"
PKG_DIR="$WORK_DIR/${PROJECT_NAME}_${STAMP}"
mkdir -p "$PKG_DIR"

# Excludes: keep these aggressive so we only ship relevant source/config
EXCLUDES=(
  ".git" ".svn" ".hg"
  "node_modules" ".pnpm-store" ".yarn" ".npm" ".cache"
  "__pycache__" "*.pyc" "*.pyo" ".pytest_cache" ".mypy_cache" ".ruff_cache"
  "venv" ".venv" "env" ".envrc"
  ".idea" ".vscode"
  "dist" "build" ".next" "out" "coverage"
  "*.log" "logs" "tmp" "temp"
  ".DS_Store" "Thumbs.db"
  "caddy_data" "caddy_config"
)

# Build rsync exclude args
RSYNC_EX=()
for e in "${EXCLUDES[@]}"; do
  RSYNC_EX+=(--exclude="$e")
done

echo "==> Crawling project root: $ROOT"
echo "==> Output dir: $OUT_DIR"
echo "==> Staging: $PKG_DIR"
echo

# Copy tree (preserve perms, symlinks)
# rsync is ideal for "mirror but exclude"
rsync -a --delete \
  "${RSYNC_EX[@]}" \
  "$ROOT"/ "$PKG_DIR"/

# Add a crawl metadata file
cat > "$PKG_DIR/CRAWL_INFO.txt" <<EOF
Project: $PROJECT_NAME
Host: $HOST
Crawl time: $(date -Is)
Root: $ROOT

Excludes:
$(printf ' - %s\n' "${EXCLUDES[@]}")
EOF

# Create manifest (paths + sizes + mtime)
MANIFEST="$PKG_DIR/CRAWL_MANIFEST.tsv"
(
  echo -e "size_bytes\tmtime_iso\tpath"
  cd "$PKG_DIR"
  # Use POSIX-ish find formatting
  find . -type f -print0 | while IFS= read -r -d '' f; do
    # strip leading ./
    p="${f#./}"
    # stat format differs slightly by platform; on Debian this works:
    sz="$(stat -c '%s' "$f")"
    mt="$(stat -c '%y' "$f" | sed 's/ /T/; s/ .*//')"
    echo -e "${sz}\t${mt}\t${p}"
  done
) > "$MANIFEST"

# Pack tarball
TAR_NAME="${PROJECT_NAME}_${STAMP}_${HOST}.tar.gz"
TAR_PATH="$OUT_DIR/$TAR_NAME"

echo "==> Creating tarball: $TAR_PATH"
tar -C "$WORK_DIR" -czf "$TAR_PATH" "$(basename "$PKG_DIR")"

# Checksums
echo "==> Checksums:"
sha256sum "$TAR_PATH" | tee "$OUT_DIR/${TAR_NAME}.sha256"

# Quick “top offenders” size report
echo
echo "==> Largest files (top 20):"
tar -tzf "$TAR_PATH" | head -n 0 >/dev/null # sanity read
(
  cd "$PKG_DIR"
  find . -type f -printf '%s\t%p\n' 2>/dev/null | sort -nr | head -n 20
) | sed 's#^\([0-9]\+\)\t\./#\1\t#'

echo
echo "DONE."
echo "Bundle: $TAR_PATH"
echo "SHA:    $OUT_DIR/${TAR_NAME}.sha256"

# cleanup staging
rm -rf "$WORK_DIR"

