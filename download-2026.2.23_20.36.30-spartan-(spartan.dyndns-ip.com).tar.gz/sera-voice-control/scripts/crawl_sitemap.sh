#!/usr/bin/env bash
set -euo pipefail

# Crawl key directories and generate a lightweight sitemap with file metadata.
# Excludes secrets and heavy directories.

ROOT=${1:-/home/spartan}
OUT=${2:-"$PWD/docs/SITEMAP_SPARTAN_AI_STACK.md"}

# Directories to include (edit as needed)
INCLUDE=(
  "$ROOT/sera"
  "$ROOT/ha"
  "$ROOT/voice_stage"
  "$ROOT/toolgateway"
)

EXCLUDES=(
  '.git'
  'node_modules'
  '__pycache__'
  '.venv'
  '.mypy_cache'
  '.pytest_cache'
  'caddy_data'
  'caddy_config'
  'data/caddy'
  'logs'
  '*.log'
  '*.pem'
  '*.key'
  '*.crt'
  '*.p12'
  '*.pfx'
  '.env'
)

mkdir -p "$(dirname "$OUT")"

{
  echo "# Spartan AI Stack Sitemap"
  echo
  echo "Generated: $(date -Is)"
  echo "Root: $ROOT"
  echo
  echo "## Included roots"
  for d in "${INCLUDE[@]}"; do
    echo "- $d"
  done
  echo
  echo "## Excludes"
  for e in "${EXCLUDES[@]}"; do
    echo "- $e"
  done
  echo
} > "$OUT"

# Build find prune expression
prune_expr=()
for ex in "${EXCLUDES[@]}"; do
  # dir excludes
  if [[ "$ex" != *.* && "$ex" != *'*'* ]]; then
    prune_expr+=( -path "*/$ex/*" -o -path "*/$ex" -o )
  fi
done

for base in "${INCLUDE[@]}"; do
  [[ -d "$base" ]] || continue
  echo "## Tree: $base" >> "$OUT"
  echo >> "$OUT"

  # File listing with size + mtime + sha256 (for small files only)
  # Limit hashing to files <= 2MB to keep it fast.
  find "$base" \
    \( \
      -path '*/.git/*' -o -path '*/node_modules/*' -o -path '*/__pycache__/*' -o -path '*/.venv/*' -o -path '*/caddy_data/*' -o -path '*/caddy_config/*' -o -name '*.log' -o -name '.env' -o -name '*.pem' -o -name '*.key' -o -name '*.crt' -o -name '*.p12' -o -name '*.pfx' \
    \) -prune -false -o -type f -print0 \
  | while IFS= read -r -d '' f; do
      rel="${f#$ROOT/}"
      size=$(stat -c '%s' "$f" 2>/dev/null || echo 0)
      mtime=$(stat -c '%y' "$f" 2>/dev/null | cut -d'.' -f1 || echo "")
      sha="-"
      if [[ $size -le 2097152 ]]; then
        sha=$(sha256sum "$f" | awk '{print $1}')
      fi
      printf "- %s (bytes=%s, mtime=%s, sha256=%s)\n" "$rel" "$size" "$mtime" "$sha" >> "$OUT"
    done

  echo >> "$OUT"
  echo "---" >> "$OUT"
  echo >> "$OUT"
done

echo "Wrote $OUT"
