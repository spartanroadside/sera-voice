#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://127.0.0.1:3200}"

echo "==> Modules:"
curl -sS "$BASE/modules" | python3 -m json.tool

echo "==> Ping (admin):"
curl -sS -X POST "$BASE/execute" -H 'Content-Type: application/json' \
  -d '{"module":"system.ping","payload":{"t":"now"},"user_id":"local","role":"admin"}' | python3 -m json.tool

echo "==> Echo (guest should fail):"
set +e
curl -sS -o /tmp/sera_exec_out.json -w "\nHTTP:%{http_code}\n" -X POST "$BASE/execute" -H 'Content-Type: application/json' \
  -d '{"module":"system.echo","payload":{"hello":"world"},"user_id":"guest1","role":"guest"}'
cat /tmp/sera_exec_out.json | python3 -m json.tool || cat /tmp/sera_exec_out.json
set -e

echo "==> Echo (allow-list):"
curl -sS -X POST "$BASE/execute" -H 'Content-Type: application/json' \
  -d '{"module":"system.echo","payload":{"hello":"world"},"user_id":"u1","role":"user","allowed_actions":["module:system.echo"]}' | python3 -m json.tool
