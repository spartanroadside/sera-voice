#!/usr/bin/env bash
set -euo pipefail
find . -type d -name "node_modules" -prune -exec rm -rf {} +
find . -type d -name "__pycache__" -prune -exec rm -rf {} +
find . -type f \( -name "*.pyc" -o -name "*.pyo" \) -delete
find . -maxdepth 2 -type f -name ".env" -delete
find . -maxdepth 2 -type f -name ".env.*" ! -name ".env.example" -delete
echo "Cleanup complete."
