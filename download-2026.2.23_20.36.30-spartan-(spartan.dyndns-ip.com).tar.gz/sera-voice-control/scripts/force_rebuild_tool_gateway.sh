#!/usr/bin/env bash
set -euo pipefail
cd /home/spartan/sera/sera-ai/sera-voice-control

# Hard reset just this service
sudo docker compose rm -sf tool-gateway
sudo docker compose build --no-cache --pull tool-gateway
sudo docker compose up -d tool-gateway

# Evidence: show the running server.py hash
docker exec -it tool-gateway sh -lc 'sha256sum /app/server.py && python - << "PY"
import json, urllib.request
data = json.load(urllib.request.urlopen("http://127.0.0.1:3100/openapi.json"))
print("imports:", [p for p in sorted(data.get("paths", {})) if p.startswith("/imports")])
PY'