#!/usr/bin/env bash
set -euo pipefail
BASE_TLS="${1:-https://sera.lan:8443}"

echo "==> Caddy ping:"
curl -k -sS "$BASE_TLS/__ping" || true
echo

echo "==> Settings GET:"
curl -k -sS -i "$BASE_TLS/api/settings" | sed -n '1,80p'
echo

echo "==> Settings POST:"
curl -k -sS -i -X POST "$BASE_TLS/api/settings" -H 'Content-Type: application/json' \
  -d '{"theme":"light","net_scope":"lan"}' | sed -n '1,120p'
echo

echo "==> Projects create (UI-style payload):"
curl -k -sS -i -X POST "$BASE_TLS/api/projects" -H 'Content-Type: application/json' \
  -d '{"name":"Test Project","template":"web-hello"}' | sed -n '1,160p'
echo

echo "==> Projects list:"
curl -k -sS "$BASE_TLS/api/projects" | python3 -m json.tool
