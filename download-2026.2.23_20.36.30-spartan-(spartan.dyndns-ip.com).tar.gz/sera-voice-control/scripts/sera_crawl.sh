#!/usr/bin/env bash
set -euo pipefail

# SERA crawl: inventory + light hygiene report
# Writes reports under: /home/spartan/sera/sera-ai/logs/sera-voice-control/crawl
# Safe to run as user or sudo.

ROOT="${SERA_ROOT:-/home/spartan/sera}"
PROJECT="${SERA_PROJECT:-sera-voice-control}"
LOG_BASE="${SERA_LOG_BASE:-$ROOT/logs/$PROJECT/crawl}"
TS="$(date +%Y-%m-%d_%H%M%S)"

mkdir -p "$LOG_BASE/trees"

REPORT="$LOG_BASE/sera_crawl_${TS}.txt"
JSON="$LOG_BASE/sera_crawl_${TS}.json"
TREE="$LOG_BASE/trees/sera_tree_${TS}.txt"

# ---- Collect tree ----
# (Exclude common junk, keep maxdepth reasonably high for debugging)
( cd "$ROOT" && \
  find . \
    -path './.git' -o -path './.git/*' -o \
    -path './**/node_modules' -o -path './**/node_modules/*' -o \
    -path './**/__pycache__' -o -path './**/__pycache__/*' -o \
    -path './**/.venv' -o -path './**/.venv/*' -o \
    -path './**/venv' -o -path './**/venv/*' -o \
    -path './**/logs' -o -path './**/logs/*' \
    -prune -o \
    -print \
  | sed 's#^\./##' \
  | sort \
) > "$TREE"

# ---- Stats + hygiene hints ----
python3 - <<PY
import os, json
from collections import Counter
from pathlib import Path

root = Path("$ROOT")
report = Path("$REPORT")
json_path = Path("$JSON")
tree = Path("$TREE")

# Walk
file_paths = []
dir_count = 0
for p in root.rglob('*'):
    try:
        if p.is_dir():
            dir_count += 1
        elif p.is_file():
            file_paths.append(p)
    except Exception:
        continue

exts = Counter((p.suffix.lower().lstrip('.') or '(noext)') for p in file_paths)

# Largest files
largest = sorted(
    ((p.stat().st_size, str(p)) for p in file_paths),
    reverse=True,
)[:30]

# Largest directories (shallow)
# Avoid crossing filesystems; approximate with os.walk size sums
sizes = {}
for base, dirs, files in os.walk(root):
    total = 0
    for f in files:
        fp = os.path.join(base, f)
        try:
            st = os.stat(fp)
            total += st.st_size
        except Exception:
            pass
    sizes[base] = total

# Show top 30 by summed file sizes under that dir (not recursive totals; but good signal)
# For real du use system du; keeping python portable.
largest_dirs = sorted(((v, k) for k,v in sizes.items()), reverse=True)[:30]

def fmt_mb(n):
    return f"{n/1024/1024:.2f} MB"

# Bundles outside incoming/
outside_bundles = []
for p in file_paths:
    if p.suffixes[-2:] == ['.tar', '.gz'] or str(p).endswith('.tar.gz'):
        rel = str(p.relative_to(root))
        if not rel.startswith('incoming/'):
            outside_bundles.append(rel)

# Duplicate basenames
by_name = {}
for p in file_paths:
    by_name.setdefault(p.name, []).append(str(p))
dupes = {k:v for k,v in by_name.items() if len(v) > 1}

# Draft report
lines = []
lines.append("SERA CRAWL REPORT")
lines.append(f"Timestamp: {os.environ.get('TS','')}".replace('TS','').strip())
lines.append(f"Root: {root}")
lines.append("")
lines.append("== TREE (paths) ==")
lines.append(f"Saved: {tree}")
lines.append(f"Lines: {sum(1 for _ in tree.open('r', errors='ignore'))}")
lines.append("")
lines.append("== FILE COUNTS ==")
lines.append(f"Total dirs : {dir_count}")
lines.append(f"Total files: {len(file_paths)}")
lines.append("")
lines.append("== TOP EXTENSIONS ==")
for ext, cnt in exts.most_common(30):
    lines.append(f"{cnt:7d} {ext}")
lines.append("")
lines.append("== LARGEST FILES ==")
for sz, path in largest:
    lines.append(f"{fmt_mb(sz):>8} {path}")
lines.append("")
lines.append("== LARGEST DIRECTORIES (approx) ==")
for sz, path in largest_dirs:
    lines.append(f"{fmt_mb(sz):>8} {path}")
lines.append("")
lines.append("== BUNDLES OUTSIDE incoming/ ==")
if outside_bundles:
    for rel in sorted(outside_bundles)[:200]:
        lines.append(rel)
else:
    lines.append("(none)")
lines.append("")
lines.append("== DUPLICATE FILENAMES (name collisions) ==")
if dupes:
    for name in sorted(dupes.keys()):
        lines.append(f"-- {name}")
        for p in dupes[name]:
            lines.append(f"   {p}")
else:
    lines.append("(none)")

report.write_text("\n".join(lines) + "\n")

summary = {
    "timestamp": "$TS",
    "root": str(root),
    "counts": {"files": len(file_paths), "dirs": dir_count},
    "notes": {
        "tree": str(tree),
        "report": str(report),
        "bundles_outside_incoming_count": len(outside_bundles),
        "duplicate_filenames_count": len(dupes),
    }
}
json_path.write_text(json.dumps(summary, indent=2) + "\n")

print("Wrote JSON summary:", json_path)
PY

echo "Saved report: $REPORT"
echo "Saved json  : $JSON"

# If run with sudo, fix ownership to the invoking user to avoid later permission friction
if [[ -n "${SUDO_USER:-}" ]]; then
  chown -R "$SUDO_USER:$SUDO_USER" "$LOG_BASE" 2>/dev/null || true
fi
