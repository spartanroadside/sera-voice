#!/usr/bin/env bash
set -euo pipefail

# SERA Voice Control - Clean installer
# Usage:
#   ./scripts/install_sera.sh --bundle /path/to/sera-voice-control_RUN16_YYYY-MM-DD.tar.gz [--dir /home/spartan/sera]

BUNDLE=""
INSTALL_DIR="/home/spartan/sera"
PROJECT_DIR=""
NONINTERACTIVE=0

log(){ echo "[install] $*"; }
die(){ echo "[install] ERROR: $*" >&2; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --bundle) BUNDLE="$2"; shift 2 ;;
    --dir) INSTALL_DIR="$2"; shift 2 ;;
    --project-dir) PROJECT_DIR="$2"; shift 2 ;;
    --noninteractive) NONINTERACTIVE=1; shift ;;
    -h|--help)
      sed -n '1,40p' "$0"; exit 0 ;;
    *) die "Unknown arg: $1" ;;
  esac
done

[[ -n "$BUNDLE" ]] || die "--bundle is required"
[[ -f "$BUNDLE" ]] || die "Bundle not found: $BUNDLE"

# Resolve project dir
if [[ -z "$PROJECT_DIR" ]]; then
  PROJECT_DIR="$INSTALL_DIR/sera-voice-control"
fi

log "Install dir: $INSTALL_DIR"
log "Project dir: $PROJECT_DIR"

# Docker presence
if command -v docker >/dev/null 2>&1; then
  DOCKER_BIN="docker"
else
  die "docker not found in PATH"
fi

# Detect snap docker (common on Ubuntu)
DOCKER_IS_SNAP=0
if command -v snap >/dev/null 2>&1 && snap list 2>/dev/null | awk '{print $1}' | grep -qx docker; then
  DOCKER_IS_SNAP=1
fi
log "Docker: $(docker --version 2>/dev/null || true) (snap=$DOCKER_IS_SNAP)"

# Basic sanity
mkdir -p "$INSTALL_DIR" "$INSTALL_DIR/incoming" "$INSTALL_DIR/bundles" "$INSTALL_DIR/logs" "$INSTALL_DIR/backups" || true

# Optional prompt for OpenAI key
OPENAI_KEY=""
if [[ $NONINTERACTIVE -eq 0 ]]; then
  read -r -p "Enter OPENAI_API_KEY (or leave blank to configure later): " OPENAI_KEY || true
fi

# Generate TOOLGATEWAY_SECRET if not present
ENV_FILE="$PROJECT_DIR/.env"
mkdir -p "$PROJECT_DIR" || true
if [[ ! -f "$ENV_FILE" ]]; then
  log "Creating $ENV_FILE"
  umask 077
  cat > "$ENV_FILE" <<EOF
# SERA Voice Control env
RUN_TAG=RUN16
# Generate once per install
TOOLGATEWAY_SECRET=
# Optional
OPENAI_API_KEY=
SERA_SAFE_MODE=1
LOG_DIR=$INSTALL_DIR/logs/sera-voice-control
EOF
fi

if ! grep -q '^TOOLGATEWAY_SECRET=' "$ENV_FILE"; then
  echo 'TOOLGATEWAY_SECRET=' >> "$ENV_FILE"
fi

SECRET=$(grep '^TOOLGATEWAY_SECRET=' "$ENV_FILE" | head -n1 | cut -d= -f2-)
if [[ -z "$SECRET" ]]; then
  if command -v openssl >/dev/null 2>&1; then
    SECRET=$(openssl rand -hex 32)
  else
    # fallback
    SECRET=$(python - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)
  fi
  log "Generating TOOLGATEWAY_SECRET"
  # Replace first occurrence
  perl -pi -e 's/^TOOLGATEWAY_SECRET=.*/TOOLGATEWAY_SECRET='"$SECRET"'/' "$ENV_FILE"
fi

if [[ -n "$OPENAI_KEY" ]]; then
  perl -pi -e 's/^OPENAI_API_KEY=.*/OPENAI_API_KEY='"$OPENAI_KEY"'/' "$ENV_FILE"
fi

# Stop existing stack if present
if [[ -d "$PROJECT_DIR" && -f "$PROJECT_DIR/docker-compose.yml" ]]; then
  log "Stopping any existing stack"
  (cd "$PROJECT_DIR" && docker compose down) || true
fi

# Extract bundle
log "Extracting bundle over $INSTALL_DIR"
# NOTE: bundle already contains sera-voice-control/ at top level
tar -xzf "$BUNDLE" -C "$INSTALL_DIR"

# Ensure perms for logs
LOG_DIR="$INSTALL_DIR/logs/sera-voice-control"
mkdir -p "$LOG_DIR"
touch "$LOG_DIR/actions.jsonl" || true
chown -R "$(id -u)":"$(id -g)" "$LOG_DIR" || true
chmod -R u+rwX,go+rX "$LOG_DIR" || true

# Build + start
log "Building images"
(cd "$PROJECT_DIR" && docker compose build)

log "Starting stack"
(cd "$PROJECT_DIR" && docker compose up -d)

log "Health checks"
set +e
curl -fsS http://127.0.0.1:3000/health >/dev/null 2>&1 && log "voice-gateway OK" || log "voice-gateway not reachable yet"
curl -fsS http://127.0.0.1:3100/health >/dev/null 2>&1 && log "tool-gateway OK" || log "tool-gateway not reachable yet"
curl -fsS http://127.0.0.1:3200/health >/dev/null 2>&1 && log "agent-runner OK" || log "agent-runner not reachable yet"
set -e

log "Done. UI: https://<server-ip>:8443/ (or http://127.0.0.1:8080/)"
