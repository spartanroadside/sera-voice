#!/usr/bin/env bash
set -euo pipefail

# SERA rotation helper (dry-run by default)
# Usage:
#   ./sera_rotate.sh --apply
# Default policies:
#   - backups: keep last 10 per project
#   - logs: keep last 30 days
#   - workspace tmp: purge > 24h
#   - outgoing: purge > 30d (optional)

APPLY=0
if [[ ${1:-} == "--apply" ]]; then APPLY=1; fi

ROOT="${SERA_ROOT:-/home/spartan/sera}"

say(){ echo "[rotate] $*"; }
run(){ if [[ $APPLY -eq 1 ]]; then eval "$@"; else say "DRYRUN: $*"; fi; }

say "Root: $ROOT"
say "Apply: $APPLY"

# Backups
if [[ -d "$ROOT/backups" ]]; then
  for proj in "$ROOT/backups"/*; do
    [[ -d "$proj" ]] || continue
    say "Backups in $(basename "$proj")"
    mapfile -t files < <(ls -1t "$proj"/*.tar.gz 2>/dev/null || true)
    if [[ ${#files[@]} -gt 10 ]]; then
      for f in "${files[@]:10}"; do
        run rm -f ""$f""
      done
    fi
  done
fi

# Logs
if [[ -d "$ROOT/logs" ]]; then
  say "Prune logs older than 30 days"
  run find ""$ROOT/logs"" -type f -name "*.log" -mtime +30 -delete
fi

# Workspace tmp
if [[ -d "$ROOT/workspaces" ]]; then
  say "Prune workspace tmp older than 24h"
  run find ""$ROOT/workspaces"" -type d -name tmp -prune -o -type f -path "*/tmp/*" -mmin +1440 -delete
fi

say "Done."
