#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="${SERA_LOG_DIR:-/home/spartan/sera/sera-ai/logs/sera-voice-control}"

sudo mkdir -p "$LOG_DIR"
sudo chown -R "${SUDO_USER:-$USER}:${SUDO_USER:-$USER}" "$LOG_DIR" || true
chmod 775 "$LOG_DIR" || true

echo "OK: log dir ready: $LOG_DIR"
ls -la "$LOG_DIR" | sed -n '1,20p' || true
