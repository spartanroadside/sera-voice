#!/usr/bin/env bash
set -euo pipefail

LOG_DIR="${SERA_LOG_DIR:-/home/spartan/sera/sera-ai/logs/sera-voice-control}"
FILE="${1:-agent.jsonl}"
N="${2:-100}"

path="$LOG_DIR/$FILE"
if [[ ! -f "$path" ]]; then
  echo "ERROR: log file not found: $path" >&2
  echo "Tip: run ./scripts/ensure_logs_dir.sh and then exercise the service." >&2
  exit 1
fi

tail -n "$N" "$path"
