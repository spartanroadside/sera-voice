import os


def env_bool(name: str, default: str = "0") -> bool:
    """Parse common truthy env values."""
    return os.getenv(name, default).strip() in ("1", "true", "TRUE", "yes", "YES", "on", "ON")


def env_str(name: str, default: str = "") -> str:
    return os.getenv(name, default)


class Settings:
    """Centralized runtime configuration.

    Defaults are chosen for local/dev safety.
    """

    # DEV-only flags
    DEV_EXPERIMENTAL: bool = env_bool("SERA_DEV_EXPERIMENTAL", "0")

    # Session behavior
    REQUIRE_SESSION: bool = env_bool("SERA_REQUIRE_SESSION", "0")

    # Database behavior
    DB_AUTO_MIGRATE: bool = env_bool("SERA_DB_AUTO_MIGRATE", "0")


settings = Settings()
