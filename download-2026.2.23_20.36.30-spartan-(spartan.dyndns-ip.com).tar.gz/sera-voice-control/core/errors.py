from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SeraError(Exception):
    """Typed error used for consistent envelope mapping."""

    code: str
    message: str

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.code}: {self.message}"


# Common error codes used by new API endpoints.
ERR_BAD_REQUEST = "BAD_REQUEST"
ERR_NOT_FOUND = "NOT_FOUND"
ERR_UNAUTHORIZED = "UNAUTHORIZED"
ERR_FORBIDDEN = "FORBIDDEN"
ERR_INTERNAL = "INTERNAL_ERROR"
