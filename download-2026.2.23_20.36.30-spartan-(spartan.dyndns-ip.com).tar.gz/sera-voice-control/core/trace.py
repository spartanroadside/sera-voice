import uuid
from typing import Optional

from fastapi import Header


def ensure_trace_id(x_trace_id: Optional[str]) -> str:
    """Return a valid trace id (prefer incoming header, otherwise generate)."""
    if x_trace_id and isinstance(x_trace_id, str) and x_trace_id.strip():
        return x_trace_id.strip()
    return str(uuid.uuid4())


def trace_header(x_trace_id: Optional[str] = Header(default=None)) -> str:
    """FastAPI dependency to fetch/ensure trace id."""
    return ensure_trace_id(x_trace_id)
