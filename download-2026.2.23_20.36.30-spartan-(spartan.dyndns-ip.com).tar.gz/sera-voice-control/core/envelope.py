from __future__ import annotations

from typing import Any, Dict, Optional


def ok(data: Any = None, *, message: str = "", code: str = "OK", trace_id: str, run_id: Optional[str] = None) -> Dict[str, Any]:
    """Standard success envelope."""
    return {
        "status": "ok",
        "code": code,
        "message": message,
        "trace_id": trace_id,
        "run_id": run_id,
        "data": {} if data is None else data,
    }


def error(*, code: str, message: str, trace_id: str, run_id: Optional[str] = None, data: Any = None) -> Dict[str, Any]:
    """Standard error envelope."""
    return {
        "status": "error",
        "code": code,
        "message": message,
        "trace_id": trace_id,
        "run_id": run_id,
        "data": {} if data is None else data,
    }


# Backwards-compatible alias used by some routes/modules.
# Prefer `error(...)` going forward.
def err(*, code: str, message: str, trace_id: str, run_id: Optional[str] = None, data: Any = None) -> Dict[str, Any]:
    return error(code=code, message=message, trace_id=trace_id, run_id=run_id, data=data)
