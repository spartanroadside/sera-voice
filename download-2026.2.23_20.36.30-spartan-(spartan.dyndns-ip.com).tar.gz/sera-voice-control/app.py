import os
import re
import json
from typing import Optional, Dict, Any

import requests
from fastapi import FastAPI

from agent.sera_processor import parse_user_input, new_confirm_token
from agent.middleware.trace_context import TraceContextMiddleware
from agent.middleware.session_context import SessionContextMiddleware

try:
    from agent.db.migrate import apply_all
except Exception:
    apply_all = None

from agent.routes.docs import router as docs_router
from agent.routes.db import router as db_router
from agent.routes.session import router as session_router
from agent.routes.meta import router as meta_router
from pydantic import BaseModel

try:
    from openai import OpenAI
except Exception:
    OpenAI = None  # type: ignore

app = FastAPI(title="SERA Agent Runner")

_CONFIRM_CACHE: Dict[str, Dict[str, Any]] = {}

app.add_middleware(TraceContextMiddleware)
app.add_middleware(SessionContextMiddleware)


@app.on_event("startup")
def _startup_db_migrate():
    if os.getenv("SERA_DB_AUTO_MIGRATE", "0") == "1" and apply_all is not None:
        try:
            apply_all()
        except Exception:
            pass


TOOL_URL = os.environ.get("TOOL_URL", "http://127.0.0.1:3100")
TOKEN = os.environ.get("TOOLGATEWAY_SECRET", "")
MODEL = os.environ.get("AGENT_MODEL", "gpt-4o-mini")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
AI_PROVIDER = os.environ.get("AI_PROVIDER", "openai").lower()

_client = OpenAI(api_key=OPENAI_API_KEY) if (AI_PROVIDER == "openai" and OpenAI and OPENAI_API_KEY) else None


class AskReq(BaseModel):
    user: str
    confirm: Optional[str] = None


def _tool_post(path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    headers = {"X-Tool-Token": TOKEN, "Content-Type": "application/json"}
    r = requests.post(f"{TOOL_URL}{path}", headers=headers, data=json.dumps(payload), timeout=60)
    try:
        body = r.json()
    except Exception:
        body = {"text": r.text}
    return {"http": r.status_code, "body": body}


def _tool_get(path: str, params: Dict[str, Any]) -> Dict[str, Any]:
    headers = {"X-Tool-Token": TOKEN}
    r = requests.get(f"{TOOL_URL}{path}", headers=headers, params=params, timeout=30)
    try:
        body = r.json()
    except Exception:
        body = {"text": r.text}
    body["_http_status"] = r.status_code
    return body


@app.get("/health")
def health():
    """
    Lightweight health endpoint.
    Prefers install-time metadata from environment variables.
    Falls back to VERSION file inside container if present.
    """

    version = (os.getenv("SERA_VERSION") or "").strip() or "unknown"
    build_date = (os.getenv("SERA_BUILD_DATE") or "").strip() or None
    bundle = (os.getenv("SERA_BUNDLE") or "").strip() or None

    if version == "unknown" or build_date is None:
        try:
            from pathlib import Path
            from datetime import datetime

            version_path = Path(__file__).resolve().parents[1] / "VERSION"
            if version_path.exists():
                txt = version_path.read_text(encoding="utf-8").strip()
                if txt:
                    version = txt
                if build_date is None:
                    build_date = datetime.fromtimestamp(
                        version_path.stat().st_mtime
                    ).isoformat()
        except Exception:
            pass

    resp = {"ok": True, "version": version, "build_date": build_date}
    if bundle:
        resp["bundle"] = bundle
    return resp


@app.get("/llm/ping")
def llm_ping():
    return {
        "ok": True,
        "provider": AI_PROVIDER,
        "model": MODEL,
        "has_api_key": bool(OPENAI_API_KEY),
        "client_ready": bool(_client),
    }


@app.post("/llm/test")
def llm_test(payload: Dict[str, Any]):
    text = (payload or {}).get("text") or "ping"
    if not _client:
        return {"ok": False, "error": "LLM client not configured", "provider": AI_PROVIDER, "model": MODEL}
    try:
        resp = _client.responses.create(
            model=MODEL,
            input=[
                {"role": "system", "content": "Reply with a single short sentence confirming you received the message."},
                {"role": "user", "content": str(text)},
            ],
        )
        out_text = getattr(resp, "output_text", None) or ""
        return {"ok": True, "reply": out_text}
    except Exception as e:
        return {"ok": False, "error": str(e)}


app.include_router(docs_router)
app.include_router(db_router)
app.include_router(session_router)
app.include_router(meta_router)