from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import json

from agent.db import get_db

router = APIRouter(prefix="/session", tags=["session"])

class SessionCreate(BaseModel):
    session_id: str
    meta: dict = {}

@router.post("/create")
def create_session(data: SessionCreate):
    db = get_db()
    meta_json = json.dumps(data.meta or {}, separators=(",", ":"), ensure_ascii=False)
    db.execute(
        "INSERT INTO sessions(session_id, meta_json) VALUES(?, ?) "
        "ON CONFLICT(session_id) DO UPDATE SET meta_json=excluded.meta_json",
        [data.session_id, meta_json],
    )
    return {"ok": True, "session_id": data.session_id}

@router.get("/get/{session_id}")
def get_session(session_id: str):
    db = get_db()
    row = db.query_one("SELECT session_id, created_at, meta_json FROM sessions WHERE session_id = ?", [session_id])
    if not row:
        raise HTTPException(status_code=404, detail={"error":"not_found","session_id":session_id})
    sid, created_at, meta_json = row
    try:
        meta = json.loads(meta_json or "{}")
    except Exception:
        meta = {}
    return {"ok": True, "session_id": sid, "created_at": created_at, "meta": meta}

@router.get("/list")
def list_sessions(limit: int = 50):
    limit = max(1, min(int(limit), 500))
    db = get_db()
    rows = db.query_all("SELECT session_id, created_at FROM sessions ORDER BY created_at DESC LIMIT ?", [limit])
    return {"ok": True, "sessions": [{"session_id": r[0], "created_at": r[1]} for r in rows]}
