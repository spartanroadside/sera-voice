from __future__ import annotations

from datetime import datetime
from pathlib import Path

from fastapi import APIRouter

from agent.core.envelope import ok
from agent.core.trace import trace_header


router = APIRouter(prefix="/api/meta", tags=["meta"])


def _repo_root() -> Path:
    # agent/routes/meta.py -> agent/routes -> agent -> repo root
    return Path(__file__).resolve().parents[2]


@router.get("/version")
def get_version(trace_id: str = trace_header()):
    """Return deployed version and build timestamp.

    Version source of truth is the repo root VERSION file.
    """
    version_path = _repo_root() / "VERSION"
    version = "unknown"
    build_date = None
    if version_path.exists():
        try:
            version = version_path.read_text(encoding="utf-8").strip() or "unknown"
        except Exception:
            version = "unknown"
        try:
            build_date = datetime.fromtimestamp(version_path.stat().st_mtime).isoformat()
        except Exception:
            build_date = None

    return ok({"version": version, "build_date": build_date}, trace_id=trace_id)
