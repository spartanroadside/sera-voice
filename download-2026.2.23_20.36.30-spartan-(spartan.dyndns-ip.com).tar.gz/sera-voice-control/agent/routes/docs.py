from __future__ import annotations

from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, JSONResponse

from agent.core.envelope import ok, error
from agent.core.trace import trace_header


router = APIRouter(prefix="/api/docs", tags=["docs"])


def _repo_root() -> Path:
    # agent/routes/docs.py -> agent/routes -> agent -> repo root
    return Path(__file__).resolve().parents[2]


SPECS_ROOT = _repo_root() / "docs" / "_structured" / "08_specs"
OPENAPI_PATH = SPECS_ROOT / "api" / "openapi.yaml"
SCHEMAS_DIR = SPECS_ROOT / "api" / "schemas"


@router.get("/openapi.yaml")
def get_openapi_yaml(trace_id: str = trace_header()):
    if not OPENAPI_PATH.exists():
        return JSONResponse(status_code=404, content=error(code="DOCS_NOT_FOUND", message="openapi.yaml not found", trace_id=trace_id))
    return FileResponse(path=str(OPENAPI_PATH), media_type="text/yaml")


@router.get("/schemas/{name}")
def get_schema(name: str, trace_id: str = trace_header()):
    # Security: prevent path traversal
    if "/" in name or "\\" in name or name.startswith("."):
        raise HTTPException(status_code=400, detail="invalid schema name")
    p = (SCHEMAS_DIR / name).resolve()
    if not str(p).startswith(str(SCHEMAS_DIR.resolve())):
        raise HTTPException(status_code=400, detail="invalid schema path")
    if not p.exists():
        return JSONResponse(status_code=404, content=error(code="DOCS_NOT_FOUND", message=f"schema not found: {name}", trace_id=trace_id))
    return FileResponse(path=str(p), media_type="application/json")


@router.get("/index")
def docs_index(trace_id: str = trace_header()):
    schemas = []
    if SCHEMAS_DIR.exists():
        schemas = sorted([f.name for f in SCHEMAS_DIR.glob("*.json")])
    data = {
        "openapi": "/api/docs/openapi.yaml" if OPENAPI_PATH.exists() else None,
        "schemas": {name: f"/api/docs/schemas/{name}" for name in schemas},
        "spec_root": str(SPECS_ROOT),
    }
    return ok(data, trace_id=trace_id)
