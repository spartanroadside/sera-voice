from fastapi import APIRouter
import os

from agent.db import get_db

router = APIRouter(prefix="/db", tags=["db"])

@router.get("/health")
def db_health():
    db_type = os.getenv("DB_TYPE", "sqlite")
    db_path = os.getenv("DB_PATH", "/home/spartan/sera/sera-ai/data/sera.db")
    db = get_db()
    ok = True
    detail = {}
    try:
        row = db.query_one("SELECT name FROM sqlite_master WHERE type='table' AND name='sessions';")
        ok = bool(row)
        detail["sessions_table"] = "OK" if ok else "MISSING"
    except Exception as e:
        ok = False
        detail["error"] = str(e)
    return {"ok": ok, "db_type": db_type, "db_path": db_path, **detail}
