from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from agent.core.logging import emit
from agent.core.security.execution_guard import UserContext, authorize

router = APIRouter(prefix="", tags=["execute"])

class ExecuteReq(BaseModel):
    module: str
    payload: dict = {}
    user_id: str = "local"
    role: str = "admin"
    allowed_actions: list[str] | None = None

@router.post("/execute")
def execute(req: ExecuteReq, request: Request):
    rid = getattr(request.state, "request_id", None)
    action = f"module:{req.module}"
    user = UserContext(user_id=req.user_id, role=req.role, allowed_actions=req.allowed_actions)

    if not authorize(user, action):
        emit("WARN", "agent", "authorize_denied", request_id=rid, user={"id": user.user_id, "role": user.role}, context={"action": action})
        raise HTTPException(status_code=403, detail={"error": "forbidden", "action": action})

    registry = getattr(request.app.state, "registry", None)
    if registry is None:
        raise HTTPException(status_code=500, detail="registry not initialized")

    emit("INFO", "agent", "execute_start", request_id=rid, user={"id": user.user_id, "role": user.role}, context={"module": req.module})
    try:
        result = registry.execute(req.module, req.payload)
    except KeyError:
        emit("WARN", "agent", "execute_unknown_module", request_id=rid, context={"module": req.module})
        raise HTTPException(status_code=404, detail={"error": "unknown_module", "module": req.module})
    except Exception as e:
        emit("ERROR", "agent", "execute_error", request_id=rid, context={"module": req.module, "error": str(e)})
        raise HTTPException(status_code=500, detail={"error": "execution_failed", "module": req.module})

    emit("INFO", "agent", "execute_ok", request_id=rid, context={"module": req.module})
    return {"ok": True, "module": req.module, "result": result}

@router.get("/modules")
def list_modules(request: Request):
    registry = getattr(request.app.state, "registry", None)
    if registry is None:
        raise HTTPException(status_code=500, detail="registry not initialized")
    return {"ok": True, "modules": registry.list()}
