"""Database adapter abstraction (Phase 1).

Current implementation still uses SQLite via agent.db.connection.
This module provides a stable interface so we can switch to MySQL later.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class DBConfig:
    backend: str = "sqlite"  # sqlite|mysql
    sqlite_path: str = "/workspace/sera.db"
    mysql_dsn: Optional[str] = None


class DBAdapter:
    def __init__(self, cfg: DBConfig):
        self.cfg = cfg

    @property
    def backend(self) -> str:
        return (self.cfg.backend or "sqlite").lower().strip()
