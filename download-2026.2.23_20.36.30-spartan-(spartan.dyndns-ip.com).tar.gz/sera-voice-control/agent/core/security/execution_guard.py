from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class UserContext:
    user_id: str = "local"
    role: str = "admin"  # admin|privileged|user|guest
    allowed_actions: Optional[List[str]] = None

def authorize(user: UserContext, action: str) -> bool:
    if user.role == "admin":
        return True
    if user.allowed_actions is None:
        return False
    return action in user.allowed_actions
