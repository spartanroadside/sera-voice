import json
import os
from datetime import datetime
from typing import Any, Dict, Optional

LOG_PATH_DEFAULT = "/logs/agent.jsonl"
SERVICE_DEFAULT = "agent-runner"

def _now():
    return datetime.utcnow().isoformat(timespec="milliseconds") + "Z"

def emit(
    level: str,
    module: str,
    event: str,
    *,
    request_id: Optional[str] = None,
    user: Optional[dict] = None,
    context: Optional[Dict[str, Any]] = None,
    service: Optional[str] = None,
    duration_ms: Optional[float] = None,
    error: Optional[str] = None,
):
    entry: Dict[str, Any] = {
        "ts": _now(),
        "level": level.upper(),
        "service": service or os.getenv("SERA_SERVICE", SERVICE_DEFAULT),
        "module": module,
        "event": event,
        "request_id": request_id,
        "user": user or {},
        "context": context or {},
    }
    if duration_ms is not None:
        entry["duration_ms"] = duration_ms
    if error:
        entry["error"] = error

    line = json.dumps(entry, separators=(",", ":"), ensure_ascii=False)

    # stdout always
    print(line)

    # best-effort file append (non-fatal)
    path = os.getenv("SERA_AGENT_LOG", LOG_PATH_DEFAULT)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
