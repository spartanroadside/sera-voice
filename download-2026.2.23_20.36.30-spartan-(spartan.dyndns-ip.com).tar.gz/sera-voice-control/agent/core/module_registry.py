from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, Optional

@dataclass
class ModuleSpec:
    name: str
    version: str
    execute: Callable[[dict], dict]
    description: str = ""

class ModuleRegistry:
    def __init__(self) -> None:
        self._mods: Dict[str, ModuleSpec] = {}

    def register(self, spec: ModuleSpec) -> None:
        self._mods[spec.name] = spec

    def list(self) -> Dict[str, dict]:
        return {k: {"version": v.version, "description": v.description} for k, v in self._mods.items()}

    def get(self, name: str) -> Optional[ModuleSpec]:
        return self._mods.get(name)

    def execute(self, name: str, payload: dict) -> dict:
        mod = self.get(name)
        if not mod:
            raise KeyError(f"Unknown module: {name}")
        return mod.execute(payload or {})
