from fastapi import FastAPI
from agent.middleware.request_id import RequestIdMiddleware
from agent.core.module_registry import ModuleRegistry, ModuleSpec
from agent.routes import session
from agent.routes import execute as execute_route
from agent.routes import db as db_route

from agent.modules.system import ping as mod_ping
from agent.modules.system import echo as mod_echo

app = FastAPI()

# Middleware
app.add_middleware(RequestIdMiddleware)

# Registry init
registry = ModuleRegistry()
registry.register(ModuleSpec(name="system.ping", version="1.0.0", execute=mod_ping.execute, description="Health ping"))
registry.register(ModuleSpec(name="system.echo", version="1.0.0", execute=mod_echo.execute, description="Echo payload"))
app.state.registry = registry

# Routes
app.include_router(session.router)
app.include_router(execute_route.router)
app.include_router(db_route.router)

@app.get("/health")
def health():
    return {"status": "ok", "modules": registry.list()}
