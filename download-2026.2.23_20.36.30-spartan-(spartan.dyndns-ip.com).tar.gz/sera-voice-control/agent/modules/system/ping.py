def execute(payload: dict) -> dict:
    return {"ok": True, "reply": "pong", "payload": payload or {}}
