def execute(payload: dict) -> dict:
    return {"ok": True, "echo": payload or {}}
