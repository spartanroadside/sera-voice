class SeraProcessor:

    def process(self, payload: dict) -> dict:
        return {
            "received": payload,
            "status": "processed"
        }
