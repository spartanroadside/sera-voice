from __future__ import annotations

SCHEMA_SQLITE = [
    # sessions table (minimal)
    """CREATE TABLE IF NOT EXISTS sessions (
        session_id TEXT PRIMARY KEY,
        created_at TEXT DEFAULT (datetime('now')),
        meta_json TEXT DEFAULT '{}'
    );""",
]
