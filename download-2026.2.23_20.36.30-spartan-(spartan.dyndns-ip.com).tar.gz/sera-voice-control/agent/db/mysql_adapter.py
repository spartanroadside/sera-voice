from __future__ import annotations
# Placeholder adapter: wire in mysqlclient or pymysql later.
# This exists so DB_TYPE=mysql can be implemented without refactoring callers.

class MySQLAdapter:
    def __init__(self, host: str, port: int, user: str, password: str, database: str) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database

    def connect(self) -> None:
        raise NotImplementedError("MySQL adapter not implemented yet (Phase 2)")

    def close(self) -> None:
        return

    def execute(self, sql: str, params=None) -> None:
        raise NotImplementedError("MySQL adapter not implemented yet (Phase 2)")

    def query_one(self, sql: str, params=None):
        raise NotImplementedError("MySQL adapter not implemented yet (Phase 2)")

    def query_all(self, sql: str, params=None):
        raise NotImplementedError("MySQL adapter not implemented yet (Phase 2)")
