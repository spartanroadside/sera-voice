from __future__ import annotations
import os
import sqlite3
from typing import Any, Optional, Sequence, Tuple

from agent.db.schema import SCHEMA_SQLITE

class SQLiteAdapter:
    def __init__(self, path: str) -> None:
        self.path = path
        self.conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL;")
        self.conn.execute("PRAGMA foreign_keys=ON;")

    def close(self) -> None:
        if self.conn:
            self.conn.close()
            self.conn = None

    def execute(self, sql: str, params: Sequence[Any] | None = None) -> None:
        assert self.conn is not None
        cur = self.conn.cursor()
        cur.execute(sql, params or [])
        self.conn.commit()

    def query_one(self, sql: str, params: Sequence[Any] | None = None) -> Optional[Tuple[Any, ...]]:
        assert self.conn is not None
        cur = self.conn.cursor()
        cur.execute(sql, params or [])
        return cur.fetchone()

    def query_all(self, sql: str, params: Sequence[Any] | None = None) -> list[Tuple[Any, ...]]:
        assert self.conn is not None
        cur = self.conn.cursor()
        cur.execute(sql, params or [])
        return cur.fetchall()

    def init_schema(self) -> None:
        for stmt in SCHEMA_SQLITE:
            self.execute(stmt)
