from __future__ import annotations
import os
from typing import Optional

from agent.db.sqlite_adapter import SQLiteAdapter
from agent.db.mysql_adapter import MySQLAdapter

_db_singleton = None

def get_db():
    global _db_singleton
    if _db_singleton is not None:
        return _db_singleton

    db_type = os.getenv("DB_TYPE", "sqlite").lower()
    if db_type == "sqlite":
        path = os.getenv("DB_PATH", "/home/spartan/sera/sera-ai/data/sera.db")
        db = SQLiteAdapter(path)
        db.connect()
        db.init_schema()
        _db_singleton = db
        return db

    if db_type == "mysql":
        host = os.getenv("MYSQL_HOST", "127.0.0.1")
        port = int(os.getenv("MYSQL_PORT", "3306"))
        user = os.getenv("MYSQL_USER", "sera")
        password = os.getenv("MYSQL_PASSWORD", "")
        database = os.getenv("MYSQL_DATABASE", "sera")
        db = MySQLAdapter(host, port, user, password, database)
        db.connect()
        _db_singleton = db
        return db

    raise ValueError(f"Unsupported DB_TYPE: {db_type}")
