SERA Logic Service

Port: 3300
Purpose:
- Enforce edit contract
- Normalize plans
- Proxy tool-gateway calls with token authentication

Environment:
TOOL_URL=http://tool-gateway:3100
TOOL_TOKEN=<same as TOOLGATEWAY_SECRET>
CONTRACT_MODE=strict|warn
