import os
import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Any, Dict, Optional
from jsonschema import validate as js_validate, ValidationError

TOOL_URL = os.environ.get("TOOL_URL", "http://tool-gateway:3100")
TOOL_TOKEN = os.environ.get("TOOL_TOKEN", "")
CONTRACT_MODE = os.environ.get("CONTRACT_MODE", "strict")

app = FastAPI(title="SERA Logic", version="0.1.0")

EDIT_CONTRACT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "required": ["intent", "actions"],
    "properties": {
        "intent": {"type": "string", "minLength": 1},
        "actions": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["tool", "args"],
                "properties": {
                    "tool": {"type": "string"},
                    "args": {"type": "object"},
                    "note": {"type": "string"},
                },
                "additionalProperties": False,
            },
        },
        "meta": {"type": "object"},
    },
    "additionalProperties": False,
}

class ValidateReq(BaseModel):
    payload: Dict[str, Any]

class ToolProxyReq(BaseModel):
    path: str
    method: str = "GET"
    json: Optional[Dict[str, Any]] = None
    params: Optional[Dict[str, Any]] = None

@app.get("/health")
def health():
    return {"ok": True, "service": "sera-logic", "mode": CONTRACT_MODE}

@app.post("/contract/validate")
def contract_validate(req: ValidateReq):
    try:
        js_validate(instance=req.payload, schema=EDIT_CONTRACT_SCHEMA)
        return {"ok": True}
    except ValidationError as e:
        if CONTRACT_MODE == "strict":
            raise HTTPException(status_code=422, detail=e.message)
        return {"ok": False, "warning": str(e)}

@app.post("/plan/normalize")
def plan_normalize(req: ValidateReq):
    contract_validate(req)
    return {"ok": True, "normalized": req.payload}

@app.post("/tool/proxy")
def tool_proxy(req: ToolProxyReq):
    if not TOOL_TOKEN:
        raise HTTPException(status_code=500, detail="Missing TOOL_TOKEN")

    url = TOOL_URL.rstrip("/") + req.path
    headers = {"x-tool-token": TOOL_TOKEN}

    try:
        r = requests.request(
            method=req.method.upper(),
            url=url,
            headers=headers,
            json=req.json,
            params=req.params,
            timeout=20,
        )
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=str(e))

    if r.status_code >= 400:
        raise HTTPException(status_code=r.status_code, detail=r.text)

    try:
        return r.json()
    except Exception:
        return {"ok": True, "raw": r.text}
