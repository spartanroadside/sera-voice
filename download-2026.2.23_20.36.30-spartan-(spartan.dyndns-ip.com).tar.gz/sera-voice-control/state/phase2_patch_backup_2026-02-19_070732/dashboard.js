// Dashboard controller for SERA AI UI (Sera AI Ver 1.001)
// Fix: nav buttons now actually switch visible pages.

const $ = (id) => document.getElementById(id);

async function fetchJson(url) {
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error(`${url} -> ${r.status}`);
  return await r.json();
}


function getBakedMeta(){
  const m = (window.__SERA_META__ || {});
  return {
    build_id: (m.build_id || "").toString(),
    built_at: (m.built_at || "").toString(),
  };
}

async function loadMetaForFooter(){
  // Prefer backend /api/meta when available; fallback to baked version.js
  const baked = getBakedMeta();
  let build_id = baked.build_id || "";
  let status = "STARTING";
  try{
    const j = await fetchJson("/api/meta");
    if(j && j.ok){
      build_id = (j.build_id || build_id || "").toString();
      status = "OK";
    }else{
      status = "OFFLINE";
    }
  }catch{
    status = "OFFLINE";
  }
  return { build_id, status };
}


function setFooter({ build_id = "", status = "OK" } = {}) {
  const el = $("footerStatus");
  if (!el) return;
  const st = status || "OK";
  // Footer details are handled by footer_meta.js; keep this status-only.
  el.textContent = ["SERA AI", st].join(" • ");
}


async function refreshStatus() {
  try {
    const m = await loadMetaForFooter();
    setFooter({ build_id: m.build_id, status: m.status });
  } catch (e) {
    console.warn("refreshStatus failed", e);
    setFooter({ build_id: "", status: "OFFLINE" });
  }
}

async function refreshPills() {
  // Optional endpoint provided by sysdiag container. UI should not break if absent.
  try {
    const j = await fetchJson("/sysdiag/system.json");
    if (j && typeof j === "object") {
      if ($("cpuPct")) $("cpuPct").textContent = (j.cpu?.pct ?? j.cpu_pct ?? "–");
      if ($("memPct")) $("memPct").textContent = (j.mem?.pct ?? j.mem_pct ?? "–");
      if ($("load1")) $("load1").textContent = (j.load?.one ?? j.load1 ?? "–");
    }
  } catch { /* ignore */ }
}

function showPage(pageId) {
  const pages = Array.from(document.querySelectorAll(".page"));
  let found = false;
  for (const p of pages) {
    const isTarget = p.id === `page-${pageId}`;
    p.style.display = isTarget ? "block" : "none";
    if (isTarget) found = true;
  }
  if (!found) {
    // Fallback: show voice
    for (const p of pages) p.style.display = (p.id === "page-voice") ? "block" : "none";
    pageId = "voice";
  }

  // Active nav state
  document.querySelectorAll("[data-page]").forEach((btn) => {
    const isActive = btn.getAttribute("data-page") === pageId;
    btn.classList.toggle("active", isActive);
    btn.classList.toggle("primary", isActive);
  });

  // Persist navigation in hash (deep link / refresh friendly)
  try { window.location.hash = `#${pageId}`; } catch { /* ignore */ }
}

function wireNav() {
  document.querySelectorAll("[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => showPage(btn.getAttribute("data-page")));
  });

  // In-page links that navigate to other pages (e.g., Settings shortcuts)
  document.querySelectorAll("[data-nav]").forEach((a) => {
    a.addEventListener("click", (e) => {
      e.preventDefault();
      const target = a.getAttribute("data-nav") || "";
      if (target) showPage(target);
    });
  });

  // Back/forward hash nav
  window.addEventListener("hashchange", () => {
    const page = String(window.location.hash || "").replace(/^#/, "");
    if (page) showPage(page);
  });
}


function wireUserMenu(){
  const btn = $("userBtn");
  const dd  = $("userDropdown");
  if(btn && dd){
    btn.addEventListener("click", () => {
      dd.style.display = (dd.style.display === "none" || !dd.style.display) ? "block" : "none";
    });
    document.addEventListener("click", (e) => {
      if(!btn.contains(e.target) && !dd.contains(e.target)) dd.style.display = "none";
    });
  }
  document.querySelectorAll("#userDropdown [data-action]").forEach((b) => {
    b.addEventListener("click", () => {
      const action = b.getAttribute("data-action");
      if(action === "settings") showPage("settings");
      dd && (dd.style.display = "none");
    });
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  wireNav();
  wireUserMenu();
  await refreshStatus();

  const initial = String(window.location.hash || "").replace(/^#/, "") || "voice";
  showPage(initial);

  refreshPills();
  setInterval(refreshStatus, 15000);
  setInterval(refreshPills, 5000);
});