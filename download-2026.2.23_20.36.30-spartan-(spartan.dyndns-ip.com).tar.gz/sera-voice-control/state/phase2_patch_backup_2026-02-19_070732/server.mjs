// gateway/server.mjs
// SERA Voice Gateway / UI API Gateway (Express)
//
// Goals:
// - UI calls /api/* ONLY and always gets JSON (never HTML Cannot GET/POST)
// - Proxy tool-gateway with X-Tool-Token (TOOLGATEWAY_SECRET)
// - Provide UI compatibility aliases for legacy routes
// - Persist state in /state (bind mounted)
// - Realtime /session requires OPENAI_API_KEY
//
// Node 18+ required (fetch + FormData)

import express from "express";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import os from "os";
import http from "http";
import https from "https";
import net from "net";
import { fileURLToPath } from "url";

const app = express();
app.set("trust proxy", true);

// ---------- env / config ----------
const PORT = Number(process.env.PORT || 3000);

const ACTION_LOG_PATH = process.env.ACTION_LOG_PATH || "/logs/actions.jsonl";
const SAFE_MODE_RAW = String(process.env.SAFE_MODE ?? process.env.SERA_SAFE_MODE ?? "1").toLowerCase();
const SAFE_MODE_BOOL = !["0", "false", "no", "off", ""].includes(SAFE_MODE_RAW);

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const REALTIME_MODEL = process.env.REALTIME_MODEL || "gpt-realtime";
const VOICE = process.env.REALTIME_VOICE || "marin";

const AGENT_URL = process.env.AGENT_URL || "http://127.0.0.1:3200";
const TOOL_URL = process.env.TOOL_URL || "http://127.0.0.1:3100";
const TOOL_TOKEN = process.env.TOOLGATEWAY_SECRET || "";

const DEBUG_DIR_MOUNT = process.env.DEBUG_DIR_MOUNT || "/debug";

// Persistent state
const STATE_DIR = process.env.STATE_DIR || "/state";
const SYSTEM_CHECKLIST_PATH = process.env.SYSTEM_CHECKLIST_PATH || path.join(STATE_DIR, "system_checklist.json");
const SETTINGS_PATH = process.env.SETTINGS_PATH || path.join(STATE_DIR, "app_settings.json");
const PROFILES_PATH = process.env.PROFILES_PATH || path.join(STATE_DIR, "profiles.json");
const SYSDIAG_LAST_PATH = process.env.SYSDIAG_LAST_PATH || path.join(STATE_DIR, "sysdiag_last.json");

// ---------- helpers ----------
function nowIso() {
  return new Date().toISOString();
}

function reqId(req) {
  const h = req.headers["x-request-id"];
  if (h) return String(h);
  if (crypto.randomUUID) return crypto.randomUUID();
  return crypto.randomBytes(16).toString("hex");
}

function ensureDirFor(filePath) {
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
  } catch {}
}

function safeWriteJsonl(obj) {
  try {
    ensureDirFor(ACTION_LOG_PATH);
    fs.appendFileSync(ACTION_LOG_PATH, JSON.stringify(obj) + "\n", { encoding: "utf8" });
  } catch (e) {
    console.error("action-log write failed", e);
  }
}

// Ensure UI-provided relative paths cannot escape their intended root.
function sanitizeRelPath(p) {
  const s = String(p ?? "").trim().replace(/\\/g, "/");
  const noLead = s.replace(/^\/+/, "");
  if (noLead === "") return "";
  const parts = noLead.split("/").filter(Boolean);
  for (const seg of parts) {
    if (seg === "." || seg === "..") throw new Error("Invalid path segment");
    if (seg.includes("..")) throw new Error("Invalid path segment");
  }
  return parts.join("/");
}

function readJsonFile(filePath) {
  try {
    const raw = fs.readFileSync(filePath, "utf8");
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function atomicWriteJson(filePath, obj) {
  ensureDirFor(filePath);
  const tmp = `${filePath}.tmp`;
  const data = JSON.stringify(obj, null, 2);
  const fd = fs.openSync(tmp, "w");
  try {
    fs.writeFileSync(fd, data, { encoding: "utf8" });
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
  fs.renameSync(tmp, filePath);
}

function readRunInfo() {
  try {
    const p = path.resolve("./RUN_INFO.txt");
    return fs.readFileSync(p, "utf8").trim();
  } catch {
    return "";
  }
}

function readVersionFile() {
  try {
    const fp = fileURLToPath(new URL("./VERSION", import.meta.url));
    if (fs.existsSync(fp)) return String(fs.readFileSync(fp, "utf8") || "").trim() || "";
  } catch {}
  return "";
}

function readBuildId() {
  const metaPath = path.join(STATE_DIR, "build_meta.json");
  try {
    ensureDirFor(metaPath);
    if (fs.existsSync(metaPath)) {
      const o = JSON.parse(fs.readFileSync(metaPath, "utf8"));
      if (o && o.build_id) return String(o.build_id);
    }
    const id = new Date().toISOString().replace(/[:.]/g, "-").replace("T", "_");
    const tmp = metaPath + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify({ build_id: id, created_at: nowIso() }, null, 2), "utf8");
    fs.renameSync(tmp, metaPath);
    return id;
  } catch {
    return "UNKNOWN";
  }
}

const RUN_TAG = (process.env.SERA_VERSION || process.env.RUN_TAG || readRunInfo() || readVersionFile() || "UNKNOWN").trim();
const BUILD_ID = (process.env.BUILD_ID || readBuildId()).trim();

function runtimeMeta() {
  return {
    ok: true,
    version: RUN_TAG,
    build_date: process.env.SERA_BUILD_DATE || null,
    bundle: process.env.SERA_BUNDLE || null,
    bundle_tag: process.env.SERA_BUNDLE_TAG || null,
    channel: process.env.SERA_CHANNEL || null,
    build_id: BUILD_ID,
  };
}

function reqOrigin(req) {
  const proto = String(req.headers["x-forwarded-proto"] || req.protocol || "http").split(",")[0].trim();
  const host = req.get("host") || "";
  return `${proto}://${host}`;
}

function getHostIfaces() {
  try {
    const nets = os.networkInterfaces();
    const ips = [];
    for (const name of Object.keys(nets || {})) {
      for (const n of nets[name] || []) {
        if (n && n.family === "IPv4" && !n.internal) ips.push({ name, address: n.address });
      }
    }
    return ips;
  } catch {
    return [];
  }
}

function normalizeBaseUrl(u) {
  if (!u) return "";
  return String(u).trim().replace(/\/+$/, "");
}

function deriveBaseUrlFromRequest(req) {
  try {
    const proto = String(req.headers["x-forwarded-proto"] || "http").split(",")[0].trim();
    const host = String(req.headers["x-forwarded-host"] || req.headers.host || "").split(",")[0].trim();
    if (host) return normalizeBaseUrl(`${proto}://${host}`);
  } catch {}
  return "";
}

function withSchemeAndPort(baseUrl, scheme, port) {
  if (!baseUrl) return "";
  try {
    const u = new URL(baseUrl);
    u.protocol = scheme + ":";
    if (port) u.port = String(port);
    return normalizeBaseUrl(u.toString());
  } catch {
    return "";
  }
}

function hostWithoutPortFromHeaders(req) {
  const hostHeader = String(req.headers["x-forwarded-host"] || req.headers.host || "");
  const hostFirst = hostHeader.split(",")[0].trim();
  return hostFirst.replace(/:\d+$/, ""); // strip any port
}

// Phase 2: resolve workspace root consistently (container + host)
function resolveWorkspacesDir() {
  const explicit =
    process.env.WORKSPACES_DIR ||
    process.env.SERA_WORKSPACES_DIR ||
    (process.env.SERA_ROOT ? path.join(process.env.SERA_ROOT, "workspaces") : "");

  const candidates = [
    explicit,
    "/sera-ai/workspaces", // typical container mount
    "/home/spartan/sera/sera-ai/workspaces", // common host path
  ].filter(Boolean);

  for (const c of candidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isDirectory()) return c;
    } catch {}
  }

  // fall back to first candidate even if missing (for clearer error paths)
  return candidates[0] || "";
}

// ---------- action logging middleware ----------
app.use((req, res, next) => {
  const id = reqId(req);
  req._request_id = id;
  res.setHeader("X-Request-Id", id);
  const start = Date.now();

  res.on("finish", () => {
    const loggable = req.path.startsWith("/api/") || ["/agent", "/session"].includes(req.path);
    if (!loggable) return;

    let project;
    try {
      project = (req.body && (req.body.project || req.body.project_id)) || req.query?.project;
    } catch {}

    safeWriteJsonl({
      ts: nowIso(),
      request_id: id,
      method: req.method,
      path: req.path,
      status: res.statusCode,
      ms: Date.now() - start,
      project,
      ua: req.headers["user-agent"],
      ip: req.headers["x-forwarded-for"] || req.socket?.remoteAddress,
    });
  });

  next();
});

// ---------- body parsing ----------
app.use("/session", express.text({ type: ["application/sdp", "text/plain", "application/sdp;charset=UTF-8"] }));
app.use("/agent", express.json({ limit: "1mb" }));
app.use(express.json({ limit: "10mb" }));

// ---------- tool helpers ----------
function requireToolToken(res) {
  if (TOOL_TOKEN) return true;
  res.status(500).json({ ok: false, error: "Missing TOOLGATEWAY_SECRET" });
  return false;
}

async function toolPost(apiPath, payload) {
  if (!TOOL_TOKEN) throw new Error("Missing TOOLGATEWAY_SECRET");
  const base = TOOL_URL.replace(/\/$/, "");
  const r = await fetch(`${base}${apiPath}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Tool-Token": TOOL_TOKEN },
    body: JSON.stringify(payload || {}),
  });
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("application/json") ? await r.json() : await r.text();
  if (!r.ok) return { ok: false, status: r.status, body };
  return body;
}

async function toolGet(apiPath) {
  if (!TOOL_TOKEN) throw new Error("Missing TOOLGATEWAY_SECRET");
  const base = TOOL_URL.replace(/\/$/, "");
  const r = await fetch(`${base}${apiPath}`, { headers: { "X-Tool-Token": TOOL_TOKEN }, cache: "no-store" });
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("application/json") ? await r.json() : await r.text();
  if (!r.ok) return { ok: false, status: r.status, body };
  return body;
}

async function passthroughToolGet(req, res, pathname, qsObj = null) {
  if (!requireToolToken(res)) return;
  const base = TOOL_URL.replace(/\/$/, "");
  const q = qsObj ? `?${new URLSearchParams(qsObj).toString()}` : "";
  const r = await fetch(`${base}${pathname}${q}`, {
    headers: { "X-Tool-Token": TOOL_TOKEN },
    cache: "no-store",
  });
  const body = await r.text();
  return res.status(r.status).type(r.headers.get("content-type") || "application/json").send(body);
}

// ---------- health/meta/config/status ----------
if (!OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY not set. OpenAI-backed chat/voice will be unavailable until you add it to .env");
}

app.get("/health", (_req, res) => res.status(200).json(runtimeMeta()));
app.post("/health", (_req, res) => res.status(200).json(runtimeMeta()));
app.get("/version", (_req, res) => res.status(200).json(runtimeMeta()));

app.get("/api/health", (_req, res) => res.status(200).json(runtimeMeta()));

app.get("/api/config", (_req, res) => {
  res.json({
    ok: true,
    run: RUN_TAG,
    build_id: BUILD_ID,
    port: PORT,
    realtime_model: REALTIME_MODEL,
    realtime_voice: VOICE,
    tool_url: TOOL_URL,
    agent_url: AGENT_URL,
    safe_mode: SAFE_MODE_BOOL,
    action_log_path: ACTION_LOG_PATH,
    ui_url: `http://127.0.0.1:${process.env.UI_PORT || "8080"}/`,
  });
});

app.get("/api/meta", (req, res) => {
  res.json({
    ok: true,
    host: req.headers.host || "",
    origin: reqOrigin(req),
    version: RUN_TAG,
    build_date: process.env.SERA_BUILD_DATE || null,
    bundle: process.env.SERA_BUNDLE || null,
    bundle_tag: process.env.SERA_BUNDLE_TAG || null,
    channel: process.env.SERA_CHANNEL || null,
    build_id: BUILD_ID,
  });
});

app.get("/system/meta", (_req, res) => {
  res.status(200).json({
    ok: true,
    ifaces: getHostIfaces(),
    env: { agent_url: AGENT_URL, tool_url: TOOL_URL },
  });
});

app.get("/api/status", async (_req, res) => {
  let toolOk = false;
  let agentOk = false;
  try {
    const r = await fetch(`${TOOL_URL.replace(/\/$/, "")}/health`, {
      headers: TOOL_TOKEN ? { "X-Tool-Token": TOOL_TOKEN } : {},
    });
    toolOk = r.ok;
  } catch {}
  try {
    const r = await fetch(`${AGENT_URL.replace(/\/$/, "")}/health`);
    agentOk = r.ok;
  } catch {}
  return res.json({ ok: true, run: RUN_TAG, voice: true, tool: toolOk, agent: agentOk });
});

app.get("/status", (_req, res) => res.json({ ok: true, run: RUN_TAG }));

// ---------- settings (persistent) ----------
function settingsDefaults() {
  return { ui: { prefer_https: true, default_page: "home" }, sysdiag: { lines_default: 200 } };
}

function mergeSettings(defaultsObj, existing) {
  const out = JSON.parse(JSON.stringify(defaultsObj));
  if (existing && typeof existing === "object") {
    for (const k of Object.keys(out)) {
      if (existing[k] && typeof existing[k] === "object") out[k] = { ...out[k], ...existing[k] };
    }
    for (const [k, v] of Object.entries(existing)) {
      if (!(k in out)) out[k] = v;
    }
  }
  return out;
}

app.get("/api/settings", (_req, res) => {
  const existing = readJsonFile(SETTINGS_PATH);
  res.status(200).json(mergeSettings(settingsDefaults(), existing));
});

app.put("/api/settings", (req, res) => {
  try {
    const existing = readJsonFile(SETTINGS_PATH);
    const next = mergeSettings(settingsDefaults(), { ...(existing || {}), ...(req.body || {}) });
    atomicWriteJson(SETTINGS_PATH, next);
    res.status(200).json({ ok: true, settings: next });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get("/api/settings/effective", (req, res) => {
  const existing = readJsonFile(SETTINGS_PATH);
  const merged = mergeSettings(settingsDefaults(), existing);
  res.status(200).json({
    ok: true,
    origin: reqOrigin(req),
    host: req.get("host") || "",
    forwarded_proto: req.headers["x-forwarded-proto"] || null,
    settings: merged,
  });
});

// ---------- profiles (persistent) ----------
function defaultProfiles() {
  return {
    meta: { updated_at: null, updated_by: null },
    active: "lan",
    profiles: {
      lan: { label: "LAN", base_url: "", notes: "Use LAN IP/hostname when on local network." },
      wan: { label: "WAN", base_url: "", notes: "Use WAN hostname when off-network (no hairpin NAT)." },
      local: { label: "Local", base_url: "http://127.0.0.1:3000", notes: "Direct gateway port from the server host." },
    },
  };
}

function loadProfiles() {
  const cur = readJsonFile(PROFILES_PATH);
  if (cur && typeof cur === "object" && cur.profiles) return cur;
  return defaultProfiles();
}

function saveProfiles(obj) {
  atomicWriteJson(PROFILES_PATH, obj);
  return obj;
}

function effectiveProfile(req) {
  const p = loadProfiles();
  const active = p.active || "lan";
  const prof = p.profiles && p.profiles[active] ? p.profiles[active] : null;
  let base = prof ? normalizeBaseUrl(prof.base_url || "") : "";
  if (!base) base = deriveBaseUrlFromRequest(req);
  return { active, profile: prof, base_url: base };
}

app.get("/api/profiles", (_req, res) => {
  try {
    const p = loadProfiles();
    res.json({ ok: true, ...p });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.put("/api/profiles", (req, res) => {
  try {
    const cur = loadProfiles();
    const body = req.body || {};
    const merged = {
      meta: { updated_at: nowIso(), updated_by: body.updated_by || cur.meta?.updated_by || null },
      active: typeof body.active === "string" ? body.active : cur.active,
      profiles: { ...(cur.profiles || {}), ...(body.profiles || {}) },
    };
    if (!merged.profiles[merged.active]) merged.active = Object.keys(merged.profiles)[0] || "lan";
    saveProfiles(merged);
    res.json({ ok: true, ...merged });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get("/api/profiles/active", (_req, res) => {
  try {
    const p = loadProfiles();
    res.json({ ok: true, active: p.active, profile: p.profiles?.[p.active] || null });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.put("/api/profiles/active", (req, res) => {
  try {
    const p = loadProfiles();
    const a = req.body?.active ? String(req.body.active) : "";
    if (!a || !p.profiles?.[a]) return res.status(400).json({ ok: false, error: "Unknown active profile" });
    p.active = a;
    p.meta = { ...(p.meta || {}), updated_at: nowIso() };
    saveProfiles(p);
    res.json({ ok: true, active: p.active, profile: p.profiles?.[p.active] || null });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- sysdiag probes ----------
function functionMap(req) {
  const eff = effectiveProfile(req);
  const base = eff.base_url || "";
  const baseHttp = withSchemeAndPort(base, "http", 8080) || "";
  const baseHttps = withSchemeAndPort(base, "https", 8443) || base;

  return {
    "svc.voice_gateway.running": { label: "Gateway /health (self)", probe: { type: "http", url: `http://127.0.0.1:${PORT}/health` } },
    "svc.tool_gateway.running": { label: "Tool gateway /health", probe: { type: "http", url: `${TOOL_URL.replace(/\/$/, "")}/health` } },
    "svc.agent_runner.running": { label: "Agent runner /health", probe: { type: "http", url: `${AGENT_URL.replace(/\/$/, "")}/health` } },

    "net.port.8443.listening": { label: "Port 8443 listening", probe: { type: "port", host: "127.0.0.1", port: 8443 } },
    "net.port.8080.listening": { label: "Port 8080 listening", probe: { type: "port", host: "127.0.0.1", port: 8080 } },
    "net.port.6333.listening": { label: "Port 6333 listening", probe: { type: "port", host: "127.0.0.1", port: 6333 } },

    "route.http.ping": baseHttp ? { label: "HTTP UI ping (/)", probe: { type: "http", url: `${baseHttp}/` } } : { label: "HTTP UI ping (/)" },
    "route.https.ping": baseHttps ? { label: "HTTPS UI ping (/)", probe: { type: "http", url: `${baseHttps}/` } } : { label: "HTTPS UI ping (/)" },
    "route.ui.index": baseHttps ? { label: "UI index loads", probe: { type: "http", url: `${baseHttps}/` } } : { label: "UI index loads" },
    "route.api_proxy": baseHttps ? { label: "API proxy /api/meta", probe: { type: "http", url: `${baseHttps}/api/meta` } } : { label: "API proxy /api/meta" },
  };
}

function httpProbe(url) {
  return new Promise((resolve) => {
    const lib = url.startsWith("https:") ? https : http;
    const start = Date.now();
    const req = lib.get(url, { timeout: 2000 }, (resp) => {
      resp.on("data", () => {});
      resp.on("end", () =>
        resolve({
          ok: (resp.statusCode || 0) < 400,
          status: resp.statusCode || 0,
          latency_ms: Date.now() - start,
        })
      );
    });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", () => resolve({ ok: false, status: 0, latency_ms: Date.now() - start }));
  });
}

function portProbe(host, port) {
  return new Promise((resolve) => {
    const start = Date.now();
    const sock = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      try {
        sock.destroy();
      } catch {}
      resolve({ ok, status: ok ? 1 : 0, latency_ms: Date.now() - start });
    };
    sock.setTimeout(1500);
    sock.once("connect", () => finish(true));
    sock.once("timeout", () => finish(false));
    sock.once("error", () => finish(false));
    sock.connect(port, host);
  });
}

app.get("/api/function-map", (req, res) => {
  const eff = effectiveProfile(req);
  res.status(200).json({
    ok: true,
    profile: { active: eff.active, base_url: eff.base_url, label: eff.profile?.label || eff.active },
    items: functionMap(req),
  });
});

app.post("/api/function-map/probe/:id", async (req, res) => {
  const id = String(req.params.id || "");
  const fm = functionMap(req);
  const entry = fm[id];
  if (!entry || !entry.probe) return res.status(404).json({ ok: false, error: "Unknown id" });

  const ts = nowIso();
  try {
    let result = { ok: false, status: 0, latency_ms: 0 };
    if (entry.probe.type === "http") result = await httpProbe(String(entry.probe.url || ""));
    else if (entry.probe.type === "port") result = await portProbe(String(entry.probe.host || "127.0.0.1"), Number(entry.probe.port || 0));
    else return res.status(400).json({ ok: false, error: "Unsupported probe type" });

    return res.status(200).json({ ok: true, id, pass: !!result.ok, status: result.status, latency_ms: result.latency_ms, timestamp: ts });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e), timestamp: ts });
  }
});

app.get("/api/sysdiag/last", (_req, res) => {
  const existing = readJsonFile(SYSDIAG_LAST_PATH);
  return res.status(200).json({ ok: true, result: existing || null });
});

async function runSysdiag(req, idsIn) {
  const ts = nowIso();
  const fm = functionMap(req);
  const allIds = Object.keys(fm);
  const ids = (Array.isArray(idsIn) && idsIn.length ? idsIn : allIds).filter((id) => fm[id] && fm[id].probe);

  const results = [];
  for (const id of ids) {
    const entry = fm[id];
    let r = { ok: false, status: 0, latency_ms: 0 };
    if (entry.probe.type === "http") r = await httpProbe(String(entry.probe.url || ""));
    else if (entry.probe.type === "port") r = await portProbe(String(entry.probe.host || "127.0.0.1"), Number(entry.probe.port || 0));
    results.push({ id, label: entry.label || id, pass: !!r.ok, status: r.status, latency_ms: r.latency_ms });
  }

  const summary = { total: results.length, pass: results.filter((x) => x.pass).length, fail: results.filter((x) => !x.pass).length };
  const out = { timestamp: ts, summary, results };
  atomicWriteJson(SYSDIAG_LAST_PATH, out);
  return out;
}

app.get("/api/sysdiag/run", async (req, res) => {
  try {
    const out = await runSysdiag(req, null);
    return res.status(200).json({ ok: true, ...out });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e), timestamp: nowIso() });
  }
});

app.post("/api/sysdiag/run", async (req, res) => {
  try {
    const idsIn = Array.isArray(req.body?.ids) ? req.body.ids.map((x) => String(x || "")) : null;
    const out = await runSysdiag(req, idsIn);
    return res.status(200).json({ ok: true, ...out });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e), timestamp: nowIso() });
  }
});

// ---------- /api/tests/quick ----------
async function probeJson(url) {
  const t0 = Date.now();
  try {
    const r = await fetch(url, { cache: "no-store" });
    const ms = Date.now() - t0;
    let body;
    try {
      body = await r.json();
    } catch {
      body = await r.text();
    }
    return { ok: r.ok, status: r.status, ms, url, body };
  } catch (e) {
    const ms = Date.now() - t0;
    return { ok: false, status: 0, ms, url, error: String(e) };
  }
}

app.get("/api/tests/quick", async (_req, res) => {
  const agent = await probeJson(`${AGENT_URL.replace(/\/$/, "")}/health`);
  const tools = await probeJson(`${TOOL_URL.replace(/\/$/, "")}/health`);
  return res.json({
    ok: true,
    ts: nowIso(),
    ui: "ok",
    agent: agent.ok ? "ok" : `fail:${agent.status}`,
    tools: tools.ok ? "ok" : `fail:${tools.status}`,
    voice: REALTIME_MODEL && VOICE ? "cfg" : "–",
    details: { agent, tools },
  });
});

// ---------- /api/chat ----------
// UI expects POST /api/chat with JSON {user:"..."} (or {message}/{text})
// This gateway forwards to agent-runner. The agent API endpoint has varied across builds,
// so we default to /llm/test and fall back if needed.
const AGENT_CHAT_PATH = (process.env.AGENT_CHAT_PATH || "/llm/test").startsWith("/")
  ? process.env.AGENT_CHAT_PATH || "/llm/test"
  : `/${process.env.AGENT_CHAT_PATH || "llm/test"}`;

function formatAgentReply(payload) {
  try {
    if (!payload || typeof payload !== "object") return String(payload ?? "");
    if (payload.needs_confirm) {
      return `CONFIRM REQUIRED\nAction: ${payload.action || ""}\nHint: ${payload.hint || "Send again with confirm to proceed."}`;
    }
    const r = payload.result ?? payload.reply ?? payload.text ?? payload.message ?? payload.output;
    if (typeof r === "string") return r;
    if (r && typeof r === "object") return JSON.stringify(r, null, 2);
    if (payload.error) return `ERROR: ${payload.error}`;
    return JSON.stringify(payload, null, 2);
  } catch {
    return String(payload ?? "");
  }
}

async function agentPost(pathname, payload) {
  const base = AGENT_URL.replace(/\/$/, "");
  const url = `${base}${pathname}`;
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload || {}),
  });
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("application/json") ? await r.json() : await r.text();
  return { status: r.status, ok: r.ok, body, url };
}

app.post("/api/chat", async (req, res) => {
  const ts = nowIso();
  try {
    const bodyIn = req.body || {};
    const user = String(bodyIn.user || bodyIn.message || bodyIn.text || bodyIn.prompt || "").trim();
    const confirm = bodyIn.confirm != null ? String(bodyIn.confirm) : undefined;

    if (!user) return res.status(400).json({ ok: false, error: "Missing user/message/text" });

    const payloadOut = {
      prompt: user,
      user,
      text: user,
      message: user,
      confirm,
      trace_id: req._request_id,
      ...bodyIn,
    };

    let r = await agentPost(AGENT_CHAT_PATH, payloadOut);

    if (r.status === 404) {
      const fallbacks = ["/llm/test", "/api/llm/test", "/ask"];
      for (const p of fallbacks) {
        if (p === AGENT_CHAT_PATH) continue;
        const r2 = await agentPost(p, payloadOut);
        if (r2.status !== 404) {
          r = r2;
          break;
        }
      }
    }

    const payload = typeof r.body === "object" ? r.body : { ok: r.ok, result: r.body };
    const reply = formatAgentReply(payload);

    return res.status(r.status).json({
      ok: !!(payload && payload.ok),
      reply,
      raw: payload,
      agent_url: r.url,
      timestamp: ts,
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ ok: false, error: String(e), timestamp: ts });
  }
});

// ---------- realtime voice session (WebRTC SDP exchange) ----------
app.post("/session", async (req, res) => {
  try {
    if (!OPENAI_API_KEY) return res.status(500).json({ ok: false, error: "OPENAI_API_KEY missing" });
    if (!req.body || typeof req.body !== "string") return res.status(400).json({ ok: false, error: "Missing SDP body" });

    const fd = new FormData();
    fd.set("sdp", req.body);
    fd.set("session", JSON.stringify({ type: "realtime", model: REALTIME_MODEL, audio: { output: { voice: VOICE } } }));

    const r = await fetch("https://api.openai.com/v1/realtime/calls", {
      method: "POST",
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}` },
      body: fd,
    });

    const text = await r.text();
    if (!r.ok) return res.status(r.status).type("text/plain").send(text);
    return res.type("application/sdp").send(text);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- agent proxy (non-api legacy) ----------
app.post("/agent", async (req, res) => {
  try {
    const r = await fetch(`${AGENT_URL.replace(/\/$/, "")}/ask`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body || {}),
    });
    const ct = r.headers.get("content-type") || "";
    const body = ct.includes("application/json") ? await r.json() : await r.text();
    return res.status(r.status).send(body);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- Threads (UI expects /api/threads/*) ----------
app.post("/api/threads/list", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/list", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/threads/create", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/create", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/threads/append", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/append", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/threads/read", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/read", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// Legacy (keep if you still have scripts calling these) — guarded + try/catch
app.post("/threads/list", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/list", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});
app.post("/threads/create", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/create", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});
app.post("/threads/append", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/append", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});
app.post("/threads/read", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/threads/read", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- Files (UI expects /api/files/*) ----------
app.get("/api/files/list", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    const project = String(req.query.project || "default");
    const relPath = sanitizeRelPath(String(req.query.path || ""));
    const out = await toolPost("/list_dir", { project, path: relPath, max_items: 500 });
    return res.json(out);
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/files/upload_b64", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/upload_b64", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- Projects (UI expects /api/projects/*) ----------
app.get("/api/projects/list", async (req, res) => {
  try {
    return await passthroughToolGet(req, res, "/projects/list");
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get("/api/projects/current", async (req, res) => {
  try {
    return await passthroughToolGet(req, res, "/projects/current");
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

/**
 * Phase 2: Project runtime info
 * GET /api/projects/runtime?project=sera-voice-control
 *
 * Uses WORKSPACES_DIR / SERA_WORKSPACES_DIR / SERA_ROOT/workspaces and fallbacks
 * so the gateway works both on host and inside container (/sera-ai/workspaces).
 */
app.get("/api/projects/runtime", (req, res) => {
  try {
    const project = String(req.query.project || "").trim();
    if (!project) return res.status(400).json({ ok: false, error: "Missing project" });

    if (!/^[a-z0-9][a-z0-9_.-]{0,63}$/i.test(project)) {
      return res.status(400).json({ ok: false, error: "Invalid project name" });
    }

    const base = resolveWorkspacesDir();
    if (!base) {
      return res.status(500).json({
        ok: false,
        error: "No valid workspaces directory configured",
        hint: "Set WORKSPACES_DIR or mount /sera-ai/workspaces",
      });
    }

    const runtimePath = path.join(base, project, "run", "runtime.json");

    if (!fs.existsSync(runtimePath)) {
      return res.status(404).json({
        ok: false,
        error: "runtime.json not found",
        path: runtimePath,
        workspaces_dir: base,
        hint: "Create the project or generate runtime.json in <workspaces>/<project>/run/runtime.json",
      });
    }

    const obj = readJsonFile(runtimePath);
    if (!obj) return res.status(500).json({ ok: false, error: "Failed to parse runtime.json", path: runtimePath });

    return res.status(200).json({ ok: true, project, runtime: obj, path: runtimePath, workspaces_dir: base });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// FIX: UI had 404 here previously
app.post("/api/projects/create", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    const name = String(req.body?.name || req.body?.project || req.body?.project_id || "").trim();
    if (!name) return res.status(400).json({ ok: false, error: "Missing name/project" });
    const out = await toolPost("/projects/create", { project: name });
    return res.json(out);
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/projects/set_current", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    const project = String(req.body?.project || req.body?.project_id || req.body?.name || "").trim();
    if (!project) return res.status(400).json({ ok: false, error: "Missing project" });
    const out = await toolPost("/projects/set_current", { project });
    return res.json(out);
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/projects/export_pack", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/projects/export_pack", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- Backups ----------
app.get("/api/backups/list", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    const project = String(req.query.project || "default");
    return await passthroughToolGet(req, res, "/backups/list", { project });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/backups/create", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/backups/create", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/backups/extract", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    return res.json(await toolPost("/backups/extract", req.body || {}));
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- Bundles / Deploy ----------
app.get("/api/bundles/list", async (req, res) => {
  try {
    return await passthroughToolGet(req, res, "/bundles/list");
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/bundles/deploy_latest", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    const project = String((req.body && (req.body.project || req.body.project_id)) || "sera-voice-control");
    const out = await toolPost("/deploy/bundle", { mode: "latest", project });
    return res.json(out);
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post("/api/bundles/cascade", async (req, res) => {
  try {
    if (!requireToolToken(res)) return;
    const body = req.body || {};
    const project = String(body.project || body.project_id || "sera-voice-control");
    const mode = String(body.mode || "latest");
    const bundle = body.bundle ? String(body.bundle) : undefined;

    const payload = { project, mode };
    if (bundle) payload.bundle = bundle;

    const out = await toolPost("/deploy/bundle", payload);
    return res.json(out);
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- Plugins ----------
app.get("/api/plugins/list", async (req, res) => {
  try {
    return await passthroughToolGet(req, res, "/plugins/list");
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- logs ----------
app.get("/api/logs/actions/tail", async (req, res) => {
  try {
    const lines = Math.min(parseInt(req.query.lines || "200", 10) || 200, 2000);
    let content = "";
    try {
      content = fs.readFileSync(ACTION_LOG_PATH, "utf8");
    } catch {
      content = "";
    }
    const arr = content.split(/\r?\n/).filter(Boolean);
    const tail = arr.slice(Math.max(0, arr.length - lines));
    return res.json({ ok: true, path: ACTION_LOG_PATH, count: tail.length, lines: tail });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- debug health files (read-only mount) ----------
function isSafeDiagName(name) {
  if (!name) return false;
  const n = String(name);
  if (n.includes("/") || n.includes("\\") || n.includes("..")) return false;
  return /^health_(fail|ok)_\d{4}-\d{2}-\d{2}_\d{6}\.txt$/.test(n);
}

app.get("/api/debug/health/list", (_req, res) => {
  try {
    const dir = DEBUG_DIR_MOUNT;
    if (!fs.existsSync(dir)) return res.json({ ok: true, files: [] });

    const files = fs
      .readdirSync(dir)
      .filter((f) => /^health_(fail|ok)_\d{4}-\d{2}-\d{2}_\d{6}\.txt$/.test(f))
      .map((f) => {
        try {
          const st = fs.statSync(path.join(dir, f));
          return { name: f, bytes: st.size, mtime: st.mtime.toISOString() };
        } catch {
          return { name: f, bytes: null, mtime: null };
        }
      })
      .sort((a, b) => String(b.mtime || "").localeCompare(String(a.mtime || "")));

    return res.json({ ok: true, files });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get("/api/debug/health/read", (req, res) => {
  try {
    const name = req.query.name;
    if (!isSafeDiagName(name)) return res.status(400).json({ ok: false, error: "Invalid name" });

    const fp = path.join(DEBUG_DIR_MOUNT, String(name));
    if (!fs.existsSync(fp)) return res.status(404).json({ ok: false, error: "Not found" });

    const raw = fs.readFileSync(fp, "utf8");
    const content = raw.length > 200000 ? raw.slice(0, 200000) + "\n\n[truncated]" : raw;
    return res.json({ ok: true, name: String(name), content });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- sysdiag proxy (/sysdiag/* -> tool-gateway) ----------
app.use("/sysdiag", async (req, res) => {
  try {
    if (req.method !== "GET") return res.status(405).json({ ok: false, error: "method not allowed" });

    const base = TOOL_URL.replace(/\/$/, "");
    const url = `${base}${req.originalUrl}`;

    const headers = {};
    if (TOOL_TOKEN) headers["X-Tool-Token"] = TOOL_TOKEN;

    const r = await fetch(url, { headers, cache: "no-store" });
    const ct = r.headers.get("content-type") || "application/json; charset=utf-8";
    res.setHeader("Content-Type", ct);

    const ab = await r.arrayBuffer();
    return res.status(r.status).send(Buffer.from(ab));
  } catch (e) {
    return res.status(502).json({ ok: false, error: "sysdiag proxy failed", detail: String(e) });
  }
});

// ---------- root redirect ----------
app.get("/", (req, res) => {
  const uiPort = String(process.env.UI_PORT || "8080");
  const proto = String(req.headers["x-forwarded-proto"] || "http").split(",")[0].trim();
  const hostOnly = hostWithoutPortFromHeaders(req);
  const target = `${proto}://${hostOnly}:${uiPort}/`;
  return res.redirect(302, target);
});

// ---------- system checklist (persistent) ----------
const STATUS_ENUM = new Set(["working", "broken", "unknown"]);

function checklistTemplate() {
  return {
    meta: { updated_at: null, updated_by: null },
    items: {
      "svc.voice_gateway.running": { status: "unknown", note: "", updated_at: null },
      "svc.tool_gateway.running": { status: "unknown", note: "", updated_at: null },
      "svc.agent_runner.running": { status: "unknown", note: "", updated_at: null },
      "net.port.8443.listening": { status: "unknown", note: "", updated_at: null },
      "net.port.8080.listening": { status: "unknown", note: "", updated_at: null },
      "net.port.6333.listening": { status: "unknown", note: "", updated_at: null },
      "route.http.ping": { status: "unknown", note: "", updated_at: null },
      "route.https.ping": { status: "unknown", note: "", updated_at: null },
      "route.ui.index": { status: "unknown", note: "", updated_at: null },
      "route.api_proxy": { status: "unknown", note: "", updated_at: null },
      "ui.router.navigation_ok": { status: "unknown", note: "", updated_at: null },
      "ui.agent.prompt_submit": { status: "unknown", note: "", updated_at: null },
      "ui.sysdiag.view": { status: "unknown", note: "", updated_at: null },
    },
  };
}

function mergeChecklist(templateObj, existing) {
  const out = templateObj;
  if (!existing || typeof existing !== "object") return out;

  if (existing.items && typeof existing.items === "object") {
    for (const [id, val] of Object.entries(existing.items)) {
      if (!out.items[id] || !val || typeof val !== "object") continue;
      if (STATUS_ENUM.has(val.status)) out.items[id].status = val.status;
      if (typeof val.note === "string") out.items[id].note = val.note.slice(0, 2000);
      if (typeof val.updated_at === "string") out.items[id].updated_at = val.updated_at;
    }
  }

  out.meta = {
    updated_at: existing.meta?.updated_at || null,
    updated_by: existing.meta?.updated_by || null,
  };
  return out;
}

app.get("/api/system/checklist/template", (_req, res) => {
  return res.status(200).json(checklistTemplate());
});

app.get("/api/system/checklist", (_req, res) => {
  const tpl = checklistTemplate();
  const existing = readJsonFile(SYSTEM_CHECKLIST_PATH);
  return res.status(200).json(mergeChecklist(tpl, existing));
});

app.put("/api/system/checklist/item/:id", (req, res) => {
  try {
    const id = String(req.params.id || "");
    const status = String(req.body?.status || "").toLowerCase();
    const note = typeof req.body?.note === "string" ? req.body.note.slice(0, 2000) : "";

    if (!id || !/^[a-z0-9_.-]+$/i.test(id)) return res.status(400).json({ ok: false, error: "Invalid id" });
    if (!STATUS_ENUM.has(status)) return res.status(400).json({ ok: false, error: "Invalid status" });

    const tpl = checklistTemplate();
    const existing = readJsonFile(SYSTEM_CHECKLIST_PATH);
    const merged = mergeChecklist(tpl, existing);

    if (!merged.items[id]) return res.status(404).json({ ok: false, error: "Unknown id" });

    const ts = nowIso();
    merged.items[id] = { status, note, updated_at: ts };
    merged.meta.updated_at = ts;
    merged.meta.updated_by = req.body?.updated_by ? String(req.body.updated_by).slice(0, 64) : null;

    atomicWriteJson(SYSTEM_CHECKLIST_PATH, merged);
    return res.status(200).json({ ok: true, item: merged.items[id], meta: merged.meta });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// ---------- JSON-only 404 for /api (MUST BE LAST) ----------
app.use("/api", (_req, res) => {
  return res.status(404).json({ ok: false, error: "Not found", hint: "Gateway route missing for this /api endpoint." });
});

// ---------- start ----------
app.listen(PORT, () => {
  const agentBase = (AGENT_URL || "http://127.0.0.1:3200").replace(/\/$/, "");
  const toolBase = (TOOL_URL || "http://127.0.0.1:3100").replace(/\/$/, "");
  console.log(`Gateway listening on :${PORT} (model=${REALTIME_MODEL}, voice=${VOICE}, safe_mode=${SAFE_MODE_BOOL})`);
  console.log(`Resolved AGENT_URL=${agentBase}`);
  console.log(`Resolved TOOL_URL=${toolBase}`);
});