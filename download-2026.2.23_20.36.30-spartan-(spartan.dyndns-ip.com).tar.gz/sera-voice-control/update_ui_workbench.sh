#!/usr/bin/env bash
set -euo pipefail

UI_DIR="ui"

echo "Creating $UI_DIR/p2_workbench.css..."
cat > "$UI_DIR/p2_workbench.css" <<'CSS'
/* =========================================================
   SERA Phase2 Workbench (Unified E Layout)
   Resizable + Dockable + Floating AI Console
   ========================================================= */

/* ---- Root Layout Vars ---- */
:root{
  --p2-left: 320px;
  --p2-right: 340px;
  --p2-chat-h: 220px;

  --p2-gap: 12px;
  --p2-border: rgba(255,255,255,.10);
  --p2-border-strong: rgba(255,255,255,.18);
  --p2-bg-soft: rgba(255,255,255,.03);
}

/* =========================================================
   Workbench Layout
   ========================================================= */

.seraP2Wrap{
  display:flex;
  flex-direction:column;
  gap:var(--p2-gap);
  min-height:calc(100vh - 160px);
}

.seraP2Workbench{
  display:grid;
  grid-template-columns:
    var(--p2-left)
    8px
    1fr
    8px
    var(--p2-right);
  gap:0;
  min-height:560px;
}

.seraP2LeftStack,
.seraP2Center,
.seraP2RightStack{
  display:flex;
  flex-direction:column;
  gap:var(--p2-gap);
  min-width:0;
}

/* Bottom Chat Dock */
.seraP2ChatDock{
  height:var(--p2-chat-h);
  min-height:120px;
  border:1px solid var(--p2-border);
  border-radius:var(--radius,18px);
  background:var(--p2-bg-soft);
  overflow:hidden;
  display:flex;
  flex-direction:column;
}

/* =========================================================
   Splitters
   ========================================================= */

.seraP2VSplit,
.seraP2HSplit{
  position:relative;
  user-select:none;
  z-index:5;
}

.seraP2VSplit{
  cursor:col-resize;
}
.seraP2HSplit{
  height:8px;
  cursor:row-resize;
}

.seraP2VSplit::after{
  content:"";
  position:absolute;
  top:20%;
  bottom:20%;
  left:50%;
  width:2px;
  transform:translateX(-50%);
  background:rgba(147,197,253,.35);
  border-radius:999px;
}

.seraP2HSplit::after{
  content:"";
  position:absolute;
  left:20%;
  right:20%;
  top:50%;
  height:2px;
  transform:translateY(-50%);
  background:rgba(147,197,253,.35);
  border-radius:999px;
}

/* =========================================================
   Panels / Cards (Unified)
   ========================================================= */

.seraP2Card,
.seraP2Panel,
.p2panel,
.pbPanel{
  border:1px solid var(--p2-border);
  border-radius:var(--radius,18px);
  background:var(--p2-bg-soft);
  overflow:hidden;
  display:flex;
  flex-direction:column;
  min-height:0;
  transition:border-color .15s ease;
}

.seraP2Card:hover,
.seraP2Panel:hover{
  border-color:var(--p2-border-strong);
}

.seraP2Panel__title,
.pbPanel__title{
  padding:10px;
  font-size:12px;
  text-transform:uppercase;
  letter-spacing:.06em;
  opacity:.75;
  border-bottom:1px solid var(--p2-border);
}

.seraP2Panel__body,
.pbPanel__body{
  padding:10px;
  overflow:auto;
  flex:1;
  min-height:0;
}

/* =========================================================
   Floating AI Console
   ========================================================= */

.seraP2Float{
  position:fixed;
  top:12vh;
  right:40px;
  width:min(520px,92vw);
  height:min(520px,78vh);
  border:1px solid var(--p2-border);
  border-radius:var(--radius,18px);
  background:rgba(18,26,42,.98);
  box-shadow:0 18px 60px rgba(0,0,0,.55);
  display:flex;
  flex-direction:column;
  z-index:1000;
}

.seraP2FloatBar{
  padding:10px;
  border-bottom:1px solid var(--p2-border);
  display:flex;
  justify-content:space-between;
  align-items:center;
  cursor:move;
  user-select:none;
}

.seraP2FloatBody{
  padding:10px;
  overflow:auto;
  flex:1;
}

/* =========================================================
   Basic P2 Controls
   ========================================================= */

.seraP2Btn{
  border:1px solid var(--p2-border);
  border-radius:999px;
  padding:6px 12px;
  background:rgba(255,255,255,.04);
  font-size:12px;
  cursor:pointer;
}

.seraP2Btn.primary{
  border-color:var(--primary,#2a59ff);
  box-shadow:inset 0 0 0 2px rgba(42,89,255,.18);
}

.seraP2Input,
.seraP2Textarea{
  border:1px solid var(--p2-border);
  border-radius:12px;
  padding:6px 10px;
  background:rgba(0,0,0,.18);
  color:inherit;
  font-size:12px;
  outline:none;
}

.seraP2Textarea{
  resize:vertical;
  min-height:120px;
}

.seraP2Mono{
  font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  font-size:12px;
}

.seraP2Row{
  display:flex;
  gap:8px;
  align-items:center;
}

.seraP2ListItem{
  padding:6px 8px;
  border-radius:8px;
  cursor:pointer;
}
.seraP2ListItem:hover{
  background:rgba(255,255,255,.06);
}
CSS

echo "Creating $UI_DIR/modals.css..."
cat > "$UI_DIR/modals.css" <<'CSS'
/* =========================================================
   SERA Modal System (Blocking Dialogs)
   ========================================================= */

:root{
  --modal-overlay:rgba(0,0,0,.6);
  --modal-border:rgba(255,255,255,.12);
  --modal-bg:rgba(18,26,42,.98);
  --modal-anim:160ms;
}

.modalOverlay{
  position:fixed;
  inset:0;
  display:flex;
  align-items:center;
  justify-content:center;
  background:var(--modal-overlay);
  padding:20px;
  opacity:0;
  visibility:hidden;
  pointer-events:none;
  transition:opacity var(--modal-anim) ease, visibility var(--modal-anim) ease;
  z-index:1200;
}

.modalOverlay.is-open{
  opacity:1;
  visibility:visible;
  pointer-events:auto;
}

.modalWin{
  width:min(680px,95vw);
  max-height:90vh;
  background:var(--modal-bg);
  border:1px solid var(--modal-border);
  border-radius:var(--radius,18px);
  box-shadow:0 18px 60px rgba(0,0,0,.55);
  display:flex;
  flex-direction:column;
  transform:translateY(12px);
  transition:transform var(--modal-anim) ease;
}

.modalOverlay.is-open .modalWin{
  transform:translateY(0);
}

.modalHdr{
  padding:12px;
  border-bottom:1px solid var(--modal-border);
  display:flex;
  justify-content:space-between;
  align-items:center;
}

.modalBody{
  padding:12px;
  overflow:auto;
  flex:1;
}

.modalFtr{
  padding:12px;
  border-top:1px solid var(--modal-border);
  display:flex;
  justify-content:flex-end;
  gap:8px;
}
CSS

echo "Creating $UI_DIR/CSS_BASE_GUIDE.md..."
cat > "$UI_DIR/CSS_BASE_GUIDE.md" <<'MD'
# SERA UI Schema – Final Unified Workbench

## Core Concepts

### Workbench
Resizable layout using CSS variables:
- --p2-left
- --p2-right
- --p2-chat-h

Controlled by workspace.js.

### Splitters
- .seraP2VSplit
- .seraP2HSplit

### Panels
Canonical panel visual:
- .seraP2Card
- .seraP2Panel
- .p2panel (legacy alias)
- .pbPanel (legacy alias)

### Floating Tool Window
- .seraP2Float
- .seraP2FloatBar
- .seraP2FloatBody

Used for AI console undock.

### Modals (Blocking)
- .modalOverlay
- .modalWin
- .modalHdr
- .modalBody
- .modalFtr

Use for confirmations, settings dialogs.

## Migration Notes

- Retire .p2grid.
- Mount Phase2 workspace inside #page-project-workspace.
- Keep legacy panel classes for backward compatibility.
- Future installer can merge p2_workbench.css into a unified design system.
MD

echo "Done."