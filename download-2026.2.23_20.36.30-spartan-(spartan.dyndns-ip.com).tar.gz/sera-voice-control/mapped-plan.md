============================================================
TO PROCESSOR: BUILD PREP CHECKLIST (IMPORTANT)
============================================================

1) CAPABILITIES + PLATFORM HOOKS
- Implement GET /api/system/capabilities returning booleans:
  canOpenFileManager, canOpenExternalEditor, supportsTTS, supportsSTT,
  supportsWebsocketLogs, canDeploy, canRestartService
- UI must hide/disable features based on this.

2) PATH SANDBOX + ATOMIC WRITES (NON-NEGOTIABLE)
- Enforce safeJoin(projectRoot, relPath) on ALL file endpoints:
  reject absolute paths, "..", null bytes; resolve then confirm startsWith projectRoot
- Atomic write: temp -> fsync -> rename -> fsync dir
- Denylist: .git/**, node_modules/**, .sera/** (except snapshots/logs as needed)

3) CHANGESET PIPELINE (PATCH REVIEW REQUIRED)
- Add ProposedChangeSet storage endpoints:
  POST /api/changes  (create)
  GET /api/changes/:id
  POST /api/changes/:id/apply
  POST /api/changes/:id/discard
  POST /api/changes/:id/rollback  (recommended)
- Autosnapshot before apply:
  .sera/snapshots/<timestamp>_<changeSetId>/
  store metadata.json with provenance (threadId/messageId/model)

4) CONCURRENCY / LOCKING
- Apply operations must acquire per-project lock (reject with E_LOCKED)
- Run/build operations must reject overlapping runs (E_BUSY) or provide stop endpoint

5) RUN/BUILD/DEPLOY SAFETY
- Commands must come from allowlist (project settings templates) OR server config
- Never execute raw user input as shell
- Provide run/build status and log streaming (SSE or WS)
- Deploy history list + status + rollback hooks

6) CONSISTENT ERROR ENVELOPE
- Standard JSON response:
  ok:true,data
  ok:false,error:{code,message,details}
- Use stable error codes: E_PATH, E_LOCKED, E_BUSY, E_EXT, E_IO, E_AUTH, E_CMD

7) PROJECT SETTINGS (SERVER CONTRACT)
- Project settings fields:
  model, previewUrl, buildCommand, runCommand, includeRules, excludeRules
- Endpoints:
  GET/POST/PATCH /api/projects
  PATCH /api/projects/:id to update settings
- Import/clone support can be later; ensure schema is future-proof.

8) AUDIT LOG (MINIMAL)
- Append-only .sera/audit.jsonl events:
  project.create/delete/update
  file.write/delete/rename
  changeset.create/apply/discard/rollback
  run/build start/stop
  deploy start/success/fail

9) THREAD STORAGE + EXPORT
- Thread list per project:
  GET /api/projects/:id/threads
- Messages:
  GET /api/threads/:id/messages
  POST /api/threads/:id/messages includes context + attachments metadata
- Export:
  GET /api/threads/:id/export?format=md|json

10) UI MOUNT CONTRACT FOR WORKBENCH
- Provide a stable mount div for Phase2 workbench (e.g. #p2Root)
- workspace renderer must accept mount element OR provide getRootEl() that returns it

============================================================
OPTIONAL BUT HIGH ROI (IF TIME)
============================================================

A) SEARCH API
- Server-side ripgrep-like search:
  GET /api/projects/:id/search?q=&include=&exclude=
- Needed for “search in files” later without loading entire project.

B) FILE WATCH / REFRESH
- Provide "project changed" signal or polling for external edits.

C) DIAGNOSTICS ENDPOINT
- GET /api/system/diagnostics should run:
  mic capability flags (if relevant), endpoint reachability, disk write test,
  workspace project root validity, streaming support check

============================================================
END
============================================================
============================================================
SERA IDE PRODUCT PLAN + PAGE MAP 
(Expanded + Missing Items Included)
============================================================


============================================================
WHAT YOU ALREADY HAVE TODAY (FACTS)
============================================================

NAV:
- Voice
- Chat
- Dashboard
- Programmer
- System
- System sub-pages: Deploy, Admin, Settings, Diagnostics

VOICE PAGE:
- PTT (press/hold)
- Status diagnostics (secure context, mic permission, etc.)
- Prompt input
- Output log
- Auto-send recognized speech to /api/chat
- TTS playback of reply

DASHBOARD:
- Preview viewer (iframe)
- URL input + Load/Open controls

PROGRAMMER (V1):
- .p2grid layout
- File tree
- Editor
- Threads list
- Chat box

PHASE2 WORKBENCH (REAL IDE):
- Resizable left/right panes
- Bottom chat dock resizable
- Persistence via --p2-left / --p2-right / --p2-chat-h
- Splitters for left/center, center/right, chat height
- AI console dock/undock into draggable floating window

CONCLUSION:
- Industry standard IDE layout already exists in Phase2.
- Programmer page should become the mount for Phase2 workbench.


============================================================
INDUSTRY-STANDARD IDE CAPABILITY BUCKETS
============================================================

PROJECT MANAGEMENT:
- create/open/clone/import
- project settings
- switch active project
- delete/archive
- templates/scaffolds
- recent projects

WORKSPACE:
- file explorer
- editor
- tabs
- search in files
- replace in files
- diff viewer
- terminal/logs
- build/run/debug controls
- preview
- problems panel

AI WORKFLOW:
- chat per project/thread
- context sources (files, selection, logs, project summary)
- tool execution results (“console”)
- voice input option
- prompt presets / macros
- apply patch pipeline (review -> apply/discard)

COLLAB / HISTORY:
- threads/sessions
- change history / snapshots
- export/share threads
- audit log (who/what applied changes)

OPERATIONS / SYSTEM:
- service status
- logs
- deployments
- settings & endpoints
- diagnostics
- capabilities flags


============================================================
PAGE-BY-PAGE FUNCTION MAP (RECOMMENDED)
============================================================

------------------------------------------------------------
1) VOICE PAGE
------------------------------------------------------------

PURPOSE:
- Hands-free input + command execution + quick feedback

KEEP (EXISTING):
- PTT (hold-to-talk)
- Status (mic / secure context / STT availability)
- Prompt input
- Output log
- TTS toggle (if present)

ADD:
- Target routing selector:
  - Chat thread
  - Active project (default thread)
  - Programmer selection (insert into editor / replace selection)
  - Command palette (execute command by voice)
- Voice “Actions / Presets” (collapsible):
  - run tests
  - run build
  - run dev
  - deploy latest
  - open file <name>
  - switch project <name>
- “Wake word” optional (V2)
- “Dictation mode” (write into active editor) optional


------------------------------------------------------------
2) CHAT PAGE
------------------------------------------------------------

PURPOSE:
- AI session manager + project/thread navigation

KEEP (EXISTING):
- Left pane sections (Connected / Recent / Project chats)
- Right chat view + send box

ADD / STANDARDIZE:
- Thread list + search / filter:
  - by project
  - by title
  - by updated
- Upload file support:
  - Attach to thread context (AI sees it)
  - Save to project storage (writes file under project)
- Voice input in chat:
  - mic button next to send
  - optional PTT mode in chat
- Context controls (toggles):
  - include selection
  - include open file
  - include run logs
  - include project summary
  - include file tree (optional)
- Export thread:
  - markdown
  - json
- “Send to Programmer” actions:
  - Open file
  - Create file
  - Propose patch (ChangeSet)
  - Run command
  - Show diff modal


------------------------------------------------------------
3) DASHBOARD PAGE
------------------------------------------------------------

PURPOSE:
- Project hub + preview viewer + recent activity

KEEP (EXISTING):
- Preview iframe viewer + URL input + Load/Open

ADD:
- Project list:
  - create
  - delete/archive (danger zone)
  - rename
  - duplicate/clone
  - import from path
  - import from git (V1)
- Project summary panel:
  - last modified
  - build status (idle/running/error)
  - active model
  - preview URL
  - last deployment status
- Quick actions per project:
  - Open in Programmer (Simple)
  - Open in Workbench (Phase2)
  - Open in File Manager (host action)
  - Open in External Editor (host action)
  - Open Preview
  - Open Chat (project thread)
  - Project Settings
- Recent activity feed (append-only):
  - deploy succeeded/failed
  - build failed
  - AI patch applied
  - snapshot created/restored


------------------------------------------------------------
4) PROGRAMMER PAGE
------------------------------------------------------------

PURPOSE:
- Primary IDE workspace

MUST SUPPORT 2 MODES:

MODE A: SIMPLE EDITOR (KEEP ORIGINAL)
- file tree + editor
- save/reload
- thread list + chat box
- “Open in Workbench” button

MODE B: WORKBENCH IDE (PHASE2 MOUNT)
- Left: files + project viewer
- Center: editor + tabs + find-in-file
- Right: AI console + run log
- Bottom dock: chat/terminal/output (resizable)
- AI console dock/undock + floating window

ADD BUTTONS / OPTIONS (YOU REQUESTED):
- Open in File Manager
- Open in External Editor
- Open in Workbench (toggle mode)
- Open in Simple (toggle mode)

STANDARD IDE ACTIONS TO ADD:
- Search in files
- Replace in files
- Diff viewer (Patch review)
- Run / Build / Test controls (top bar)
- Problems panel (lint/test failures)
- Terminal (V1)
- Git status/diff (V1)

CORE RULE:
- All edits from AI must go through Patch Review (Diff modal) -> Apply/Discard


------------------------------------------------------------
5) SYSTEM PAGE
------------------------------------------------------------

PURPOSE:
- Operations console (whole IDE)

TOP-LEVEL:
- Health (service status)
- Logs
- Docs viewer
- Quick-nav to Deploy/Admin/Settings/Diagnostics

SUB-PAGES:

DEPLOY:
- Already good; improve formatting
ADD:
- deployment history list
- last deploy status badge
- link to logs for deploy
- rollback UI (select deployment)

ADMIN:
- service status + action log viewer (auto refresh)
ADD (GUARDED):
- restart service controls
- clear cache
- rotate logs
- user/session audit log view (V1)

SETTINGS:
- Paths & URLs
- endpoints
- raw JSON editing
ADD:
- AI provider/model defaults
- per-project overrides link
- permissions/auth settings (future)
- capabilities display (server feature flags)

DIAGNOSTICS:
ADD:
- mic permissions / STT capability checks
- network test (agent/tool gateway endpoints)
- workspace mount verification
- disk write test (optional)
- websocket/SSE test (if streaming logs)


============================================================
PAGES / SUBPAGES TO ADD (HIGH VALUE)
============================================================

1) PROJECT SETTINGS (page or modal)
- project metadata
- build/run commands
- preview URL
- AI context rules (include/exclude)
- model defaults per project
- danger zone: delete/archive

2) COMMAND PALETTE (overlay)
- open file…
- run task…
- switch project…
- toggle AI window…
- deploy latest…
- open settings/logs
- becomes best voice target action

3) PATCH REVIEW / DIFF (modal or page)
- show diff (unified MVP, side-by-side V1)
- apply / discard
- track applied changes
- optional: apply selected files only (V1)

4) SNAPSHOTS / BACKUPS (promote existing)
- create snapshot
- restore snapshot
- list snapshots per project
- compare snapshot
- “undo last apply” via snapshot

5) KEYBINDINGS (later)
- show shortcuts
- customize bindings (V2)


============================================================
RECOMMENDED “WHERE DOES WHAT LIVE” CHEAT SHEET
============================================================

VOICE:
- capture speech
- route to: chat / programmer / palette
- show status + log

CHAT:
- threads/sessions manager
- attachments + context toggles
- generates ChangeSets (does not write directly)
- exports threads

DASHBOARD:
- project lifecycle + preview viewer
- quick actions + activity feed

PROGRAMMER:
- edits + run/build/test
- AI console + logs
- patch review applies changes

SYSTEM:
- ops tooling (health/logs/docs)
- deploy/admin/settings/diagnostics


============================================================
MISSING ITEMS YOU SHOULD INCLUDE (IMPORTANT)
============================================================

SECURITY / SAFETY:
- path sandboxing for all file ops
- atomic writes + autosnapshot before apply
- apply locks to prevent concurrency conflicts
- command allowlist for run/build

UX / IDE CORE:
- unsaved changes tracking (dirty state)
- confirm before navigation/close
- open files list + editor tabs
- global search + replace
- problems panel
- notifications/toasts
- streaming build/run logs

AI GOVERNANCE:
- ChangeSet provenance:
  - source threadId/messageId
  - model used
  - timestamp
- selective apply (file-by-file V1)
- rollback / undo last apply (via snapshot)
- audit log (apply/discard/rollback)

OPS:
- capabilities endpoint to hide unsupported buttons:
  - canOpenFileManager, supportsTTS, supportsSTT, canDeploy, etc.

QUALITY:
- consistent error envelope for API responses
- minimal telemetry/activity feed stored locally


============================================================
MVP / V1 / V2 BACKLOG (EXECUTION CHECKLIST)
============================================================

MVP (SHIP):
- Programmer mode toggle: Simple <-> Workbench
- Patch review modal (apply/discard)
- Chat context toggles + Send to Programmer actions
- Dashboard project list CRUD + quick actions
- Voice target routing + macros panel (basic)
- System: deploy formatting + diagnostics tests + capabilities view
- Snapshots: create + restore + list (minimal)

V1 (PRO):
- Tabs + recent files
- Search in files + replace
- Problems panel
- Terminal
- Git status/diff (basic)
- Deployment history + rollback UI
- Thread export + presets library

V2 (DIFFERENTIATION):
- Debugger integration
- AI refactor/test generator/debug assistant
- Multi-agent workflows + tool timeline
- Custom keybindings + macro editor
- Collaboration/share threads/read-only mode


============================================================
END OF COPY BLOCK
============================================================
========================
SERA IDE – COMPLETE MAPPING & SPEC
========================


============================================================
GLOBAL UI STATE (ui_state.js)
============================================================

export const uiState = {
  activeProjectId: null,
  activeThreadId: null,
  activeFilePath: null,
  programmerMode: "workbench", // "simple" | "workbench"
  layout: {
    left: 320,
    right: 340,
    chatHeight: 220
  }
};


============================================================
EVENT BUS (ui_events.js)
============================================================

export const uiEvents = new EventTarget();

export function emit(name, detail = {}) {
  uiEvents.dispatchEvent(new CustomEvent(name, { detail }));
}

export function on(name, handler) {
  uiEvents.addEventListener(name, handler);
}


============================================================
PROJECT DATA MODEL
============================================================

{
  "id": "proj_123",
  "name": "My App",
  "rootPath": "/path/to/project",
  "createdAt": 0,
  "updatedAt": 0,
  "settings": {
    "model": "gpt-4o",
    "previewUrl": "http://localhost:3000",
    "buildCommand": "npm run build",
    "runCommand": "npm run dev",
    "includeRules": ["src/**"],
    "excludeRules": ["node_modules/**"]
  }
}


============================================================
THREAD MODEL
============================================================

{
  "id": "thr_123",
  "projectId": "proj_123",
  "title": "Fix login bug",
  "createdAt": 0,
  "updatedAt": 0
}


============================================================
MESSAGE MODEL
============================================================

{
  "id": "msg_123",
  "threadId": "thr_123",
  "role": "user",
  "content": "Refactor auth flow",
  "attachments": [],
  "proposedChangeSetId": "chg_123"
}


============================================================
PROPOSED CHANGE SET MODEL
============================================================

{
  "id": "chg_123",
  "projectId": "proj_123",
  "summary": "Add settings page",
  "files": [
    {
      "path": "ui/settings.js",
      "type": "modify",
      "content": "..."
    }
  ],
  "diff": "optional unified diff"
}


============================================================
REST API CONTRACT
============================================================

GET    /api/projects
POST   /api/projects
DELETE /api/projects/:id
PATCH  /api/projects/:id
POST   /api/projects/:id/open

GET    /api/projects/:id/files?path=
GET    /api/projects/:id/file?path=
PUT    /api/projects/:id/file?path=
DELETE /api/projects/:id/file?path=
POST   /api/projects/:id/rename

GET    /api/projects/:id/threads
POST   /api/projects/:id/threads
GET    /api/threads/:id/messages
POST   /api/threads/:id/messages

POST   /api/changes
GET    /api/changes/:id
POST   /api/changes/:id/apply
POST   /api/changes/:id/discard

POST   /api/projects/:id/run
POST   /api/projects/:id/build
GET    /api/projects/:id/runlog

POST   /api/deploy/latest
GET    /api/deploy/history
POST   /api/deploy/:id/rollback

GET    /api/system/status
GET    /api/system/logs
POST   /api/system/restart
POST   /api/system/clear-cache
GET    /api/system/diagnostics


============================================================
PATCH REVIEW MODAL (HTML)
============================================================

<div class="modalOverlay" id="patchModal">
  <div class="modalWin">
    <div class="modalHdr">
      <div>Review Changes</div>
      <button onclick="closePatchModal()">✕</button>
    </div>
    <div class="modalBody">
      <pre id="patchDiffView" class="seraP2Mono"></pre>
    </div>
    <div class="modalFtr">
      <button class="ghost" onclick="discardPatch()">Discard</button>
      <button class="primary" onclick="applyPatch()">Apply</button>
    </div>
  </div>
</div>


============================================================
PATCH REVIEW LOGIC (JS)
============================================================

let activeChangeSet = null;

function openPatchModal(changeSet) {
  activeChangeSet = changeSet;
  document.getElementById("patchDiffView").textContent =
    changeSet.diff || JSON.stringify(changeSet.files, null, 2);
  document.getElementById("patchModal").classList.add("is-open");
}

function closePatchModal() {
  document.getElementById("patchModal").classList.remove("is-open");
  activeChangeSet = null;
}

async function applyPatch() {
  await fetch(`/api/changes/${activeChangeSet.id}/apply`, { method: "POST" });
  closePatchModal();
}

async function discardPatch() {
  await fetch(`/api/changes/${activeChangeSet.id}/discard`, { method: "POST" });
  closePatchModal();
}


============================================================
COMMAND PALETTE (HTML)
============================================================

<div class="modalOverlay" id="paletteModal">
  <div class="modalWin modal--sm">
    <div class="modalBody">
      <input id="paletteInput" placeholder="Type a command..." />
      <div id="paletteResults"></div>
    </div>
  </div>
</div>


============================================================
COMMAND PALETTE LOGIC (JS)
============================================================

const commands = [
  { id: "open-file", label: "Open File" },
  { id: "switch-project", label: "Switch Project" },
  { id: "run-build", label: "Run Build" },
  { id: "deploy-latest", label: "Deploy Latest" }
];

function openPalette() {
  document.getElementById("paletteModal").classList.add("is-open");
}

function closePalette() {
  document.getElementById("paletteModal").classList.remove("is-open");
}


============================================================
DOCK PANEL IDS
============================================================

ai
runlog
chat
problems
terminal
outline


============================================================
VOICE TARGET ROUTING
============================================================

<select id="voiceTarget">
  <option value="chat">Chat</option>
  <option value="programmer">Programmer</option>
  <option value="palette">Command Palette</option>
</select>


============================================================
VOICE MACRO STRUCTURE
============================================================

[
  { "phrase": "run build", "action": "run-build" },
  { "phrase": "deploy latest", "action": "deploy-latest" },
  { "phrase": "open file", "action": "open-file" }
]


============================================================
WORKBENCH DOCK MAPPING
============================================================

RIGHT DOCK:
- AI Console
- Run Log
- Outline (future)

BOTTOM DOCK:
- Chat
- Terminal (future)
- Problems (future)


============================================================
PROGRAMMER MODES
============================================================

simple:
  - file tree
  - editor
  - inline chat

workbench:
  - resizable left/right
  - bottom chat dock
  - AI console dock/float
  - run log
  - tabs


============================================================
AI EDIT PIPELINE
============================================================

Chat/Voice -> ProposedChangeSet
-> openPatchModal()
-> Apply or Discard
-> File system write
-> Refresh editor + tree


============================================================
END OF COMPLETE SPEC
============================================================
============================================================
SERVER-SIDE SAFETY MIDDLEWARE + APPLY RULES (MINIMAL SPEC)
============================================================


============================================================
1) ERROR ENVELOPE (ALL ENDPOINTS)
============================================================

Success:
{ "ok": true, "data": ... }

Error:
{
  "ok": false,
  "error": {
    "code": "E_CODE",
    "message": "Human readable message",
    "details": { }
  }
}


============================================================
2) PATH SANDBOXING (PREVENT TRAVERSAL)
============================================================

Rules:
- Every file op must be relative to the active project root.
- Reject absolute paths (startsWith "/" or matches "^[A-Za-z]:\\").
- Reject any segment containing "..".
- Normalize separators.
- Resolve final path and ensure it begins with projectRoot.

Pseudo:
function safeJoin(projectRoot, relPath):
  if relPath is empty => throw E_PATH
  if relPath is absolute => throw E_PATH
  if relPath contains "\0" => throw E_PATH
  relPath = relPath.replaceAll("\\", "/")
  if relPath.split("/").includes("..") => throw E_PATH
  abs = resolve(projectRoot, relPath)
  if !abs.startsWith(resolve(projectRoot) + pathSep) => throw E_PATH
  return abs


============================================================
3) ALLOWLIST / DENYLIST (OPTIONAL BUT RECOMMENDED)
============================================================

Deny by default:
- node_modules/**
- .git/**
- secrets/** (if you have)
- *.pem, *.key, *.env (optionally)

Allowlist extensions (optional):
- .js .ts .json .md .html .css .scss .txt .yml .yaml
If not allowlisted -> E_EXT


============================================================
4) ATOMIC WRITES + AUTOSNAPSHOT
============================================================

Atomic write for each file:
- write to temp: <file>.tmp.<pid>.<ts>
- fsync temp
- rename temp -> real path
- fsync parent dir (if supported)

Autosnapshot before apply:
- create snapshot folder: .sera/snapshots/<timestamp>_<changeSetId>/
- copy only files that will be modified/created/deleted (not whole project)
- store metadata.json: { changeSetId, files[], createdAt, sourceThreadId, sourceMsgId }


============================================================
5) FILE LOCKING / CONCURRENCY
============================================================

Lock granularity:
- per project OR per file

Minimal approach:
- per project lock for apply operations
- while locked:
  - reject other apply requests (E_LOCKED)
  - allow read ops

Pseudo:
if projectLocks[projectId] is locked:
  return E_LOCKED
lock
try apply
finally unlock


============================================================
6) CHANGESET VALIDATION (BEFORE APPLY)
============================================================

Incoming ChangeSet must pass:
- has id, projectId
- files is array with at least 1 item
- each file entry has: path, type in ["create","modify","delete","rename"]
- content required for create/modify
- all paths pass safeJoin rules
- denylist rules enforced
- max file count (e.g. 200) and max total bytes (e.g. 10MB) to prevent abuse
- optional: detect binary content and reject unless explicitly allowed


============================================================
7) APPLY RULES (ORDER + GUARANTEES)
============================================================

Order:
1) validate
2) autosnapshot (only affected files)
3) apply creates/modifies
4) apply renames (careful with conflicts)
5) apply deletes (last)
6) write apply log entry

Guarantees:
- if any write fails, stop and return error
- snapshot exists so rollback is possible
- never leave partial temp files (cleanup)


============================================================
8) ROLLBACK / UNDO LAST APPLY
============================================================

Maintain:
- .sera/apply_log.jsonl
Each line:
{ ts, changeSetId, snapshotId, files, sourceThreadId, sourceMsgId }

Rollback endpoint:
POST /api/changes/:id/rollback
- find matching snapshotId
- restore saved copies over working files
- handle deletes/restores
- log rollback action


============================================================
9) RUN/BUILD PROCESS CONTROL (SAFETY)
============================================================

For /run, /build:
- only allow commands from project settings allowlist OR configured templates
- store process handle by projectId
- prevent overlapping runs (E_BUSY)
- stream logs via SSE/WS
- hard timeout optional (e.g. 30 min)
- kill endpoint (admin or user)

State:
projectRuntime[projectId] = { status:"running", startedAt, pid, command }


============================================================
10) CAPABILITIES ENDPOINT (UI HIDES UNSUPPORTED ACTIONS)
============================================================

GET /api/system/capabilities

Example:
{
  "ok": true,
  "data": {
    "canOpenFileManager": true,
    "canOpenExternalEditor": true,
    "supportsTTS": true,
    "supportsSTT": true,
    "supportsWebsocketLogs": true,
    "canDeploy": true,
    "canRestartService": false
  }
}


============================================================
11) MINIMAL AUDIT LOG (RECOMMENDED)
============================================================

Append-only jsonl:
.sera/audit.jsonl

Events:
- project.create/delete/update
- file.write/delete/rename
- changeset.create/apply/discard/rollback
- deploy.start/success/fail
- system.restart/cacheClear

Entry:
{ ts, user:"local", action:"changes.apply", projectId, changeSetId, details:{} }


============================================================
12) SECURITY NOTES (MUST)
============================================================

- Validate ALL inputs
- Never execute arbitrary shell commands from UI input
- Project root must be explicit and controlled
- Keep backups/snapshots out of preview hosting path
- Rate limit endpoints if exposed remotely


============================================================
END OF SPEC
============================================================

============================================================
SERA ↔ VOICE ↔ SERA-LOGIC ↔ OPENAI (CHATGPT) CONTRACT
ROBUST MESSAGE + COMMAND MAPPING SPEC
============================================================


============================================================
0) HIGH-LEVEL ARCHITECTURE
============================================================

VOICE (optional input)
   ↓
UI (Voice or Chat)
   ↓
SERA-LOGIC (Orchestrator / Router / Policy Engine)
   ↓
  ├── Internal Command Execution (File ops, Run, Deploy, etc.)
  └── OpenAI (ChatGPT API)
         ↓
      Tool Calls (function calling)
         ↓
SERA-LOGIC validates + executes tools
         ↓
Response returned to UI
         ↓
Optional: ProposedChangeSet → Patch Review → Apply


============================================================
1) CORE DESIGN PRINCIPLES
============================================================

1) SERA-LOGIC is the single source of truth.
2) OpenAI never directly writes files.
3) All file changes become ProposedChangeSets.
4) All actions are explicit (command or chat intent).
5) Every message carries structured metadata.
6) Voice and Chat use identical message envelope.
7) All tool executions are validated server-side.


============================================================
2) UNIVERSAL MESSAGE ENVELOPE (UI → SERA-LOGIC)
============================================================

{
  "id": "msg_uuid",
  "timestamp": 0,
  "source": "voice|chat|palette|system",
  "projectId": "proj_123",
  "threadId": "thr_123",
  "actor": {
    "type": "user",
    "id": "local"
  },
  "intentHint": "auto|chat|command|edit|run|deploy",
  "payload": {
    "type": "text",
    "content": "run build and fix errors"
  },
  "context": {
    "activeFile": "src/app.js",
    "selection": "...",
    "includeFullFile": false,
    "includeLogs": true,
    "includeProjectSummary": true
  }
}


============================================================
3) SERA-LOGIC INTENT RESOLUTION CONTRACT
============================================================

SERA-LOGIC decides one of:

A) INTERNAL_COMMAND
B) AI_CHAT
C) AI_TOOL_CALL
D) REJECT (invalid / unsafe)

Resolved structure:

{
  "resolution": {
    "type": "INTERNAL_COMMAND|AI_CHAT|AI_TOOL_CALL",
    "confidence": 0.94,
    "reason": "Matched macro 'run build'"
  }
}


============================================================
4) INTERNAL COMMAND CONTRACT
============================================================

{
  "command": {
    "name": "run_build",
    "args": {
      "projectId": "proj_123"
    }
  }
}

Allowed command names (allowlist):

- run_build
- run_dev
- run_tests
- deploy_latest
- open_file
- switch_project
- create_snapshot
- rollback_last_apply
- open_external_editor
- open_file_manager

All commands:
- validated against allowlist
- arguments validated
- executed in sandbox
- logged to audit log


============================================================
5) AI REQUEST CONTRACT (SERA-LOGIC → OPENAI)
============================================================

{
  "model": "gpt-4o",
  "messages": [
    { "role": "system", "content": "You are an IDE assistant." },
    { "role": "user", "content": "Fix the login bug." }
  ],
  "tools": [ TOOL_DEFINITIONS ],
  "tool_choice": "auto"
}

Tools must mirror SERA internal tool schema.


============================================================
6) TOOL DEFINITIONS (OPENAI FUNCTION CALLS)
============================================================

Example tools exposed to model:

create_files:
{
  "name": "create_files",
  "description": "Propose new files",
  "parameters": {
    "type": "object",
    "properties": {
      "files": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "path": {"type":"string"},
            "content": {"type":"string"}
          },
          "required": ["path","content"]
        }
      }
    },
    "required": ["files"]
  }
}

modify_files
delete_files
rename_file
run_command
explain_file


============================================================
7) TOOL CALL EXECUTION PIPELINE
============================================================

OpenAI returns:

{
  "tool_calls": [
    {
      "name": "modify_files",
      "arguments": { ... }
    }
  ]
}

SERA-LOGIC:
1) Validates arguments (path sandbox, limits, denylist)
2) Converts to ProposedChangeSet
3) Stores changeSet
4) Returns to UI:

{
  "type": "PROPOSED_CHANGESET",
  "changeSetId": "chg_123"
}

UI:
→ Opens Patch Review modal


============================================================
8) PROPOSED CHANGESET CONTRACT (CANONICAL)
============================================================

{
  "id": "chg_123",
  "projectId": "proj_123",
  "source": {
    "type": "ai",
    "threadId": "thr_123",
    "messageId": "msg_123",
    "model": "gpt-4o"
  },
  "createdAt": 0,
  "summary": "Fix login validation bug",
  "files": [
    {
      "path": "src/login.js",
      "type": "modify",
      "content": "..."
    }
  ],
  "diff": "optional unified diff"
}


============================================================
9) VOICE → SERA-LOGIC FLOW
============================================================

Voice transcript:
"Run build and deploy if successful"

UI wraps transcript in Universal Envelope.

SERA-LOGIC:
- Detect macro pattern
- Possibly split into multiple commands:
  run_build
  deploy_latest

OR
- Ask AI for reasoning:
  If ambiguous, forward to OpenAI.


============================================================
10) MULTI-STEP AI EXECUTION (SAFE LOOP)
============================================================

AI → tool_call
SERA validates + executes
SERA returns tool result to AI
AI continues reasoning
Loop until:
- final assistant message
- OR ProposedChangeSet created

Always:
- max iteration limit (e.g. 5)
- timeout
- token limit


============================================================
11) RESPONSE CONTRACT (SERA-LOGIC → UI)
============================================================

Possible response types:

CHAT_MESSAGE:
{
  "type": "CHAT_MESSAGE",
  "content": "Here is the explanation..."
}

PROPOSED_CHANGESET:
{
  "type": "PROPOSED_CHANGESET",
  "changeSetId": "chg_123"
}

COMMAND_RESULT:
{
  "type": "COMMAND_RESULT",
  "command": "run_build",
  "status": "started"
}

ERROR:
{
  "type": "ERROR",
  "code": "E_PATH",
  "message": "Unsafe path"
}


============================================================
12) SAFETY RULES (CRITICAL)
============================================================

- AI never writes directly.
- All file edits require patch review.
- Commands executed only from allowlist.
- All paths pass safeJoin().
- Max file count per ChangeSet (e.g., 200).
- Max total content size limit.
- Per-project apply lock.
- Audit log for every execution.


============================================================
13) OPTIONAL ADVANCED FEATURES
============================================================

- Intent classifier model separate from main GPT.
- Confidence threshold (fallback to clarification).
- Conversation memory summarization.
- Role separation:
  - Planner model
  - Executor model
- Capability gating:
  - If supportsDeploy=false, do not expose deploy tools.


============================================================
14) FINAL FLOW SUMMARY
============================================================

VOICE/CHAT INPUT
   ↓
UNIVERSAL MESSAGE ENVELOPE
   ↓
SERA-LOGIC
   ↓
[Internal Command] OR [OpenAI Tool Loop]
   ↓
ProposedChangeSet OR CommandResult OR ChatMessage
   ↓
UI renders + Patch Review if needed


============================================================
END OF CONTRACT
============================================================

============================================================
SERA COMMANDS SECTION (EXTENDED) — “HEY SERA” + HOME ASSISTANT + RESEARCH
(How it fits + what it looks like)
============================================================


============================================================
0) WHERE THIS FITS IN THE EXISTING CONTRACT
============================================================

Add a "COMMANDS" layer inside SERA-LOGIC:

UI (Voice/Chat/Palette)
  -> SERA-LOGIC Router
       -> Command Registry (macros, home automation, system ops)
       -> AI (only when needed)
       -> Tool executors (IDE tools, HA tools, research tools)

Key rule:
- If command can be executed deterministically: run directly (no AI).
- If command is ambiguous: ask follow-up OR use AI classifier.
- If command changes code/files: produce ProposedChangeSet (patch review).


============================================================
1) UNIVERSAL COMMAND ENVELOPE (UI → SERA-LOGIC)
============================================================

{
  "id": "cmd_uuid",
  "timestamp": 0,
  "source": "voice|chat|palette|system",
  "wakeWord": "hey_sera",
  "rawText": "hey sera turn on kitchen light",
  "projectId": "proj_123",
  "threadId": "thr_123",
  "context": {
    "mode": "ide|home|research|system",
    "activeFile": "src/app.js",
    "selection": "",
    "includeLogs": false
  },
  "routing": {
    "defaultDomain": "auto",
    "confidenceThreshold": 0.78
  }
}


============================================================
2) COMMAND REGISTRY (CANONICAL STRUCTURE)
============================================================

Command categories (domains):
- ide.*        (open file, build, apply patch, search)
- system.*     (status, logs, restart guarded)
- home.*       (home assistant devices/scenes)
- research.*   (web research, summarize, compare)
- comms.*      (send message, email, notifications)
- media.*      (play music, volume)
- calendar.*   (create event, reminders)

Registry entry schema:

{
  "id": "home.light.set",
  "domain": "home",
  "intent": ["turn on", "turn off", "lights"],
  "utterances": [
    "turn on {area} light",
    "turn off {area} lights",
    "set {area} brightness to {level}"
  ],
  "params": {
    "area": { "type": "string", "required": true },
    "device": { "type": "string", "required": false },
    "state": { "type": "string", "enum": ["on","off"], "required": false },
    "brightness": { "type": "number", "min": 0, "max": 100, "required": false }
  },
  "executor": "homeAssistant",
  "requiresConfirmation": false,
  "safety": {
    "risk": "low",
    "allowlistOnly": true
  }
}


============================================================
3) ROUTING / CLASSIFICATION (SERA-LOGIC)
============================================================

SERA-LOGIC Router outputs:

{
  "route": {
    "domain": "home|ide|research|system|auto",
    "commandId": "home.light.set",
    "confidence": 0.92
  },
  "slots": {
    "area": "kitchen",
    "state": "on"
  },
  "policy": {
    "needsConfirmation": false,
    "needsFollowUp": false
  }
}

Routing strategies:
A) Deterministic regex + phrase table (fast + offline)
B) Lightweight intent classifier model (optional)
C) AI fallback classification (OpenAI) when confidence low


============================================================
4) FOLLOW-UP QUESTION CONTRACT (WHEN AMBIGUOUS)
============================================================

When missing required params:

{
  "type": "FOLLOW_UP",
  "question": "Which kitchen light? (ceiling, counter, island)",
  "choices": ["ceiling","counter","island"],
  "pendingCommand": {
    "commandId": "home.light.set",
    "slots": { "area": "kitchen", "state": "on" }
  }
}

UI replies with:

{
  "type": "FOLLOW_UP_ANSWER",
  "pendingCommandId": "pending_123",
  "answer": "ceiling"
}


============================================================
5) EXECUTOR CONTRACT (COMMAND → ACTION)
============================================================

Unified execution request:

{
  "execute": {
    "commandId": "home.light.set",
    "slots": { "area": "kitchen", "device": "ceiling", "state": "on" },
    "requestId": "req_123"
  }
}

Unified execution result:

{
  "type": "COMMAND_RESULT",
  "requestId": "req_123",
  "commandId": "home.light.set",
  "status": "success",
  "data": {
    "entity_id": "light.kitchen_ceiling",
    "state": "on"
  }
}


============================================================
6) HOME ASSISTANT INTEGRATION (SERA-LOGIC ↔ HA)
============================================================

Recommended minimal HA API mapping:

- GET  /ha/entities            (cache entities, areas, devices)
- POST /ha/service_call        (domain, service, entity_id, data)
- GET  /ha/states/:entity_id

Example service call:

{
  "domain": "light",
  "service": "turn_on",
  "entity_id": "light.kitchen_ceiling",
  "data": { "brightness_pct": 80 }
}

Safety options:
- allowlist entity_ids
- restrict domains (no locks/alarms without confirmation)
- confirmation required for high-risk actions:
  - door lock/unlock
  - alarm arm/disarm
  - garage door


============================================================
7) RESEARCH DOMAIN (WHAT IT LOOKS LIKE)
============================================================

Research commands are “AI-first” but still structured:

Command:
research.query
Slots:
- query (string)
- depth (quick|normal|deep)
- sources (web|docs|both)
- output (bullets|brief|report)

Request:

{
  "execute": {
    "commandId": "research.query",
    "slots": {
      "query": "compare sqlite vs postgres for embedded ide storage",
      "depth": "normal",
      "sources": "web",
      "output": "bullets"
    }
  }
}

Result:

{
  "type": "RESEARCH_RESULT",
  "summary": "...",
  "keyPoints": ["..."],
  "citations": [ { "url": "...", "title": "...", "date": "..." } ]
}

Policy:
- if web access disabled, return:
  type=ERROR, code=E_NO_WEB, message="Web research unavailable"


============================================================
8) “HEY SERA” WAKE WORD + HOTWORD STATES
============================================================

Voice states:
- idle
- wake_detected
- listening_command
- confirming (optional)
- executing
- speaking_response

Wake pipeline:
1) detect wake phrase locally (or via voice engine)
2) capture next N seconds as command
3) route to SERA-LOGIC Router
4) execute or ask follow-up
5) optional TTS response

Minimum UI payload from voice layer:

{
  "wakeWord": "hey_sera",
  "transcript": "turn on kitchen light",
  "confidence": 0.87
}


============================================================
9) IDE COMMANDS + HOME COMMANDS COEXISTENCE
============================================================

Single global command namespace:
- ide.*
- home.*
- research.*
- system.*

Command palette can show them all, filter by domain:
- “> home: turn on kitchen”
- “> ide: run build”
- “> research: sqlite vs postgres”

Voice routing default:
- If programmer active and text includes IDE verbs (build/run/open file) -> ide.*
- If includes home verbs (lights/temperature/scene) -> home.*
- Otherwise -> chat/research depending on mode.


============================================================
10) IMPORTANT SAFETY POLICIES (HOME + SYSTEM)
============================================================

Risk levels:
- low: lights, media volume
- medium: thermostat, garage open
- high: locks, alarms, security

Rules:
- high-risk always requires confirmation + optional PIN
- system restart/deploy requires confirmation
- log all home/system actions in audit.jsonl


============================================================
11) COMMANDS SECTION UI (WHAT YOU ADD)
============================================================

Add a new top-level page OR modal: "Commands"

Sections:
- Favorites (user-defined)
- Home (areas/devices/scenes)
- IDE (build/run/open/search)
- Research (query presets)
- System (status/logs/admin guarded)

Per-command UI:
- run button
- parameter editor (slots)
- confirm toggles
- “add to favorites”
- show recent executions


============================================================
12) MINIMAL FILES TO IMPLEMENT (SUGGESTED)
============================================================

sera-logic/
  router.js            (intent routing + slot extraction)
  registry.json        (command registry)
  executors/
    ide.js             (existing IDE tool exec)
    home_assistant.js  (HA mapping)
    research.js        (AI research tool wrapper)
    system.js          (status/logs/admin)
  policy.js            (confirmation/PIN rules)
  audit.js             (append-only jsonl)

ui/
  commands.html/js     (commands page UI)
  command_palette.js   (search + execute commands)


============================================================
END OF COMMANDS SECTION SPEC
============================================================

============================================================
SERA “LEARNING LAYER” CONTRACT
(User-programmable commands + skills + memory + safe self-extension)
============================================================


============================================================
0) ANSWER: IS IT ALREADY BUILT IN?
============================================================

Partially.
- Your current contract supports adding commands via a registry + executors.
- A true “learning layer” adds:
  1) User-defined skills/macros
  2) User-defined tools (guarded)
  3) Memory (preferences, aliases, device names)
  4) Validation + review before activation
  5) Versioning + export/import


============================================================
1) LEARNING LAYER GOALS
============================================================

- Let users define new commands without editing core code.
- Let users teach synonyms/aliases (“kitchen light” = light.kitchen_ceiling).
- Let users build multi-step workflows (“build then deploy if success”).
- Keep security:
  - no arbitrary shell
  - no unrestricted file writes
  - allowlist tools and paths
  - confirmation for risky actions
- Make it portable:
  - export/import user skills as JSON/YAML bundles


============================================================
2) NEW ENTITIES
============================================================

A) USER_SKILL (macro / workflow)
B) USER_ALIAS (slot/entity mapping)
C) USER_MEMORY (prefs + defaults)
D) USER_TOOL (optional; guarded; admin)


============================================================
3) USER_SKILL SCHEMA (CANONICAL)
============================================================

{
  "id": "skill_001",
  "name": "Build then deploy",
  "description": "Runs build; if success deploy latest",
  "domain": "workflow",
  "utterances": [
    "build then deploy",
    "deploy after build",
    "ship it"
  ],
  "slots": {
    "project": { "type": "string", "required": false }
  },
  "steps": [
    {
      "type": "command",
      "commandId": "ide.run_build",
      "args": { "projectId": "$ctx.projectId" }
    },
    {
      "type": "if",
      "condition": { "ref": "$last.status", "eq": "success" },
      "then": [
        { "type": "command", "commandId": "system.deploy_latest", "args": {} }
      ],
      "else": [
        { "type": "notify", "level": "warn", "message": "Build failed; deploy skipped." }
      ]
    }
  ],
  "policy": {
    "requiresConfirmation": true,
    "risk": "medium",
    "allowedDomains": ["ide","system"]
  },
  "version": 1,
  "enabled": true,
  "createdAt": 0,
  "updatedAt": 0
}


============================================================
4) USER_ALIAS SCHEMA (ENTITY + SLOT LEARNING)
============================================================

{
  "id": "alias_101",
  "type": "home_entity",
  "phrase": "kitchen light",
  "mapsTo": {
    "entity_id": "light.kitchen_ceiling"
  },
  "confidence": 1.0,
  "enabled": true
}

Other alias types:
- project_alias: "myapp" -> proj_123
- path_alias: "config" -> "ui/settings.json"
- command_alias: "ship it" -> skill_001


============================================================
5) USER_MEMORY SCHEMA (PREFERENCES + DEFAULTS)
============================================================

{
  "id": "mem_local",
  "defaults": {
    "voiceTarget": "palette",
    "researchDepth": "normal",
    "preferredModel": "gpt-4o",
    "defaultProjectId": "proj_123"
  },
  "ui": {
    "programmerMode": "workbench",
    "dock": {
      "ai": "float",
      "runlog": "dock-right"
    }
  }
}


============================================================
6) USER_TOOL SCHEMA (OPTIONAL, GUARDED)
============================================================

NOTE: Only allow if admin enables. Must be sandboxed.

{
  "id": "tool_001",
  "name": "fetch_internal_doc",
  "description": "Fetches internal docs from allowed host",
  "executor": "http",
  "config": {
    "baseUrl": "https://docs.internal",
    "allowPaths": ["/api/**"],
    "timeoutMs": 8000
  },
  "policy": {
    "requiresConfirmation": false,
    "risk": "low"
  },
  "enabled": false
}


============================================================
7) ROUTING ORDER (HOW LEARNING LAYER FITS)
============================================================

Given input (voice/chat/palette):

1) Check user skills utterances (exact + fuzzy) → run skill if confident
2) Check user command aliases → mapped command/skill
3) Check built-in command registry (ide/home/research/system)
4) If ambiguous → follow-up question
5) If none match → AI chat fallback (OpenAI)
   - AI may propose creating a new skill (below)


============================================================
8) “LEARN THIS” FLOW (AI-SUGGESTED SKILLS)
============================================================

When user repeats patterns, AI can suggest:

{
  "type": "SUGGEST_SKILL",
  "skillDraft": { ...USER_SKILL... },
  "why": "You often say 'build then deploy'; I can save it as a command."
}

UI must show:
- preview skill steps
- required confirmations
- domains used
Buttons:
- Save & Enable
- Save Disabled
- Reject


============================================================
9) SKILL EXECUTION CONTRACT (SAFE WORKFLOW ENGINE)
============================================================

Execution request:

{
  "executeSkill": {
    "skillId": "skill_001",
    "context": {
      "projectId": "proj_123",
      "threadId": "thr_123",
      "vars": { }
    }
  }
}

Execution result:

{
  "type": "SKILL_RESULT",
  "skillId": "skill_001",
  "status": "success|failed|partial",
  "timeline": [
    { "step": 1, "type": "command", "commandId": "ide.run_build", "status": "success" },
    { "step": 2, "type": "if", "status": "then" },
    { "step": 3, "type": "command", "commandId": "system.deploy_latest", "status": "success" }
  ]
}

Rules:
- max steps (e.g. 20)
- max runtime (e.g. 60s unless build/deploy streaming)
- allowlist commands/domains
- confirmation on first run or on risky steps


============================================================
10) STORAGE + VERSIONING
============================================================

Store in:
.sera/learning/
  skills.json
  aliases.json
  memory.json
  tools.json (optional)

Every change:
- increments version
- append to audit.jsonl
- supports export/import bundle

Bundle format:

{
  "bundleVersion": 1,
  "skills": [...],
  "aliases": [...],
  "memory": {...}
}


============================================================
11) MINIMAL API ENDPOINTS FOR LEARNING LAYER
============================================================

GET    /api/learning/skills
POST   /api/learning/skills
PATCH  /api/learning/skills/:id
DELETE /api/learning/skills/:id
POST   /api/learning/skills/:id/execute

GET    /api/learning/aliases
POST   /api/learning/aliases
DELETE /api/learning/aliases/:id

GET    /api/learning/memory
PATCH  /api/learning/memory

POST   /api/learning/export
POST   /api/learning/import


============================================================
12) IMPORTANT SAFETY POLICIES (LEARNING LAYER)
============================================================

- Skills can only call allowlisted commands/tools.
- Skills cannot directly write files (must create ProposedChangeSet).
- High-risk domains require confirmation and optional PIN.
- Skills have “enabled” flag + can be disabled automatically on repeated failure.
- Skills must declare domains used; policy checks on every run.
- Export/import validated and sanitized (no tool injection by default).


============================================================
13) COMMAND PALETTE + COMMANDS PAGE INTEGRATION
============================================================

Command palette lists:
- built-in commands
- user skills
- favorites
- recent commands

Commands page provides:
- skill editor (visual steps)
- alias editor (phrase -> entity/project/path)
- import/export learning bundle
- enable/disable switches


============================================================
14) WHAT YOU SHOULD SEND TO THE PROCESSOR (LEARNING LAYER)
============================================================

- Implement storage files under .sera/learning/
- Implement endpoints listed above
- Implement workflow engine with step types:
  command | if | notify | ask_confirm
- Enforce allowlists + confirmations + audit logs
- Add UI hooks:
  - “Save as Command” button in Chat results
  - Voice macro learning suggestion flow


============================================================
END OF LEARNING LAYER CONTRACT
============================================================

============================================================
AI + AUTOMATION — WHAT YOU’RE STILL MISSING
(Advanced Gaps Most Systems Forget)
============================================================


============================================================
1) EXECUTION STATE MACHINE (CRITICAL)
============================================================

Right now you have:
- Commands
- AI tool calls
- Skills
- Patch review

What you are missing:
→ A formal EXECUTION STATE MODEL.

Without it, complex automation becomes messy.

Add:

Execution States:
- idle
- planning
- awaiting_tool
- executing
- awaiting_confirmation
- awaiting_followup
- streaming
- completed
- failed
- cancelled
- timed_out

Execution Record:

{
  "executionId": "exec_123",
  "source": "voice|chat|skill|system",
  "state": "executing",
  "startedAt": 0,
  "steps": [...],
  "currentStep": 2,
  "timeoutMs": 60000
}

Why this matters:
- Multi-step automation
- Recovery after crash
- Resume long workflows
- Proper streaming UI


============================================================
2) OBSERVABILITY LAYER (AUTOMATION DEBUGGING)
============================================================

You need:
- Per-execution timeline
- Token usage tracking
- Tool call latency tracking
- Failure reason capture
- Retries with backoff

Execution Log Example:

{
  "executionId": "exec_123",
  "events": [
    { "ts":0, "type":"intent_resolved", "domain":"ide" },
    { "ts":10, "type":"tool_call", "name":"modify_files" },
    { "ts":20, "type":"validation_passed" },
    { "ts":35, "type":"changeset_created" }
  ]
}

Without this:
AI automation becomes impossible to debug.


============================================================
3) RETRY + FAILURE STRATEGY (AUTONOMY SAFETY)
============================================================

Missing:
- Retry policy
- Partial success handling
- Idempotency keys

Add:

Retry policy per domain:
- ide.run_build → 0 retries
- research.query → 2 retries
- http tools → exponential backoff

Idempotency key:
{
  "executionId": "...",
  "idempotencyKey": "hash(payload)"
}

Prevents:
- Double deploy
- Double file write
- Duplicate home command


============================================================
4) PERMISSION SCOPES (VERY IMPORTANT)
============================================================

Right now you allow:
- ide.*
- home.*
- system.*
- research.*

You are missing:
→ Scoped execution permissions.

Add:

{
  "permissions": {
    "allowDomains": ["ide","research"],
    "denyCommands": ["system.restart"],
    "requireConfirmationFor": ["home.lock.*"]
  }
}

This enables:
- “AI research only mode”
- “No deploy mode”
- Child-safe home automation
- Demo mode


============================================================
5) RATE LIMITING + BUDGET CONTROL
============================================================

AI automation can spiral.

Add:

Per project:
- max tokens per hour
- max executions per minute
- max research calls per session

Per user:
- budget tracking

Contract:

{
  "limits": {
    "maxTokensPerHour": 100000,
    "maxExecutionsPerMinute": 10
  }
}

If exceeded:
→ Return ERROR: E_RATE_LIMIT


============================================================
6) MODEL STRATEGY LAYER (AI ORCHESTRATION)
============================================================

Right now:
You assume one GPT model.

Better approach:
Separate roles.

Models:
- intent_model (cheap, fast)
- reasoning_model (full GPT)
- summarizer_model
- code_model (optional)

Contract:

{
  "aiStrategy": {
    "intentModel": "gpt-4o-mini",
    "reasoningModel": "gpt-4o",
    "summarizerModel": "gpt-4o-mini"
  }
}

This prevents:
- Overpaying for simple routing
- Slow command classification


============================================================
7) LONG-RUNNING WORKFLOWS
============================================================

Missing:
- Async job queue

Examples:
- Deep research
- Multi-file refactor
- Large code migration
- Build + test + deploy pipeline

Add:

Job Contract:

{
  "jobId": "job_123",
  "type": "research.deep",
  "status": "queued|running|completed|failed",
  "progress": 0.42,
  "resultRef": "..."
}

UI subscribes via:
- WS /api/stream/jobs/:id


============================================================
8) MEMORY STRATEGY (AI CONTEXT CONTROL)
============================================================

Right now:
You pass full context toggles.

Missing:
→ Context compression layer.

Add:

Before sending to GPT:
- Summarize long logs
- Summarize file tree
- Summarize long threads

Store:

{
  "threadSummary": "...",
  "projectSummary": "...",
  "recentChangesSummary": "..."
}

Prevents:
- Token explosion
- Context truncation bugs


============================================================
9) SELF-HEALING AUTOMATION
============================================================

Advanced but powerful:

When a tool call fails:
- Ask AI to diagnose failure
- Suggest correction
- Retry with modified arguments

Example:
- Build fails
- AI reads logs
- Generates patch
- Proposes ChangeSet

This requires:
- Failure forwarding to AI
- Loop cap (max 3 iterations)


============================================================
10) ENVIRONMENT PROFILES
============================================================

Add support for profiles:

- dev
- staging
- production
- home
- demo

Profile contract:

{
  "profile": {
    "name": "production",
    "permissions": {...},
    "aiStrategy": {...},
    "limits": {...}
  }
}

Prevents:
- Deploy in wrong environment
- Home automation in wrong house
- Wrong API endpoints


============================================================
11) PLUGIN SYSTEM (FUTURE-PROOFING)
============================================================

Instead of hardcoding:
- home_assistant.js
- research.js

Add plugin contract:

{
  "plugin": {
    "id": "home-assistant",
    "version": "1.0",
    "domains": ["home"],
    "commands": [...],
    "tools": [...]
  }
}

Load dynamically from:
.sera/plugins/


============================================================
12) TEST HARNESS FOR AUTOMATION
============================================================

You need:
- Simulated execution mode

Example:

{
  "execute": {
    "commandId": "home.light.set",
    "slots": {...},
    "dryRun": true
  }
}

Returns:
- what WOULD execute
- without side effects

Critical for:
- AI-suggested skills
- High-risk commands


============================================================
13) CRITICAL THING MOST PEOPLE MISS
============================================================

AUTOMATION KILL SWITCH.

Global flag:

{
  "automationEnabled": true
}

If false:
- All execution returns ERROR: E_AUTOMATION_DISABLED

Emergency stop:
- Cancels running jobs
- Kills build processes
- Stops home automation actions


============================================================
14) FINAL SUMMARY — WHAT YOU WERE MISSING
============================================================

You already have:
- Command routing
- Tool calling
- Patch review
- Learning layer

You were missing:
- Execution state machine
- Observability + logs
- Retry + idempotency
- Permission scopes
- Budget/rate limiting
- Multi-model strategy
- Async job system
- Context compression
- Self-healing loops
- Environment profiles
- Plugin system
- Dry-run testing
- Automation kill switch


============================================================
If you implement those, this stops being
“AI-assisted IDE”
and becomes
“AI Orchestration Platform.”
============================================================

============================================================
FINAL “GO BUILD” CHECKLIST (LAST HIGH-VALUE ITEMS)
============================================================


============================================================
1) VERSIONED CONTRACTS (PREVENT BREAKING CHANGES)
============================================================

- Add version fields to every envelope:
  - universal message envelope
  - command envelope
  - tool results
  - changesets

Example:
{
  "contractVersion": 1,
  "type": "...",
  ...
}

- Server rejects unknown major versions:
  ERROR: E_CONTRACT_VERSION


============================================================
2) TRACE IDS END-TO-END (DEBUG EVERYTHING FAST)
============================================================

Every request should carry:
- traceId
- executionId
- threadId
- projectId

Example (UI -> SERA-LOGIC):
{
  "traceId": "trace_123",
  "executionId": "exec_123",
  "projectId": "proj_123",
  "threadId": "thr_123",
  ...
}

Log all with traceId so you can correlate:
voice -> router -> ai -> tool -> changeset -> apply


============================================================
3) CONFIG MANAGEMENT (INSTALL-TIME + RUNTIME)
============================================================

- Separate configs:
  A) global server config (endpoints, keys, HA token)
  B) project config (model/build/run/include rules)
  C) user config (macros/aliases/prefs)

- Validate configs on load and provide diagnostics warnings.


============================================================
4) SECRET HANDLING (DON’T LET KEYS LEAK)
============================================================

- Never store API keys in project files.
- Store secrets in:
  - env vars OR
  - encrypted local store (if needed)
- Ensure logs redact:
  - Authorization headers
  - tokens
  - OpenAI keys
  - HA tokens


============================================================
5) SAFE DEFAULT MODES (REDUCE “OOPS”)
============================================================

- Default permissions:
  - research enabled
  - home enabled (low-risk only)
  - system admin actions disabled until explicitly enabled
  - deploy requires confirmation + optional PIN

- Always require patch review for code edits.


============================================================
6) “TOOL SURFACE” MINIMIZATION (SECURITY)
============================================================

Only expose tools to OpenAI that you will actually allow.

Example:
- If canDeploy=false, do not expose deploy tools.
- If home integration disabled, do not expose home tools.


============================================================
7) GOLDEN PATHS (USER SUCCESS FIRST)
============================================================

Pick 3 “happy path” automations and make them flawless:

1) “Hey Sera, open my project and run build.”
2) “Fix this error” (logs -> patch -> review -> apply)
3) “Deploy latest” (confirm -> deploy -> show status/log link)

Everything else can be later.


============================================================
8) TEST MATRIX (MINIMUM)
============================================================

- Unit tests:
  - safeJoin path sandbox
  - changeset validation
  - skill execution engine
  - permissions + confirmation enforcement

- Integration tests:
  - create project -> create thread -> propose changeset -> apply -> rollback
  - run build -> stream logs
  - home assistant light on/off (dry-run then real)

- Dry-run mode for all high-risk actions.


============================================================
9) BACKUP / RECOVERY (YOU’LL THANK YOURSELF)
============================================================

- Auto snapshot before every apply
- “Undo last apply” button
- “Restore snapshot” UI
- Crash recovery:
  - resume execution timelines if possible
  - show last failed execution + traceId


============================================================
10) SHIP IT CHECK
============================================================

If you have:
- contract versioning
- trace ids
- strict tool allowlists
- patch review enforced
- snapshots + undo
- capabilities gating

…you can build aggressively without regrets.


============================================================
END — YOU’RE READY TO BUILD
============================================================