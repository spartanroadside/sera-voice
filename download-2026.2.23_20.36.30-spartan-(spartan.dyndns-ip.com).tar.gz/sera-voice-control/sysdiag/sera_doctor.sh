#!/usr/bin/env bash
set -euo pipefail

# SERA Doctor: quick diagnostics + failure artifacts
# Creates a timestamped report folder under <root>/debug

ROOT_DEFAULT="/home/spartan/sera"
ROOT="${SERA_ROOT:-$ROOT_DEFAULT}"
PROJECT="${SERA_PROJECT:-sera-voice-control}"
APP_DIR="$ROOT/$PROJECT"
DEBUG_DIR="$ROOT/debug"
TS="$(date +%Y-%m-%d_%H%M%S)"
OUT_DIR="$DEBUG_DIR/doctor_report_$TS"

mkdir -p "$OUT_DIR"

log() { echo "[$(date +%H:%M:%S)] $*"; }

write_cmd() {
  local name="$1"; shift
  {
    echo "$ $*"
    "$@" 2>&1
  } > "$OUT_DIR/$name.txt" || true
}

# Basic metadata
{
  echo "ts=$TS"
  echo "root=$ROOT"
  echo "project=$PROJECT"
  echo "app_dir=$APP_DIR"
  echo "hostname=$(hostname)"
  echo "uname=$(uname -a)"
} > "$OUT_DIR/meta.txt"

# Check key paths
{
  echo "PATH CHECKS"
  for p in "$ROOT" "$APP_DIR" "$APP_DIR/docker-compose.yml" "$APP_DIR/.env" "$ROOT/incoming" "$ROOT/tools" "$ROOT/logs" "$ROOT/backups"; do
    if [ -e "$p" ]; then
      echo "OK: $p"
    else
      echo "MISSING: $p"
    fi
  done
} > "$OUT_DIR/paths.txt"

# System stats
write_cmd df df -h
write_cmd free free -h
write_cmd docker_version docker version
write_cmd docker_ps docker ps
write_cmd compose_ps bash -lc "cd \"$APP_DIR\" && docker compose ps"
write_cmd compose_logs bash -lc "cd \"$APP_DIR\" && docker compose logs --tail=200"

# Endpoint health checks
{
  echo "$ curl -fsS http://127.0.0.1:3000/api/health"
  curl -fsS http://127.0.0.1:3000/api/health || true
  echo
  echo "$ curl -fsS http://127.0.0.1:3100/health"
  curl -fsS http://127.0.0.1:3100/health || true
  echo
  echo "$ curl -fsS http://127.0.0.1:3200/health"
  curl -fsS http://127.0.0.1:3200/health || true
  echo
  echo "$ curl -fsS http://127.0.0.1:3000/api/config"
  curl -fsS http://127.0.0.1:3000/api/config || true
} > "$OUT_DIR/health.txt"

# Summary
OK=1
if grep -q "MISSING:" "$OUT_DIR/paths.txt"; then OK=0; fi
if ! grep -q '"ok":true' "$OUT_DIR/health.txt"; then OK=0; fi

{
  echo "SERA_DOCTOR_OK=$OK"
  echo "report_dir=$OUT_DIR"
  echo "tip: review compose_logs.txt and health.txt first"
} > "$OUT_DIR/summary.txt"

log "Doctor report created: $OUT_DIR"
cat "$OUT_DIR/summary.txt"
