from __future__ import annotations

import os
import time
import platform
from pathlib import Path

import psutil
from fastapi import FastAPI

app = FastAPI(title="SERA Sysdiag", version="0.1.0")

SERA_ROOT = Path(os.environ.get("SERA_ROOT", "/sera"))
START_TS = time.time()


def bytes_view(n: int) -> dict:
    n = int(n)
    return {
        "bytes": n,
        "kb": round(n / 1024, 2),
        "mb": round(n / 1024 / 1024, 2),
        "gb": round(n / 1024 / 1024 / 1024, 3),
    }


def safe_disk_usage(path: Path) -> dict:
    try:
        u = psutil.disk_usage(str(path))
        return {
            "path": str(path),
            "total": bytes_view(u.total),
            "used": bytes_view(u.used),
            "free": bytes_view(u.free),
            "percent": float(u.percent),
        }
    except Exception as e:
        return {"path": str(path), "error": str(e)}


@app.get("/health")
def health():
    return {"ok": True, "uptime_s": round(time.time() - START_TS, 1)}


@app.get("/system.json")
def system_json():
    vm = psutil.virtual_memory()
    sm = psutil.swap_memory()
    la = os.getloadavg() if hasattr(os, "getloadavg") else (0.0, 0.0, 0.0)

    # cpu_percent needs an interval to be meaningful; use a very short one
    cpu_pct = psutil.cpu_percent(interval=0.15)

    disks = [safe_disk_usage(Path("/"))]
    if SERA_ROOT.exists():
        disks.append(safe_disk_usage(SERA_ROOT))

    return {
        "ts": int(time.time()),
        "host": {
            "hostname": platform.node(),
            "platform": platform.platform(),
            "python": platform.python_version(),
        },
        "uptime_s": int(time.time() - psutil.boot_time()),
        "cpu": {
            "percent": float(cpu_pct),
            "count_logical": psutil.cpu_count(logical=True),
            "count_physical": psutil.cpu_count(logical=False),
            "loadavg": {"1": float(la[0]), "5": float(la[1]), "15": float(la[2])},
        },
        "mem": {
            "total": bytes_view(vm.total),
            "available": bytes_view(vm.available),
            "used": bytes_view(vm.used),
            "percent": float(vm.percent),
        },
        "swap": {
            "total": bytes_view(sm.total),
            "used": bytes_view(sm.used),
            "free": bytes_view(sm.free),
            "percent": float(sm.percent),
        },
        "disks": disks,
    }


@app.get("/raw")
def raw():
    """A minimal, fast text endpoint for quick debugging."""
    la = os.getloadavg() if hasattr(os, "getloadavg") else (0.0, 0.0, 0.0)
    vm = psutil.virtual_memory()
    return {
        "load1": float(la[0]),
        "mem_percent": float(vm.percent),
    }
