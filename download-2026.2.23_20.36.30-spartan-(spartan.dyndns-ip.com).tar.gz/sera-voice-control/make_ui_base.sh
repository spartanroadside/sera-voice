#!/usr/bin/env bash
set -euo pipefail

ROOT="ui-base"
mkdir -p "$ROOT/css" "$ROOT/scripts" "$ROOT/docs" "$ROOT/demo"

# ---- Copy your existing files if present (adjust paths if needed) ----
cp -f "app.css" "$ROOT/css/app.css" 2>/dev/null || true
cp -f "main.css" "$ROOT/css/main.css" 2>/dev/null || true
cp -f "buttons.css" "$ROOT/css/buttons.css" 2>/dev/null || true
cp -f "css/new-buttons.css" "$ROOT/css/new-buttons.css" 2>/dev/null || true
cp -f "system_nav.css" "$ROOT/css/system_nav.css" 2>/dev/null || true
cp -f "project_builder.css" "$ROOT/css/project_builder.css" 2>/dev/null || true

# ==========================
# CSS: PANELS (single source of truth)
# ==========================
cat > "$ROOT/css/panels.css" <<'CSS'
/* PANELS
   One reusable panel component that replaces duplication like:
   - .p2panel (project_builder.css) :contentReference[oaicite:2]{index=2}
   - .pbPanel (project_builder.css) :contentReference[oaicite:3]{index=3}
*/
:root{
  --panel-bg: rgba(255,255,255,.03);
  --panel-border: rgba(255,255,255,.10);
  --panel-border-hover: rgba(255,255,255,.16);
  --panel-radius: var(--radius, 18px);
}

.panel{
  border:1px solid var(--panel-border);
  border-radius: var(--panel-radius);
  background: var(--panel-bg);
  overflow:hidden;
  min-height:0;
  display:flex;
  flex-direction:column;
}

.panel:hover{ border-color: var(--panel-border-hover); }

.panel__hdr{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  padding:10px 10px 8px;
  border-bottom:1px solid rgba(255,255,255,.08);
}
.panel__title{
  font-size:12px;
  letter-spacing:.06em;
  text-transform:uppercase;
  opacity:.78;
}
.panel__body{
  padding:10px;
  overflow:auto;
  flex:1;
  min-height:0;
}

.panel__body--tight{ padding:10px; }
.panel__body--flush{ padding:0; }
CSS

# ==========================
# CSS: SPLITTERS (resizers)
# ==========================
cat > "$ROOT/css/splitters.css" <<'CSS'
/* SPLITTERS
   Use with CSS grid or flex. JS drives resizing.
*/
:root{
  --splitter-hit: 10px;
  --splitter-line: rgba(147,197,253,.20);
  --splitter-line-hover: rgba(147,197,253,.38);
}

.splitter{
  position:relative;
  z-index: 5;
  flex:0 0 auto;
  user-select:none;
}
.splitter--x{ width: var(--splitter-hit); cursor: col-resize; }
.splitter--y{ height: var(--splitter-hit); cursor: row-resize; }

.splitter::before{
  content:"";
  position:absolute;
  inset:0;
  background: transparent;
}
.splitter::after{
  content:"";
  position:absolute;
  left:50%; top:50%;
  width:2px; height: 60%;
  transform: translate(-50%,-50%);
  border-radius: 999px;
  background: var(--splitter-line);
  opacity:.55;
}
.splitter--y::after{
  width:60%; height:2px;
}

.splitter:hover::after{ background: var(--splitter-line-hover); opacity:.9; }
CSS

# ==========================
# CSS: DOCKS (dock zones + dock panels)
# ==========================
cat > "$ROOT/css/docks.css" <<'CSS'
/* DOCKS
   Dock zones are areas that accept docked panels/windows.
   Use .dockZone--left/right/bottom inside your layout.
*/
:root{
  --dock-bg: rgba(255,255,255,.03);
  --dock-border: rgba(255,255,255,.10);
  --dock-radius: var(--radius, 18px);
}

.dockZone{
  border:1px dashed rgba(255,255,255,.12);
  border-radius: var(--dock-radius);
  background: rgba(255,255,255,.02);
  min-height: 120px;
}

.dockZone.is-dropTarget{
  border-color: rgba(147,197,253,.65);
  box-shadow: inset 0 0 0 2px rgba(147,197,253,.18);
}

.dockPanel{
  border:1px solid var(--dock-border);
  border-radius: var(--dock-radius);
  background: var(--dock-bg);
  overflow:hidden;
  display:flex;
  flex-direction:column;
  min-height: 160px;
}

.dockPanel__hdr{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  padding:10px 10px 8px;
  border-bottom:1px solid rgba(255,255,255,.08);
}

.dockPanel__title{
  font-size:12px;
  letter-spacing:.06em;
  text-transform:uppercase;
  opacity:.78;
}

.dockPanel__body{
  padding:10px;
  overflow:auto;
  flex:1;
  min-height:0;
}
CSS

# ==========================
# CSS: WINDOWS (floating detachable panels)
# ==========================
cat > "$ROOT/css/windows.css" <<'CSS'
/* FLOATING WINDOWS
   Detachable tool windows that can be moved around, focused, snapped, and stacked.
*/
:root{
  --win-bg: rgba(18,26,42,.98);
  --win-border: rgba(255,255,255,.12);
  --win-radius: var(--radius, 18px);
  --win-shadow: 0 18px 60px rgba(0,0,0,.55);
  --z-window: 1000;
}

.win{
  position: fixed;
  left: 10vw;
  top: 14vh;
  width: min(520px, 92vw);
  height: min(520px, 78vh);

  display:flex;
  flex-direction:column;
  background: var(--win-bg);
  border: 1px solid var(--win-border);
  border-radius: var(--win-radius);
  box-shadow: var(--win-shadow);
  overflow:hidden;
  z-index: var(--z-window);

  /* default visible; toggle .is-hidden */
}
.win.is-hidden{ display:none; }

.win__hdr{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  padding:10px 10px 8px;
  border-bottom:1px solid rgba(255,255,255,.10);
  cursor: move;
  user-select:none;
}
.win__title{
  font-weight:800;
  font-size:13px;
  letter-spacing:.02em;
}
.win__actions{ display:flex; gap:8px; align-items:center; }

.win__body{
  padding:10px;
  overflow:auto;
  flex:1;
  min-height:0;
}

/* focus ring when active window */
.win.is-focused{
  border-color: rgba(147,197,253,.55);
  box-shadow:
    0 18px 60px rgba(0,0,0,.55),
    0 0 0 3px rgba(147,197,253,.18);
}
CSS

# ==========================
# CSS: MODALS (schema)
# ==========================
cat > "$ROOT/css/modals.css" <<'CSS'
/* MODALS (central schema)
   Use for blocking dialogs: confirmations, settings, etc.
*/
:root{
  --modal-overlay: rgba(0,0,0,.60);
  --modal-bg: rgba(18,26,42,.98);
  --modal-border: rgba(255,255,255,.12);
  --modal-radius: var(--radius, 18px);
  --modal-shadow: 0 18px 60px rgba(0,0,0,.55);
  --modal-anim: 160ms;
}

.modalOverlay{
  position:fixed; inset:0;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:18px;
  background: var(--modal-overlay);
  z-index: 1200;

  opacity:0; visibility:hidden; pointer-events:none;
  transition: opacity var(--modal-anim) ease, visibility var(--modal-anim) ease;
}
.modalOverlay.is-open{
  opacity:1; visibility:visible; pointer-events:auto;
}
.modalWin{
  width: min(680px, 96vw);
  max-height: min(92vh, 920px);
  display:flex;
  flex-direction:column;
  background: var(--modal-bg);
  border: 1px solid var(--modal-border);
  border-radius: var(--modal-radius);
  box-shadow: var(--modal-shadow);
  transform: translateY(12px);
  transition: transform var(--modal-anim) ease;
}
.modalOverlay.is-open .modalWin{ transform: translateY(0); }

.modalHdr{ padding:12px; border-bottom:1px solid rgba(255,255,255,.10); display:flex; justify-content:space-between; gap:10px; }
.modalTitle{ font-weight:800; font-size:13px; }
.modalBody{ padding:12px; overflow:auto; flex:1; }
.modalFtr{ padding:12px; border-top:1px solid rgba(255,255,255,.10); display:flex; justify-content:flex-end; gap:8px; }
CSS

# ==========================
# CSS: IDE LAYOUT (workbench tuned for E)
# ==========================
cat > "$ROOT/css/ide-layout.css" <<'CSS'
/* IDE WORKBENCH LAYOUT
   Targets your Program Builder concept: files + editor + AI + run log + bottom chat.
   Works with your tokens in app.css:contentReference[oaicite:4]{index=4}.
*/
:root{
  --wb-gap: 12px;
  --wb-min-left: 260px;
  --wb-min-right: 260px;
}

.workbench{
  display:flex;
  flex-direction:column;
  gap: var(--wb-gap);
  min-height: calc(100vh - 160px);
}

.workbench__topbar{
  display:flex;
  gap:10px;
  align-items:center;
  justify-content:space-between;
  flex-wrap:wrap;
  padding:10px;
  border:1px solid rgba(255,255,255,.10);
  border-radius: var(--radius, 18px);
  background: rgba(255,255,255,.02);
}

/* Grid with splitters:
   [left] [splitter] [center] [splitter] [right]
*/
.workbench__main{
  display:grid;
  gap: 0;
  grid-template-columns:
    minmax(var(--wb-min-left), 34%)
    var(--splitter-hit, 10px)
    minmax(0, 1fr)
    var(--splitter-hit, 10px)
    minmax(var(--wb-min-right), 24%);
  align-items:stretch;
  min-height: 560px;
}

.wbCol{ min-width:0; display:flex; flex-direction:column; gap: var(--wb-gap); }
.wbCol--left{ padding-right: var(--wb-gap); }
.wbCol--center{ padding: 0 var(--wb-gap); }
.wbCol--right{ padding-left: var(--wb-gap); }

/* bottom chat/output */
.workbench__bottom{
  border:1px solid rgba(255,255,255,.10);
  border-radius: var(--radius, 18px);
  background: rgba(255,255,255,.02);
  padding:10px;
  min-height: 140px;
}

/* Responsive */
@media (max-width: 1100px){
  .workbench__main{
    grid-template-columns: 1fr;
    gap: var(--wb-gap);
  }
  .wbCol--left, .wbCol--center, .wbCol--right{
    padding:0;
  }
  .workbench__main .splitter{ display:none; }
}
CSS

# ==========================
# CSS: FORMS + UTIL + SCROLLBARS
# ==========================
cat > "$ROOT/css/forms.css" <<'CSS'
:root{
  --field-bg: rgba(0,0,0,.18);
  --field-border: rgba(255,255,255,.12);
  --field-radius: 12px;
}

input, select, textarea{
  color: var(--text);
  border:1px solid var(--field-border);
  background: var(--field-bg);
  border-radius: var(--field-radius);
  padding: 6px 10px;
  outline:none;
  font-size:12px;
  line-height:1.25;
}
input, select{ height: 32px; }
textarea{ min-height: 44px; }

input:focus, select:focus, textarea:focus{
  border-color: rgba(147,197,253,.55);
  box-shadow: 0 0 0 3px rgba(147,197,253,.18);
}
CSS

cat > "$ROOT/css/utilities.css" <<'CSS'
.hidden{ display:none !important; }
.flex{ display:flex; }
.flexCol{ display:flex; flex-direction:column; }
.itemsCenter{ align-items:center; }
.justifyBetween{ justify-content:space-between; }
.justifyEnd{ justify-content:flex-end; }
.gap8{ gap:8px; }
.gap10{ gap:10px; }
.mono{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace; }
.muted{ opacity:.78; }
CSS

cat > "$ROOT/css/scrollbars.css" <<'CSS'
*{ scrollbar-width: thin; scrollbar-color: rgba(233,238,252,.35) rgba(0,0,0,.15); }
*::-webkit-scrollbar{ width:10px; height:10px; }
*::-webkit-scrollbar-track{ background: rgba(0,0,0,.15); }
*::-webkit-scrollbar-thumb{
  background: rgba(233,238,252,.22);
  border: 2px solid rgba(0,0,0,.10);
  border-radius: 999px;
}
*::-webkit-scrollbar-thumb:hover{ background: rgba(233,238,252,.32); }
CSS

# ==========================
# CSS: TABS + TOASTS
# ==========================
cat > "$ROOT/css/tabs.css" <<'CSS'
/* TAB STRIP (for editor tabs, dock tabs, etc) */
.tabs{
  display:flex;
  gap:6px;
  flex-wrap:wrap;
  padding:8px;
  border-bottom:1px solid rgba(255,255,255,.08);
}
.tab{
  padding:6px 10px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,.10);
  background: rgba(255,255,255,.02);
  font-size:12px;
  cursor:pointer;
}
.tab.is-active{
  border-color: rgba(42,89,255,.55);
  box-shadow: inset 0 0 0 2px rgba(42,89,255,.18);
  background: rgba(42,89,255,.10);
}
CSS

cat > "$ROOT/css/toasts.css" <<'CSS'
/* TOASTS: non-blocking notifications */
:root{
  --toast-bg: rgba(18,26,42,.98);
  --toast-border: rgba(255,255,255,.12);
  --toast-shadow: 0 18px 60px rgba(0,0,0,.55);
}

.toastHost{
  position:fixed;
  right: 16px;
  bottom: 16px;
  display:flex;
  flex-direction:column;
  gap:10px;
  z-index: 2000;
}
.toast{
  width: min(420px, 92vw);
  background: var(--toast-bg);
  border:1px solid var(--toast-border);
  border-radius: var(--radius, 18px);
  box-shadow: var(--toast-shadow);
  padding:10px;
}
.toast__row{ display:flex; justify-content:space-between; align-items:center; gap:10px; }
.toast__title{ font-weight:800; font-size:13px; }
.toast__msg{ font-size:12px; opacity:.85; margin-top:6px; }
CSS

# ==========================
# JS: WINDOWS (drag + focus + snap)
# ==========================
cat > "$ROOT/scripts/ui_windows.js" <<'JS'
let z = 1000;

export function focusWin(win){
  z += 1;
  win.style.zIndex = z;
  document.querySelectorAll(".win.is-focused").forEach(el=>el.classList.remove("is-focused"));
  win.classList.add("is-focused");
}

export function makeDraggable(win, handle){
  let dragging=false, sx=0, sy=0, ox=0, oy=0;

  const down = (e)=>{
    dragging=true;
    focusWin(win);
    const r = win.getBoundingClientRect();
    ox = r.left; oy = r.top;
    sx = e.clientX; sy = e.clientY;
    e.preventDefault();
  };

  const move = (e)=>{
    if(!dragging) return;
    const dx = e.clientX - sx;
    const dy = e.clientY - sy;
    win.style.left = (ox + dx) + "px";
    win.style.top  = (oy + dy) + "px";
  };

  const up = ()=> dragging=false;

  handle.addEventListener("mousedown", down);
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}

export function snapTo(win, where){
  const pad = 12;
  const W = window.innerWidth;
  const H = window.innerHeight;

  win.style.position = "fixed";

  if(where === "right"){
    win.style.left = (W - pad - Math.min(420, W*0.34)) + "px";
    win.style.top = pad + "px";
  }else if(where === "left"){
    win.style.left = pad + "px";
    win.style.top = pad + "px";
  }else if(where === "bottom"){
    win.style.left = pad + "px";
    win.style.top  = (H - pad - Math.min(360, H*0.35)) + "px";
  }
}
JS

# ==========================
# JS: SPLITTERS (resize grid columns)
# ==========================
cat > "$ROOT/scripts/ui_splitters.js" <<'JS'
/*
  Resize a 3-column grid with two vertical splitters:
  grid-template-columns: [left] [s] [center] [s] [right]
  We update left/right widths while keeping center flexible.
*/
export function bindWorkbenchSplitters(gridEl, leftSplitterEl, rightSplitterEl){
  const minLeft = 220;
  const minRight = 220;

  const dragX = (splitterEl, which) => {
    let dragging=false, startX=0, startCols=null;

    const readCols = () => {
      const cs = getComputedStyle(gridEl).gridTemplateColumns.split(" ");
      // [0]=left, [2]=center, [4]=right
      return { left: parseFloat(cs[0]), right: parseFloat(cs[4]) };
    };

    const down = (e)=>{
      dragging=true;
      startX = e.clientX;
      startCols = readCols();
      document.body.style.cursor = "col-resize";
      e.preventDefault();
    };

    const move = (e)=>{
      if(!dragging) return;
      const dx = e.clientX - startX;
      let left = startCols.left;
      let right = startCols.right;

      if(which === "left"){
        left = Math.max(minLeft, startCols.left + dx);
      }else{
        right = Math.max(minRight, startCols.right - dx);
      }

      gridEl.style.gridTemplateColumns = `${left}px var(--splitter-hit,10px) minmax(0,1fr) var(--splitter-hit,10px) ${right}px`;
    };

    const up = ()=>{
      dragging=false;
      document.body.style.cursor = "";
    };

    splitterEl.addEventListener("mousedown", down);
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  dragX(leftSplitterEl, "left");
  dragX(rightSplitterEl, "right");
}
JS

# ==========================
# JS: DOCKS (dock/undock a window into a zone)
# ==========================
cat > "$ROOT/scripts/ui_docks.js" <<'JS'
/*
  Minimal dock/undock:
  - A floating .win can be "docked" into a .dockZone by moving its body into a .dockPanel
  - Keeps it simple: we treat docking as reparenting content.
*/

export function dockWin(winEl, dockZoneEl){
  const body = winEl.querySelector(".win__body");
  const title = winEl.querySelector(".win__title")?.textContent || "Docked";

  // create a dockPanel
  const panel = document.createElement("div");
  panel.className = "dockPanel";
  panel.dataset.fromWin = winEl.id || "";

  const hdr = document.createElement("div");
  hdr.className = "dockPanel__hdr";

  const t = document.createElement("div");
  t.className = "dockPanel__title";
  t.textContent = title;

  const actions = document.createElement("div");
  actions.style.display = "flex";
  actions.style.gap = "8px";

  const undockBtn = document.createElement("button");
  undockBtn.className = "ghost";
  undockBtn.textContent = "Undock";
  undockBtn.addEventListener("click", ()=> undockWin(winEl, panel));

  actions.appendChild(undockBtn);
  hdr.appendChild(t);
  hdr.appendChild(actions);

  const dockBody = document.createElement("div");
  dockBody.className = "dockPanel__body";
  dockBody.appendChild(body);

  panel.appendChild(hdr);
  panel.appendChild(dockBody);

  dockZoneEl.innerHTML = "";
  dockZoneEl.appendChild(panel);

  winEl.classList.add("is-hidden");
}

export function undockWin(winEl, dockPanelEl){
  const dockBody = dockPanelEl.querySelector(".dockPanel__body");
  const body = dockBody?.firstElementChild;
  if(!body) return;

  const winBody = document.createElement("div");
  winBody.className = "win__body";
  winBody.appendChild(body);

  const old = winEl.querySelector(".win__body");
  old?.replaceWith(winBody);

  winEl.classList.remove("is-hidden");
  dockPanelEl.remove();
}
JS

# ==========================
# JS: TOASTS
# ==========================
cat > "$ROOT/scripts/ui_toasts.js" <<'JS'
export function ensureToastHost(){
  let host = document.querySelector(".toastHost");
  if(!host){
    host = document.createElement("div");
    host.className = "toastHost";
    document.body.appendChild(host);
  }
  return host;
}

export function toast(title, msg, ms=2800){
  const host = ensureToastHost();
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = `
    <div class="toast__row">
      <div class="toast__title"></div>
      <button class="ghost">✕</button>
    </div>
    <div class="toast__msg"></div>
  `;
  el.querySelector(".toast__title").textContent = title;
  el.querySelector(".toast__msg").textContent = msg;

  el.querySelector("button").addEventListener("click", ()=> el.remove());
  host.appendChild(el);

  setTimeout(()=> el.remove(), ms);
}
JS

# ==========================
# DOCS
# ==========================
cat > "$ROOT/docs/CSS_BASE_GUIDE.md" <<'MD'
# UI Base Guide (Resizable + Dockable + Floating windows)

This package is built to match your existing global tokens in `app.css` (e.g. `--bg`, `--panel`, `--border`, `--text`, `--radius`):contentReference[oaicite:5]{index=5}.

## CSS load order (recommended)
1) app.css
2) scrollbars.css
3) forms.css
4) buttons.css / new-buttons.css
5) utilities.css
6) panels.css
7) splitters.css
8) docks.css
9) windows.css
10) modals.css
11) ide-layout.css
12) page-specific CSS (project_builder.css)

## Concept mapping
- Panels (reusable containers): `.panel`
- Docks (persistent edge zones): `.dockZone` + `.dockPanel`
- Floating windows (detachable AI tools): `.win`
- Modals (blocking dialogs): `.modalOverlay` + `.modalWin`
- Splitters (resizers): `.splitter` + JS that adjusts grid columns

## Workbench skeleton
Use `.workbench__main` with two vertical splitters:
grid-template-columns: left / splitter / center / splitter / right

JS: `bindWorkbenchSplitters(...)` will resize left and right.
MD

# ==========================
# DEMO: IDE demo page
# ==========================
cat > "$ROOT/demo/ide_demo.html" <<'HTML'
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>IDE Base Demo</title>

  <!-- Use your existing tokens + base styles -->
  <link rel="stylesheet" href="../css/app.css"/>

  <!-- New base -->
  <link rel="stylesheet" href="../css/scrollbars.css"/>
  <link rel="stylesheet" href="../css/forms.css"/>
  <link rel="stylesheet" href="../css/utilities.css"/>
  <link rel="stylesheet" href="../css/panels.css"/>
  <link rel="stylesheet" href="../css/splitters.css"/>
  <link rel="stylesheet" href="../css/docks.css"/>
  <link rel="stylesheet" href="../css/windows.css"/>
  <link rel="stylesheet" href="../css/modals.css"/>
  <link rel="stylesheet" href="../css/ide-layout.css"/>
  <link rel="stylesheet" href="../css/toasts.css"/>
  <link rel="stylesheet" href="../css/tabs.css"/>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <div class="workbench">
        <div class="workbench__topbar">
          <div class="row">
            <button class="primary" id="btnOpenAi">Open AI Window</button>
            <button class="ghost" id="btnDockAi">Dock AI → Right</button>
            <button class="ghost" id="btnToast">Toast</button>
          </div>
          <div class="small muted">Resizable + dockable + floating</div>
        </div>

        <div class="workbench__main" id="wbGrid">
          <div class="wbCol wbCol--left">
            <div class="panel">
              <div class="panel__hdr"><div class="panel__title">Files</div></div>
              <div class="panel__body">
                <div class="small muted mono">/src</div>
                <div style="margin-top:8px" class="small">index.html</div>
                <div class="small">app.js</div>
                <div class="small">styles.css</div>
              </div>
            </div>

            <div class="panel">
              <div class="panel__hdr"><div class="panel__title">Project Viewer</div></div>
              <div class="panel__body">Preview area…</div>
            </div>
          </div>

          <div class="splitter splitter--x" id="splitL"></div>

          <div class="wbCol wbCol--center">
            <div class="panel" style="flex:1">
              <div class="tabs">
                <div class="tab is-active">main.js</div>
                <div class="tab">utils.js</div>
              </div>
              <div class="panel__body">
                <textarea style="width:100%;height:420px" class="mono">/* editor */</textarea>
              </div>
            </div>
          </div>

          <div class="splitter splitter--x" id="splitR"></div>

          <div class="wbCol wbCol--right">
            <div class="dockZone" id="dockRight" style="height:100%;"></div>
            <div class="panel" style="margin-top:12px">
              <div class="panel__hdr"><div class="panel__title">Running Console</div></div>
              <div class="panel__body"><pre>logs…</pre></div>
            </div>
          </div>
        </div>

        <div class="workbench__bottom">
          <div class="small muted">Chat/output</div>
          <div class="row" style="margin-top:10px">
            <input placeholder="Ask…" style="flex:1"/>
            <button class="primary">Send</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Floating AI window -->
  <div class="win is-hidden" id="aiWin">
    <div class="win__hdr">
      <div class="win__title">AI Tools</div>
      <div class="win__actions">
        <button class="ghost" id="btnSnapRight">Snap Right</button>
        <button class="ghost" id="btnCloseWin">✕</button>
      </div>
    </div>
    <div class="win__body">
      <div class="small muted">Detachable AI assistant panel.</div>
      <div style="margin-top:10px" class="row">
        <input placeholder="Prompt…" style="flex:1"/>
        <button class="primary">Run</button>
      </div>
    </div>
  </div>

  <script type="module">
    import { makeDraggable, focusWin, snapTo } from "../scripts/ui_windows.js";
    import { bindWorkbenchSplitters } from "../scripts/ui_splitters.js";
    import { dockWin } from "../scripts/ui_docks.js";
    import { toast } from "../scripts/ui_toasts.js";

    const grid = document.querySelector("#wbGrid");
    bindWorkbenchSplitters(grid, document.querySelector("#splitL"), document.querySelector("#splitR"));

    const aiWin = document.querySelector("#aiWin");
    makeDraggable(aiWin, aiWin.querySelector(".win__hdr"));
    aiWin.addEventListener("mousedown", ()=> focusWin(aiWin));

    document.querySelector("#btnOpenAi").addEventListener("click", ()=>{
      aiWin.classList.remove("is-hidden");
      focusWin(aiWin);
    });

    document.querySelector("#btnCloseWin").addEventListener("click", ()=>{
      aiWin.classList.add("is-hidden");
    });

    document.querySelector("#btnSnapRight").addEventListener("click", ()=>{
      snapTo(aiWin, "right");
      focusWin(aiWin);
    });

    document.querySelector("#btnDockAi").addEventListener("click", ()=>{
      dockWin(aiWin, document.querySelector("#dockRight"));
    });

    document.querySelector("#btnToast").addEventListener("click", ()=>{
      toast("Build", "Build finished successfully.");
    });
  </script>
</body>
</html>
HTML

# Zip it (optional)
if command -v zip >/dev/null 2>&1; then
  rm -f ui-base.zip
  zip -r ui-base.zip "$ROOT" >/dev/null
  echo "✅ Created ui-base.zip"
else
  echo "ℹ️ zip not found; folder created at $ROOT/"
fi

echo "✅ Done. Open: ui-base/demo/ide_demo.html"