## 1.139.9 (2026-02-21)
- UI shell: restored header + footer + theme, sticky header build info.
- Voice: added global PTT button and fixed Voice page PTT wiring.
- Chat: full-width layout; Threads moved under Chat (left panel) and legacy Threads top-nav hidden.
- Dashboard: Projects Dashboard → Programmer navigation + modular dashboard sections.
- System Tools: quick navigation across all system pages.
- Settings: restored LAN/WAN/Local profiles + base URL self-heal hints.
- Diagnostics: improved fetch logging + toast links to diagnostics.
- Installer: upgraded to install.sh v5 (fresh/update/patch + backups + env merge).

## 1.134.9 (2026-02-20)
- Chat UI: new sidebar layout (Connected/Recent/Project/Independent) and “New chat” creates a fresh thread.
- Chat UI: added PTT mic button (Web Speech) on chat page.
- tool-gateway: implemented threads read/append/rename/archive/delete/attach; improved threads list to be meta-based.

## 1.131.18a (2026-02-14)
- voice-gateway: Fix `/api/llm/ping` and `/api/llm/test` to use `AGENT_URL` (no hardcoded `agent-runner` hostname).
- voice-gateway: Add `/api/net/selftest` to diagnose container DNS vs host-network reachability.
- voice-gateway: Log resolved `AGENT_URL` and `TOOL_URL` at startup.

## 1.078 (2026-02-12)
- Fix: System checklist uses `/api/system/*` routes to avoid SPA collisions returning HTML.
- Add: Function Map Registry v1 (`/api/function-map`) + per-item probe endpoint.
- UI: System Status shows **Run Test** buttons for mapped items.
- Change: Checklist meta is versionless (no run tags stored in state).
- Fix: `/api/meta` now returns a persistent, versionless `build_id` from `/state/build_meta.json`.


## 1.076 (2026-02-12)
- UI: added shared UI controls (ui_controls.js) for dropdowns/textareas and autosave indicators.
- UI: System Checklist now shows per-row "Saving…/Saved" status.
- voice-gateway: added /settings/effective for UI routing defaults.
- voice-gateway: added /system/meta for non-sensitive host metadata (interfaces, URLs).

## 1.075 (2026-02-12)
- TLS/SSL: expanded HTTPS site list to include LAN + dyndns hostnames; kept auto_https disable_redirects.
- Added persistent state mount (./state -> /state) for voice-gateway.
- voice-gateway: added /settings GET/PUT (persisted) and /system/checklist API (persisted).
- UI: System Checklist now uses the persistent checklist API; removed hardcoded ?v= cache-busters in index.html.

## RUN27 (2026-02-08)
- Fix run tag source: voice-gateway reads RUN_INFO.txt (bundle version) so UI always shows correct run.
- Bundle metadata refreshed.

## RUN24 (2026-02-08)
- SysDiag reliability: `/sysdiag/*` is now served by tool-gateway (no separate sysdiag container build).
- Dashboard footer: always shows `SERA AI — RUNxx` by querying `/api/status` (fallback `/api/config`).
- Caddy: `/sysdiag/*` routes to tool-gateway.

## RUN23 (2026-02-08)
- Added action registry doc (docs/ACTION_REGISTRY.json) to track which UI/voice actions are wired.
- Added logging schema doc (docs/LOGGING_SCHEMA.md).

## RUN22 (2026-02-08)
- Dashboard HTML cleanup (fixed broken DOM causing stray markup on Troubleshoot page).
- New System page + sysdiag service (FastAPI + psutil) for host metrics.
- Caddy routes /sysdiag/* to sysdiag service.
- deploy_bundle.sh now reads RUN_INFO.txt and updates RUN_TAG in .env.

## RUN21 (2026-02-08)
- UI: fixed broken Troubleshoot section markup that leaked raw HTML into the page.
- UI: corrected dashboard routing for Connections and repaired Troubleshoot + Home Assistant button wiring.
- Branding: header/footer now display "SERA AI" and footer shows run tag when available.

## RUN20 (2026-02-08)
- Deploy hardening: `deploy_bundle.sh` now verifies `.sha256` when present (tolerates missing newline).
- Added `scripts/smoke_test.sh` for fast health validation.
- Added `scripts/collect_run_snapshot.sh` to capture logs/health/config (redacted) into `outgoing/`.
- Docs: added authoritative schemas (`DOCS_SCHEMA.md`, `LOGGING_SCHEMA.md`, `DIRECTORY_LAYOUT.md`, `RUN_REVIEW_PROCESS.md`, `ROLLBACK.md`, `LINEAGE.md`, `INSTALL_FROM_SCRATCH.md`).
- Imported external reference docs into `docs/external/`.

## RUN17 (2026-02-06)
- Added Connections page + settings storage endpoints.
- Dynamic footer run tag.

# Changelog

## RUN30 (2026-02-08)
- Added interactive installer wrapper scripts/install.sh (preserve env / generate secrets / fresh install).
- Centered dashboard header/nav via CSS tweaks.
- Added continuity + TODO/IMPLEMENTED docs.

## RUN29 (2026-02-08)
- Added /api/docs endpoints in voice-gateway (docs list + view) and bundled docs into gateway image.
- Fixed deploy script to auto-set RUN_TAG from bundle RUN_INFO / filename.
- Updated standalone UI pages to show dynamic footer branding "SERA AI" + run.


## RUN12 (2026-02-05)
- Fixed UI JavaScript crash (duplicate const threadSelect) that prevented buttons/actions from working.
- Added unified action logging (JSONL) with request_id correlation in voice-gateway.
- Added /api/logs/actions/tail endpoint and Admin UI log viewer.
- Implemented SAFE_MODE toggle (SERA_SAFE_MODE=1) blocking destructive tool-gateway operations by default.
- Adopted new host folder schema: /home/spartan/sera/sera-ai/{incoming,outgoing,backups,logs,tools,workspaces}.

## RUN11 — 2026-02-05
- UI: external JS, fixed syntax error, buttons wired via /api/*
- Gateway: added /api/* aliases + status endpoint
- UI: footer tracking (RUN + service health)
- Docs: system docs + docs viewer
- Tools: rotation script (dry-run default)

## RUN10 — 2026-02-04
- Bundle deploy framework + token-protected tool-gateway endpoints

## RUN13 (2026-02-05)
- Fixed `docker-compose.yml` (removed obsolete `version`, clarified env/volume placement).
- Added voice-gateway compatibility routes: `/status`, `/health`, and `/api/config`.
- Added `tools/sera_crawl.sh` and updated crawl log location to `logs/sera-voice-control/crawl/`.
- Updated deployment docs to the new SERA folder schema (incoming/outgoing/backups/logs/tools/workspaces).
## 1.082
- Fix: disable caching for UI assets via Caddy headers (prevents stale JS/HTML after deploy).
- Add: Sysdiag Last viewer + simple table helper in Troubleshoot page.


## 1.130A (2026-02-13)
- Fix footer meta: /api/meta now returns version; UI footer falls back to baked metadata.
- Regenerate ui/version.js for this bundle build.
- No functional changes to core services.

## 1.132 Bundle 003 (2026-02-14)
- Added TraceContext and SessionContext middleware.
- Added /api/session/create and /api/session/validate endpoints.
- Cleaned .env.example and added session gating env vars.


## 1.131.1 (2026-02-14)
- Added Gateway POST /api/chat (wrapper for agent-runner /ask).
- Updated UI Chat page to ChatGPT-style transcript wired to /api/chat.
- Updated docs/START_HERE.md for rapid bundle track.

## 1.131.2 (2026-02-14) — BUNDLE003
- Chat: confirmation UX (Confirm/Cancel) when agent returns needs_confirm.
- Chat: safe-mode banner (reads /api/config).
- System: action log viewer wired to /api/logs/actions/tail (manual + optional auto refresh).

## 1.131.3 (2026-02-14) — BUNDLE004
- Chat: projects + threads selectors (project registry + thread list/create).
- Chat: /api/chat now persists transcripts to workspace threads (auto-create thread + append user/assistant).
- Tools: threads/list includes thread titles from .meta.json.

## 1.131.4 (2026-02-14) — BUNDLE005
- Added Threads browser page (read-only viewer + export)
- Added /api/threads/export (download thread JSON attachment)

## 1.131.5 (2026-02-14) BUNDLE006
- UI: Workspace file manager (list/upload/download across workspace areas)

## 1.131.6 (2026-02-14) — BUNDLE007
- Add Backups module (UI + API): create/list/download/restore project backups
- Default backup scope: docs, logs, configs, manifests, threads (if present)
- Restore blocked when SAFE MODE is enabled

## 1.131.7 (2026-02-14) — BUNDLE008
- Add backup Inspect endpoint + UI button for restore planning
- Add Project Export Pack: dev-safe tar.gz written to project/outbox for download/share
- Backups UI: add Export Pack panel + download link

## 1.131.7b (2026-02-14)
- Fix tool-gateway SyntaxError in tools/server.py (safe-mode deny call)
- Repack BUNDLE008 with portable sha

## 1.131.8 (2026-02-14) — BUNDLE009
- Backups: add restore Preview (collision detection) endpoint (/backups/preview) and gateway proxy (/api/backups/preview).
- UI: Backups page adds Preview button showing overwrite/new file counts and sample overwrite paths.

## 1.131.9 (2026-02-14) — BUNDLE010
- Sysdiag: route /sysdiag/* through voice-gateway (Caddy now proxies to :3000) so the gateway can inject tool token and return friendly errors if tool-gateway is down.
- Gateway: add /sysdiag/* proxy handler to tool-gateway.

## 1.131.10 (2026-02-14) — BUNDLE011
- Deploy UI: add Health reports viewer (list + load) so install failures can be inspected from the browser.
- Gateway: expose /api/debug/health/list and /api/debug/health/read (read-only) using /debug mount.
- Compose: mount host debug dir to /debug (read-only) for voice-gateway and tool-gateway.

## 1.131.11 (2026-02-14) — BUNDLE012
- UI footer cleanup: Build/Host moved to hover info.
- Settings page: separated Program vs Builder settings shortcuts.
- Troubleshoot page: added test suite run + save-to-file.
- Gateway: added /api/tests/quick and /api/tests/run (optionally saves results to /logs/tests).

## 1.131.12 (2026-02-14) BUNDLE013
- Add OpenAI/LLM config + ping test (server-side)
- Add Voice page with Web Speech fallback (STT/TTS)
- Add Updates page scaffold (list bundles + optional UI deploy switch)

## 1.131.13 (2026-02-14)
- Add SERA logic processor (command parsing to intent contract) per spec.
- Add tool-gateway /logs_tail endpoint.
- Chat UI shows intent/result details.

## 1.131.14 — BUNDLE015 (2026-02-14)

- Agent: LLM mediation with plan→mapped intents, confirmation tokens, and /llm/test endpoint.
- Tool-gateway: added /fs/read (safe roots, 256KiB cap).
- Voice UI: STT auto-send to /api/chat + TTS speak reply.
- Gateway: /api/llm/test proxy to agent-runner.

## 1.131.15 (2026-02-14)
- Fix /api/files/list 500 by using tool-gateway GET /files/list
- Fix Voice UI partial to load /voice_client.js correctly

## 1.131.16 (2026-02-14)
- Fix gateway missing sanitizeRelPath causing /api/files/list 500

## 1.131.17 (2026-02-14)
- BUNDLE018: Fix Voice page buttons and enable browser STT/TTS loop with quick actions.

## 1.135.0 (BUNDLE037) - 2026-02-20
- Chat UI v2: sidebar grouped chats + bottom dock (send/mic/attach stub)
- Remove legacy local-only threaded scaffold from chat page (forces simple mode)
- Sidebar wiring updated (projects_threads.js) to list independent/project/recent chats

