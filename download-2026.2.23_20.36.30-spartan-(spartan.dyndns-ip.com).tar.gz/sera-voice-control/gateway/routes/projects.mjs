// gateway/routes/projects.mjs
import express from "express";

export function mountProjectsRoutes(app, { TOOL_GATEWAY_URL, TOOL_TOKEN }) {
  const r = express.Router();

  async function toolFetch(toolPath, req, res, { method, bodyObj } = {}) {
    try {
      const u = new URL(toolPath, TOOL_GATEWAY_URL);
      // forward query string if desired
      if (req.url.includes("?")) {
        const qs = req.url.split("?")[1];
        if (qs) u.search = qs;
      }

      const headers = {
        "content-type": "application/json",
        "x-tool-token": TOOL_TOKEN || "",
      };

      const init = { method: method || req.method, headers };
      if (init.method !== "GET" && init.method !== "HEAD") {
        init.body = JSON.stringify(bodyObj ?? req.body ?? {});
      }

      const out = await fetch(u.toString(), init);
      const text = await out.text();
      res.status(out.status)
        .type(out.headers.get("content-type") || "application/json")
        .send(text);
    } catch (e) {
      res.status(502).json({ ok: false, error: String(e) });
    }
  }

  // ---- Phase2 UI compatibility ----
  // project_builder.js expects:
  //   GET  /api/projects
  //   POST /api/projects   { name, template }
  r.get("/projects", (req, res) => toolFetch("/projects/list", req, res));

  r.post("/projects", (req, res) => {
    const name = String(req.body?.name || "demo").trim();
    const template = String(req.body?.template || "web-hello").trim();
    // tool-gateway expects /projects/create
    return toolFetch("/projects/create", req, res, {
      method: "POST",
      bodyObj: { name, template },
    });
  });

  // Also support older dashboard calls (you showed these in console):
  //   GET /api/projects/list
  //   POST /api/projects/create
  r.get("/projects/list", (req, res) => toolFetch("/projects/list", req, res));
  r.post("/projects/create", (req, res) => toolFetch("/projects/create", req, res));

  // Optional pass-throughs if you’re using them:
  r.get("/projects/current", (req, res) => toolFetch("/projects/current", req, res));
  r.post("/projects/set_current", (req, res) => toolFetch("/projects/set_current", req, res));

  // Mount under /api with JSON body enabled
  app.use("/api", express.json({ limit: "5mb" }), r);
}