"""Database package for SERA agent.

Bundle 002 baseline: SQLite with simple SQL migrations.
"""
