"""SQLite migration runner.

Applies migrations in lexical order from agent/db/migrations.
Tracks applied migrations in schema_version table.

Safe for repeated execution.
"""

import os
from pathlib import Path
from typing import List

from .connection import db

MIGRATIONS_DIR = Path(__file__).parent / "migrations"


def _ensure_schema_table(conn) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_version (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          filename TEXT NOT NULL UNIQUE,
          applied_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """
    )


def _applied(conn) -> set:
    _ensure_schema_table(conn)
    rows = conn.execute("SELECT filename FROM schema_version ORDER BY id").fetchall()
    return {r["filename"] for r in rows}


def list_migrations() -> List[Path]:
    return sorted([p for p in MIGRATIONS_DIR.glob("*.sql") if p.is_file()])


def apply_all() -> List[str]:
    applied_now: List[str] = []
    with db() as conn:
        already = _applied(conn)
        for mig in list_migrations():
            if mig.name in already:
                continue
            sql = mig.read_text(encoding="utf-8")
            conn.executescript(sql)
            conn.execute("INSERT INTO schema_version(filename) VALUES (?)", (mig.name,))
            applied_now.append(mig.name)
    return applied_now


def current_version() -> str:
    with db() as conn:
        _ensure_schema_table(conn)
        row = conn.execute(
            "SELECT filename FROM schema_version ORDER BY id DESC LIMIT 1"
        ).fetchone()
        return row["filename"] if row else "none"


if __name__ == "__main__":
    applied = apply_all()
    print("Applied:", applied)
    print("Current:", current_version())
