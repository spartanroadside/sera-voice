-- 001_init_chat_runs_artifacts.sql
-- SQLite baseline schema for SERA chat + run tracking.

-- NOTE: schema_version table is created by the migration runner.

CREATE TABLE IF NOT EXISTS sessions (
  session_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen_at TEXT,
  expires_at TEXT,
  meta_json TEXT
);

CREATE TABLE IF NOT EXISTS conversations (
  conversation_id TEXT PRIMARY KEY,
  session_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  title TEXT,
  meta_json TEXT,
  FOREIGN KEY(session_id) REFERENCES sessions(session_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS messages (
  message_id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  role TEXT NOT NULL, -- user|assistant|system|tool
  content TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  trace_id TEXT,
  run_id TEXT,
  meta_json TEXT,
  FOREIGN KEY(conversation_id) REFERENCES conversations(conversation_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_messages_conversation_created
  ON messages(conversation_id, created_at);

CREATE TABLE IF NOT EXISTS runs (
  run_id TEXT PRIMARY KEY,
  session_id TEXT,
  conversation_id TEXT,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT,
  status TEXT NOT NULL DEFAULT 'running',
  trace_id TEXT,
  input_message_id TEXT,
  output_message_id TEXT,
  meta_json TEXT,
  FOREIGN KEY(session_id) REFERENCES sessions(session_id) ON DELETE SET NULL,
  FOREIGN KEY(conversation_id) REFERENCES conversations(conversation_id) ON DELETE SET NULL,
  FOREIGN KEY(input_message_id) REFERENCES messages(message_id) ON DELETE SET NULL,
  FOREIGN KEY(output_message_id) REFERENCES messages(message_id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_runs_session_started
  ON runs(session_id, started_at);

CREATE TABLE IF NOT EXISTS artifacts (
  artifact_id TEXT PRIMARY KEY,
  run_id TEXT,
  type TEXT NOT NULL, -- e.g. json|text|file|image|log
  uri TEXT,           -- pointer or path
  content_text TEXT,  -- optional inline content
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  meta_json TEXT,
  FOREIGN KEY(run_id) REFERENCES runs(run_id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_artifacts_run_created
  ON artifacts(run_id, created_at);

CREATE TABLE IF NOT EXISTS audit_events (
  event_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  actor TEXT,
  action TEXT NOT NULL,
  target TEXT,
  trace_id TEXT,
  run_id TEXT,
  details_json TEXT
);

CREATE INDEX IF NOT EXISTS idx_audit_created
  ON audit_events(created_at);
