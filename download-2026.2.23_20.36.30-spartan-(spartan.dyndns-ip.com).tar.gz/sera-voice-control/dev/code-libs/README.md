# Code Libraries

This folder is reserved for reusable snippets + docs (HTML, PHP, Java, etc.).

Guidelines:
- Keep each library in its own subfolder.
- Include a short README and a minimal working example.
- Prefer GPL-compatible licenses.
