# Development folder (server-side)

This repo is deployed under `/home/spartan/sera/sera-ai/sera-voice-control`.

On the server, we maintain:
- `/home/spartan/sera/sera-ai/sera-ai/dev` — development docs, update notes, snapshots, scratch logs
- `/home/spartan/sera/sera-ai/sera-ai/debug` — active debug logs (installer/deploy tails)

These directories are created by the deploy script.
