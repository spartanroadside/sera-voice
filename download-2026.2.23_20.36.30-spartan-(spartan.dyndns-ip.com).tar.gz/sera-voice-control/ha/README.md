# Home Assistant (optional)

Home Assistant can be run alongside this stack.

## Compose override
Use `docker-compose.ha.yml`:

```bash
cd /path/to/install
sudo docker compose -p <project> -f docker-compose.yml -f docker-compose.ha.yml up -d
```

## Tool Gateway HA endpoints
Set these in `.env`:
- `HOME_ASSISTANT_URL` (example: `http://127.0.0.1:8123`)
- `HOME_ASSISTANT_TOKEN` (create in Home Assistant)

Tool Gateway endpoints:
- `POST /ha_call_service`
- `POST /ha_get_state`
- `GET  /ha_states`
