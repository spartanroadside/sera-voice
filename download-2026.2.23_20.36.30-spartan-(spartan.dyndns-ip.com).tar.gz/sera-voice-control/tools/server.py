from __future__ import annotations
import sqlite3
import urllib.request
import socket

import os
import re
import json
import time
import uuid
import shlex
import hashlib
import tarfile
import base64
import mimetypes
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional, List, Tuple

import requests
from fastapi import FastAPI, Header, HTTPException, UploadFile, File, Query, Body, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel


# ----------------------------
# Paths / config
# ----------------------------
UI_DIR = os.path.join(os.path.dirname(__file__), "..", "ui")

app = FastAPI(title="Tool Gateway")

SECRET = os.environ.get("TOOLGATEWAY_SECRET", "")

HOME_ASSISTANT_URL = os.environ.get("HOME_ASSISTANT_URL", "").rstrip("/")
HOME_ASSISTANT_TOKEN = os.environ.get("HOME_ASSISTANT_TOKEN", "")

WORKSPACE = Path(os.environ.get("WORKSPACE_MOUNT", "/workspace")).resolve()
SHARE_DIR = Path(os.environ.get("SERA_SHARE_DIR", "/share")).resolve()

# Per-project storage lives under WORKSPACE/projects/<project_id>/...
PROJECTS_DIR = (WORKSPACE / "projects").resolve()
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

INCOMING_DIR = Path(os.environ.get("INCOMING_DIR", "/incoming")).resolve()
SERA_INCOMING_DIR = os.environ.get("SERA_INCOMING_DIR", "/incoming")

DEPLOY_SCRIPT_PATH = os.environ.get(
    "DEPLOY_SCRIPT_PATH",
    "/home/spartan/sera/sera-ai/sera-voice-control/scripts/deploy_bundle.sh",
)
DEPLOY_ALLOWED_ROOTS = [
    p.strip()
    for p in os.environ.get("DEPLOY_ALLOWED_ROOTS", "/home/spartan/sera").split(",")
    if p.strip()
]

SERA_SAFE_MODE = os.environ.get("SERA_SAFE_MODE", "1").strip().lower() in ("1", "true", "yes", "on")
ALLOW_ADMIN_ACTIONS = os.environ.get("ALLOW_ADMIN_ACTIONS", "0").strip().lower() in ("1", "true", "yes", "on")
ACTION_LOG_PATH = os.environ.get("ACTION_LOG_PATH", "/logs/actions.jsonl")


# ----------------------------
# Models (define BEFORE endpoints)
# ----------------------------
class ProjectCreateReq(BaseModel):
    # "project" may be omitted by UI; defaults to "default"
    project: str = "default"
    name: str = ""
    template: str = ""


class ThreadCreateReq(BaseModel):
    project: str = "default"
    title: str = ""


class ThreadRefReq(BaseModel):
    project: str = "default"
    thread_id: str


class ThreadAppendReq(BaseModel):
    project: str = "default"
    thread_id: str
    role: str = "user"
    content: str = ""
    ts: Optional[int] = None


class ThreadRenameReq(BaseModel):
    project: str = "default"
    thread_id: str
    title: str


class ThreadArchiveReq(BaseModel):
    project: str = "default"
    thread_id: str
    archived: bool = True


class ThreadDeleteReq(BaseModel):
    project: str = "default"
    thread_id: str


class ThreadAttachReq(BaseModel):
    # Move a thread between projects. to_project="" or None means "default".
    project: str = "default"  # current project
    thread_id: str
    to_project: Optional[str] = None


class ThreadUploadB64Req(BaseModel):
    project: str = "default"
    thread_id: str
    filename: str
    b64: str
    mime: Optional[str] = None


# ----------------------------
# UI-required capability map
# ----------------------------
@app.get("/function-map")
def function_map(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    return {
        "ok": True,
        "service": "tool-gateway",
        "functions": {
            "projects_list": True,
            "projects_create": True,
            "projects_tree": True,
            "projects_threads": True,
            "threads_list": True,
            "threads_create": True,
        },
    }


# ----------------------------
# Compatibility endpoints (UI calls these)
# ----------------------------
@app.get("/projects")
def projects_list_compat(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    # UI expects GET /projects
    return projects_list(x_tool_token=x_tool_token)


@app.post("/projects")
def projects_create_compat(
    req: ProjectCreateReq = Body(...),  # IMPORTANT: body, not query
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    # UI expects POST /projects
    return projects_create(req=req, x_tool_token=x_tool_token)


@app.post("/threads/create")
def threads_create(
    req: ThreadCreateReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)

    pid = _safe_project_id(req.project or "default")
    pr = _project_root(pid)
    threads_dir = pr / "threads"
    threads_dir.mkdir(parents=True, exist_ok=True)

    ts = int(time.time())
    base = f"t_{ts}"
    meta_path = threads_dir / f"{base}.meta.json"
    data_path = threads_dir / f"{base}.jsonl"

    meta = {
        "id": base,
        "project": pid,
        "title": (req.title or "").strip() or base,
        "created_at": ts,
        "updated_at": ts,
        "format": "jsonl",
    }

    if not meta_path.exists():
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    if not data_path.exists():
        data_path.write_text("", encoding="utf-8")

    return {"ok": True, "project": pid, "thread_id": base, "meta": meta}
# ----------------------------
# Version helpers
# ----------------------------
def _read_version() -> str:
    v = os.environ.get("SERA_VERSION") or os.environ.get("RUN_TAG") or ""
    if v:
        return v
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.abspath(os.path.join(here, ".."))
        vp = os.path.join(root, "VERSION")
        if os.path.isfile(vp):
            return open(vp, "r", encoding="utf-8", errors="ignore").read().strip()
    except Exception:
        pass
    return "unknown"


# ----------------------------
# Auth / logging
# ----------------------------
def _append_action_log(evt: Dict[str, Any]) -> None:
    try:
        Path(ACTION_LOG_PATH).parent.mkdir(parents=True, exist_ok=True)
        with open(ACTION_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(evt, ensure_ascii=False) + "\n")
    except Exception:
        pass


@app.middleware("http")
async def _log_requests(request: Request, call_next):
    rid = request.headers.get("X-Request-Id") or str(uuid.uuid4())
    start = time.time()
    response = await call_next(request)
    dur_ms = int((time.time() - start) * 1000)

    path = str(request.url.path)
    if path.startswith("/"):
        _append_action_log(
            {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "request_id": rid,
                "service": "tool-gateway",
                "method": request.method,
                "path": path,
                "status": response.status_code,
                "dur_ms": dur_ms,
            }
        )
    response.headers["X-Request-Id"] = rid
    return response


def _auth(token: Optional[str]) -> None:
    if not SECRET:
        raise HTTPException(status_code=500, detail="TOOLGATEWAY_SECRET not set")
    if not token or token != SECRET:
        raise HTTPException(status_code=401, detail="Invalid tool token")


def _deny_if_safe_mode(op: str) -> None:
    if SERA_SAFE_MODE:
        raise HTTPException(status_code=403, detail=f"SAFE_MODE enabled: {op} blocked")


def _deny_if_admin_actions_disabled(action: str) -> None:
    if not ALLOW_ADMIN_ACTIONS:
        raise HTTPException(
            status_code=403,
            detail=f"Admin actions disabled for: {action}. Set ALLOW_ADMIN_ACTIONS=1 to enable.",
        )


# ----------------------------
# Safe path helpers (workspace + projects)
# ----------------------------
_PROJECT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


def _project_root(project_id: str) -> Path:
    pid = (project_id or "").strip()
    if not _PROJECT_ID_RE.match(pid):
        raise HTTPException(status_code=400, detail="Invalid project id")
    root = (PROJECTS_DIR / pid).resolve()
    if PROJECTS_DIR not in root.parents and root != PROJECTS_DIR:
        raise HTTPException(status_code=400, detail="Project path escapes projects dir")
    # Ensure standard per-project dirs
    for d in ("uploads", "quarantine", "tmp", "outbox", "backups", "threads", "imports", "repo", "reports", "manifests"):
        try:
            (root / d).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def _safe_project_path(project_id: str, rel_path: str) -> Path:
    root = _project_root(project_id)
    p = (root / rel_path).resolve()
    if root not in p.parents and p != root:
        raise HTTPException(status_code=400, detail="Path escapes project")
    return p


def _safe_path(rel_path: str) -> Path:
    p = (WORKSPACE / rel_path).resolve()
    if WORKSPACE not in p.parents and p != WORKSPACE:
        raise HTTPException(status_code=400, detail="Path escapes workspace")
    return p


def _safe_share_path(rel: str) -> Path:
    p = (SHARE_DIR / rel).resolve()
    if p == SHARE_DIR or SHARE_DIR in p.parents:
        return p
    raise HTTPException(status_code=400, detail="Invalid share path")


# Ensure standard dirs exist in WORKSPACE too
for d in ("uploads", "quarantine", "tmp", "outbox", "backups"):
    try:
        (WORKSPACE / d).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


# ----------------------------
# Host command runner (nsenter)
# ----------------------------
def _run_host_cmd(cmd: str, timeout: int = 60) -> str:
    full = ["nsenter", "-t", "1", "-m", "-u", "-i", "-n", "-p", "--"] + shlex.split(cmd)
    try:
        p = subprocess.run(full, capture_output=True, text=True, timeout=timeout)
        out = (p.stdout or "") + (p.stderr or "")
        return f"exit={p.returncode}\n{out}"
    except subprocess.TimeoutExpired:
        return "exit=124\nTimed out"


_DEFAULT_ALLOWED_RUN_PATTERNS = [
    r"^(whoami|uname -a|uptime|df -h|free -m)$",
    r"^(ip a|ip addr|ip route|ss -tulpn|netstat -tulpn)$",
    r"^docker ps$",
    r"^docker compose ps$",
    r"^docker logs --tail=\d+ [A-Za-z0-9_.-]+$",
    r"^systemctl (is-active|status|restart) [A-Za-z0-9@_.-]+( --no-pager)?$",
    r"^apt-get update$",
]


def _allowed_run(cmd: str) -> bool:
    cmd = cmd.strip()
    extra = os.environ.get("ALLOW_RUN_REGEX", "").strip()
    patterns = list(_DEFAULT_ALLOWED_RUN_PATTERNS)
    if extra:
        patterns.extend([p for p in extra.split(";") if p.strip()])
    for pat in patterns:
        try:
            if re.match(pat, cmd):
                return True
        except re.error:
            continue
    return False


# ----------------------------
# Models
# ----------------------------
class ServiceReq(BaseModel):
    name: str


class LogsTailReq(BaseModel):
    service: str
    n: int = 200


class CmdReq(BaseModel):
    cmd: str
    timeout: int = 120


class FileReadReq(BaseModel):
    path: str


class FileWriteReq(BaseModel):
    path: str
    content: str
    create: bool = True


class PatchReq(BaseModel):
    path: str
    find: str
    replace: str
    count: int = 1


# ----------------------------
# Health/basic (public)
# ----------------------------
@app.get("/health")
def health():
    return {"ok": True}


@app.get("/version")
def version():
    return {"ok": True, "version": _read_version()}


@app.get("/status")
def status():
    return {
        "ok": True,
        "version": _read_version(),
        "safe_mode": SERA_SAFE_MODE,
        "allow_admin_actions": ALLOW_ADMIN_ACTIONS,
    }


# ----------------------------
# UI compatibility (public-ish safe reads)
# These are called by UI through Caddy; keep them read-only.
# ----------------------------
@app.get("/config")
def ui_config():
    return {
        "ok": True,
        "version": _read_version(),
        "safe_mode": bool(SERA_SAFE_MODE),
        "allow_admin_actions": bool(ALLOW_ADMIN_ACTIONS),
        "workspace": str(WORKSPACE),
        "projects_dir": str(PROJECTS_DIR),
    }


@app.get("/meta")
def ui_meta():
    return {
        "ok": True,
        "name": "tool-gateway",
        "version": _read_version(),
        "safe_mode": bool(SERA_SAFE_MODE),
        "allow_admin_actions": bool(ALLOW_ADMIN_ACTIONS),
        "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


@app.get("/system/checklist")
def system_checklist():
    items = [
        {"id": "tool_gateway_up", "label": "Tool Gateway reachable", "ok": True},
        {"id": "safe_mode", "label": "SAFE_MODE", "ok": not bool(SERA_SAFE_MODE), "value": int(bool(SERA_SAFE_MODE))},
        {"id": "admin_actions", "label": "ALLOW_ADMIN_ACTIONS", "ok": bool(ALLOW_ADMIN_ACTIONS), "value": int(bool(ALLOW_ADMIN_ACTIONS))},
    ]
    return {"ok": True, "items": items}


@app.get("/tests/quick")
def tests_quick():
    return {
        "ok": True,
        "tests": [
            {"id": "health", "ok": True},
            {"id": "version", "ok": _read_version() != "unknown", "value": _read_version()},
        ],
    }


# Some UI builds POST to this endpoint; accept POST as an alias.
@app.post("/tests/quick")
def tests_quick_post():
    return tests_quick()


@app.get("/profiles")
def profiles():
    # stub for UI; can be extended later
    return {"ok": True, "profiles": []}


# ----------------------------
# Sysdiag (public read-only)
# UI calls /sysdiag/system.json (no token header), so DO NOT require token here.
# ----------------------------
def _sysinfo_basic() -> Dict[str, Any]:
    return {
        "ok": True,
        "version": _read_version(),
        "safe_mode": bool(SERA_SAFE_MODE),
        "allow_admin_actions": bool(ALLOW_ADMIN_ACTIONS),
        "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "workspace": str(WORKSPACE),
        "projects_dir": str(PROJECTS_DIR),
        "incoming_dir": str(INCOMING_DIR),
    }


@app.get("/sysdiag/system.json")
def sysdiag_system_json():
    return _sysinfo_basic()


@app.get("/sysdiag/last")
def sysdiag_last():
    return {"ok": True, "last": _sysinfo_basic()}


# ----------------------------
# Bundles listing (tokened)
# ----------------------------
@app.get("/bundles/list")
def bundles_list(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    bundles = []
    try:
        base = INCOMING_DIR if INCOMING_DIR.exists() else Path(SERA_INCOMING_DIR).resolve()
        if base.exists():
            for pth in sorted(base.glob("*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True):
                st = pth.stat()
                bundles.append({"name": pth.name, "path": str(pth), "bytes": st.st_size, "mtime": int(st.st_mtime)})
    except Exception:
        pass
    return {"ok": True, "incoming_dir": str(INCOMING_DIR), "bundles": bundles}


# ----------------------------
# Host service / command control (tokened)
# ----------------------------
@app.post("/status_service")
def status_service(req: ServiceReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    return {"ok": True, "output": _run_host_cmd(f"systemctl is-active {shlex.quote(req.name)} || true")}


@app.post("/restart_service")
def restart_service(req: ServiceReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    return {"ok": True, "output": _run_host_cmd(f"systemctl restart {shlex.quote(req.name)}")}


@app.post("/logs_tail")
def logs_tail(req: LogsTailReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    svc = (req.service or "").strip()
    n = max(1, min(int(req.n or 200), 2000))
    if not svc or len(svc) > 128:
        return {"ok": False, "error": "Bad service name"}
    cmd = f"docker logs --tail {n} {shlex.quote(svc)}"
    out = _run_host_cmd(cmd)
    return {"ok": True, "output": out}


@app.post("/run")
def run_cmd(req: CmdReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    _deny_if_safe_mode("run")
    _deny_if_admin_actions_disabled("run")
    if not _allowed_run(req.cmd):
        raise HTTPException(status_code=403, detail="Command not allow-listed")
    return {"ok": True, "output": _run_host_cmd(req.cmd, timeout=req.timeout)}


# ----------------------------
# Workspace file ops (tokened)
# ----------------------------
@app.post("/read_file")
def read_file(req: FileReadReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    p = _safe_path(req.path)
    if not p.exists():
        raise HTTPException(status_code=404, detail="Not found")
    if p.is_dir():
        raise HTTPException(status_code=400, detail="Is a directory")
    return {"ok": True, "path": str(p), "content": p.read_text(errors="replace")}


@app.post("/write_file")
def write_file(req: FileWriteReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    _deny_if_safe_mode("write_file")
    p = _safe_path(req.path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists() and p.is_dir():
        raise HTTPException(status_code=400, detail="Is a directory")
    if (not p.exists()) and (not req.create):
        raise HTTPException(status_code=400, detail="Refusing to create new file")
    p.write_text(req.content, encoding="utf-8", errors="replace")
    return {"ok": True, "path": str(p), "bytes": len(req.content.encode("utf-8"))}


@app.post("/apply_patch")
def apply_patch(req: PatchReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    _deny_if_safe_mode("apply_patch")
    p = _safe_path(req.path)
    if not p.exists():
        raise HTTPException(status_code=404, detail="Not found")
    txt = p.read_text(errors="replace")
    if req.find not in txt:
        raise HTTPException(status_code=400, detail="Pattern not found")
    new = txt.replace(req.find, req.replace, req.count)
    p.write_text(new, encoding="utf-8", errors="replace")
    return {"ok": True, "path": str(p), "replaced": min(req.count, txt.count(req.find))}


@app.get("/list_files")
def list_files(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    items = []
    for p in WORKSPACE.rglob("*"):
        if p.is_file():
            items.append(str(p.relative_to(WORKSPACE)))
    items.sort()
    return {"ok": True, "count": len(items), "files": items[:2000]}


# ----------------------------
# Projects registry (simple) (tokened)
# ----------------------------
PROJECTS_REGISTRY = PROJECTS_DIR / "registry.json"
CURRENT_PROJECT = PROJECTS_DIR / "current.json"


def _load_registry() -> Dict[str, Any]:
    if not PROJECTS_REGISTRY.exists():
        return {"projects": []}
    try:
        data = json.loads(PROJECTS_REGISTRY.read_text(errors="replace") or "{}")
        if not isinstance(data, dict):
            return {"projects": []}
        if not isinstance(data.get("projects"), list):
            data["projects"] = []
        return data
    except Exception:
        return {"projects": []}


def _save_registry(data: Dict[str, Any]) -> None:
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    PROJECTS_REGISTRY.write_text(json.dumps(data, indent=2), encoding="utf-8")


class ProjectCreateReq(BaseModel):
    # "project" may be omitted by UI; defaults to "default"
    project: str = "default"
    name: str = ""
    template: str = ""


class ProjectSetReq(BaseModel):
    project: str


@app.get("/projects/list")
def projects_list(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    data = _load_registry()
    # ensure dirs exist
    for p in data.get("projects", []):
        try:
            _project_root(p.get("id") or p.get("project") or "")
        except Exception:
            pass
    return {"ok": True, **data}



# ----------------------------
# Settings (UI-required) (tokened)
# ----------------------------
class SettingsUpdateReq(BaseModel):
    theme: Optional[str] = None           # "dark" | "light"
    net_scope: Optional[str] = None       # "lan" | "wan" | "local"
    lan_host: Optional[str] = None
    wan_host: Optional[str] = None
    local_host: Optional[str] = None
    extra: Dict[str, Any] = {}

def _settings_path() -> Path:
    cfg = os.environ.get("CONFIG_DIR", "/config")
    return (Path(cfg).resolve() / "settings.json")

def _load_settings() -> Dict[str, Any]:
    p = _settings_path()
    defaults = {
        "theme": "dark",
        "net_scope": "lan",
        "lan_host": "sera.lan",
        "wan_host": "spartan.dyndns-ip.com",
        "local_host": "127.0.0.1",
    }
    try:
        if p.exists():
            j = json.loads(p.read_text(encoding="utf-8", errors="replace") or "{}")
            if isinstance(j, dict):
                defaults.update(j)
    except Exception:
        pass
    return defaults

def _save_settings(s: Dict[str, Any]) -> None:
    p = _settings_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(s, indent=2, ensure_ascii=False), encoding="utf-8")

@app.get("/settings")
def settings_get(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    return {"ok": True, "settings": _load_settings()}

@app.post("/settings")
def settings_update(
    req: SettingsUpdateReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    cur = _load_settings()
    for k in ("theme","net_scope","lan_host","wan_host","local_host"):
        v = getattr(req, k, None)
        if v is not None and str(v).strip() != "":
            cur[k] = v
    if isinstance(req.extra, dict) and req.extra:
        cur.update(req.extra)
    _save_settings(cur)
    return {"ok": True, "settings": cur}


@app.put("/settings")
def settings_update_put(
    req: Dict[str, Any] = Body(default={}),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    return settings_update(req=req, x_tool_token=x_tool_token)

@app.post("/projects/create")
def projects_create(req: ProjectCreateReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    raw_pid = (req.project or "").strip()
    if raw_pid in ("", "default"):
        raw_pid = (req.name or "").strip() or "default"
    pid = _safe_project_id(raw_pid)
    root = _project_root(pid)
    reg = _load_registry()
    existing = [p for p in reg.get("projects", []) if (p.get("id") == pid or p.get("project") == pid)]
    if not existing:
        reg["projects"].append({"id": pid, "name": (req.name or pid), "root": str(root)})
        _save_registry(reg)
    return {"ok": True, "created": pid, "root": str(root), "registry": reg}


@app.get("/projects/current")
def projects_current(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    if not CURRENT_PROJECT.exists():
        return {"ok": True, "project": None}
    try:
        j = json.loads(CURRENT_PROJECT.read_text(errors="replace") or "{}")
        return {"ok": True, "project": j.get("project")}
    except Exception:
        return {"ok": True, "project": None}


@app.post("/projects/set_current")
def projects_set_current(req: ProjectSetReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    pid = req.project.strip()
    _project_root(pid)
    CURRENT_PROJECT.write_text(json.dumps({"project": pid}, indent=2), encoding="utf-8")
    return {"ok": True, "project": pid}


# ----------------------------
# Legacy-style files API (used by UI) (tokened)
# ----------------------------
def _safe_project_id(pid: str) -> str:
    pid = (pid or "").strip() or "default"
    out = []
    for ch in pid:
        if ch.isalnum() or ch in "-_":
            out.append(ch)
    return "".join(out)[:64] or "default"


def _area_dir(project: str, area: str) -> Path:
    area = (area or "").strip().lower()
    root = _project_root(project)
    if area in ("outbox", "uploads", "quarantine", "threads", "backups", "repo"):
        return (root / area).resolve()
    raise HTTPException(status_code=400, detail="Unknown area")

# ----------------------------
# Threads + Project Tree (UI-required)
# ----------------------------

_TREE_SCOPES = {
    "repo": "repo",
    "active": "active",
    "dev": "dev",
    "ai": "ai",
    "staging": "staging",
    "uploads": "uploads",
    "quarantine": "quarantine",
    "outbox": "outbox",
    "threads": "threads",
    "backups": "backups",
    "imports": "imports",
    "reports": "reports",
    "manifests": "manifests",
}

def _norm_ui_path(p: str) -> str:
    # UI sends path like "/" or "%2F" or "/some/dir"
    p = (p or "").strip()
    if p in ("", "/"):
        return ""
    return p.lstrip("/")

def _safe_depth(depth: int) -> int:
    try:
        d = int(depth)
    except Exception:
        d = 2
    return max(1, min(d, 12))

def _list_dir_tree(base: Path, rel: str, depth: int) -> Dict[str, Any]:
    """
    Returns a tree object:
      { name, path, type, children:[...] }
    where path is slash-prefixed like "/sub/dir".
    """
    base = base.resolve()
    target = (base / rel).resolve()
    if base not in target.parents and target != base:
        raise HTTPException(status_code=400, detail="Path escapes scope root")
    if not target.exists():
        # UI expects empty-ish tree not a hard crash
        return {"name": "/", "path": "/", "type": "dir", "children": []}
    if not target.is_dir():
        raise HTTPException(status_code=400, detail="Path is not a directory")

    def node_for(path_obj: Path, root: Path) -> Dict[str, Any]:
        relp = str(path_obj.relative_to(root)).replace("\\", "/")
        ui_path = "/" + relp if relp else "/"
        return {
            "name": path_obj.name if relp else "/",
            "path": ui_path,
            "type": "dir" if path_obj.is_dir() else "file",
        }

    root_node = node_for(target, base)

    def walk(dirpath: Path, root: Path, dleft: int) -> List[Dict[str, Any]]:
        if dleft <= 0:
            return []
        kids: List[Dict[str, Any]] = []
        try:
            entries = sorted(dirpath.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        except Exception:
            return []
        for e in entries:
            # Skip very noisy / unsafe things if they exist
            if e.name in (".git", "__pycache__"):
                continue
            n = node_for(e, root)
            if e.is_dir():
                n["children"] = walk(e, root, dleft - 1)
            else:
                try:
                    st = e.stat()
                    n["size"] = int(st.st_size)
                    n["mtime"] = int(st.st_mtime)
                except Exception:
                    pass
            kids.append(n)
        return kids

    root_node["children"] = walk(target, base, depth)
    return root_node


@app.get("/projects/{project_id}/tree")
def project_tree(
    project_id: str,
    scope: str = Query("repo"),
    path: str = Query("/"),
    depth: int = Query(4),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pr = _project_root(project_id)

    sc = (scope or "repo").strip().lower()
    if sc not in _TREE_SCOPES:
        raise HTTPException(status_code=400, detail=f"Unknown scope: {scope}")

    base = (pr / _TREE_SCOPES[sc]).resolve()
    base.mkdir(parents=True, exist_ok=True)

    rel = _norm_ui_path(path)
    d = _safe_depth(depth)

    tree = _list_dir_tree(base, rel, d)
    return {"ok": True, "project": project_id, "scope": sc, "root": str(base), "tree": tree}


@app.get("/projects/scopes")
def projects_scopes(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    scopes = []
    # expose known scopes; UI can decide which to show
    for k in _TREE_SCOPES.keys():
        scopes.append({"id": k, "label": k, "readOnly": False})
    return {"ok": True, "scopes": scopes}


def _scope_base(pr: Path, scope: str) -> Path:
    sc = (scope or "repo").strip().lower()
    if sc not in _TREE_SCOPES:
        raise HTTPException(status_code=400, detail=f"Unknown scope: {scope}")
    base = (pr / _TREE_SCOPES[sc]).resolve()
    base.mkdir(parents=True, exist_ok=True)
    return base


@app.get("/projects/{project_id}/tar/list")
def tar_list(
    project_id: str,
    scope: str = Query("repo"),
    path: str = Query(""),
    limit: int = Query(500),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pr = _project_root(project_id)
    base = _scope_base(pr, scope)
    rel = _norm_ui_path(path)
    tar_path = (base / rel).resolve()
    if base.resolve() not in tar_path.parents and tar_path != base.resolve():
        raise HTTPException(400, "Invalid path")
    if not tar_path.exists() or not tar_path.is_file():
        raise HTTPException(404, "Tar not found")
    try:
        limit = max(1, min(int(limit), 5000))
    except Exception:
        limit = 500

    items = []
    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf.getmembers():
            if len(items) >= limit:
                break
            name = _tar_safe_rel(m.name)
            items.append({"name": name, "type": "dir" if m.isdir() else ("file" if m.isfile() else "other"), "size": int(m.size or 0)})
    return {"ok": True, "project": project_id, "scope": scope, "path": rel, "items": items, "truncated": len(items) >= limit}


@app.get("/projects/{project_id}/tar/file")
def tar_file(
    project_id: str,
    scope: str = Query("repo"),
    tar_path: str = Query(""),
    inner_path: str = Query(""),
    max_bytes: int = Query(200000),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pr = _project_root(project_id)
    base = _scope_base(pr, scope)
    rel_tar = _norm_ui_path(tar_path)
    tp = (base / rel_tar).resolve()
    if base.resolve() not in tp.parents and tp != base.resolve():
        raise HTTPException(400, "Invalid tar_path")
    if not tp.exists() or not tp.is_file():
        raise HTTPException(404, "Tar not found")
    inner = _tar_safe_rel(inner_path)
    try:
        max_bytes = max(1024, min(int(max_bytes), 2_000_000))
    except Exception:
        max_bytes = 200000

    with tarfile.open(tp, "r:*") as tf:
        m = tf.getmember(inner)
        if not m.isfile():
            raise HTTPException(400, "Not a file")
        f = tf.extractfile(m)
        if f is None:
            raise HTTPException(404, "Not found")
        data = f.read(max_bytes + 1)
    truncated = len(data) > max_bytes
    if truncated:
        data = data[:max_bytes]
    # try decode as utf-8, fallback latin-1
    try:
        text = data.decode("utf-8")
    except Exception:
        text = data.decode("latin-1", errors="replace")
    return {"ok": True, "project": project_id, "scope": scope, "tar_path": rel_tar, "inner_path": inner, "text": text, "truncated": truncated}


class TarExtractReq(BaseModel):
    scope: str = "repo"
    path: str
    dest_scope: str = "imports"
    dest_path: str = ""


@app.post("/projects/{project_id}/tar/extract")
def tar_extract(
    project_id: str,
    req: TarExtractReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _deny_if_safe_mode("tar_extract")
    pr = _project_root(project_id)
    src_base = _scope_base(pr, req.scope)
    dst_base = _scope_base(pr, req.dest_scope)

    rel_tar = _norm_ui_path(req.path)
    tp = (src_base / rel_tar).resolve()
    if src_base.resolve() not in tp.parents and tp != src_base.resolve():
        raise HTTPException(400, "Invalid path")
    if not tp.exists() or not tp.is_file():
        raise HTTPException(404, "Tar not found")

    dest_rel = _norm_ui_path(req.dest_path or "")
    dest_root = (dst_base / dest_rel).resolve()
    if dst_base.resolve() not in dest_root.parents and dest_root != dst_base.resolve():
        raise HTTPException(400, "Invalid dest_path")
    dest_root.mkdir(parents=True, exist_ok=True)

    extracted = 0
    with tarfile.open(tp, "r:*") as tf:
        for m in tf.getmembers():
            if m.isdev() or m.ischr() or m.isblk() or m.isfifo() or m.issym() or m.islnk():
                raise HTTPException(400, f"Blocked tar member: {m.name}")
            rel = _tar_safe_rel(m.name)
            outp = (dest_root / rel).resolve()
            if dest_root.resolve() not in outp.parents and outp != dest_root.resolve():
                raise HTTPException(400, "Extraction escaped destination")
            if m.isdir():
                outp.mkdir(parents=True, exist_ok=True)
                continue
            if m.isfile():
                outp.parent.mkdir(parents=True, exist_ok=True)
                f = tf.extractfile(m)
                if f is None:
                    continue
                outp.write_bytes(f.read())
                extracted += 1
                if extracted > 50000:
                    raise HTTPException(400, "Too many files")
    return {"ok": True, "project": project_id, "extracted": extracted, "dest_scope": req.dest_scope, "dest_path": dest_rel}


# ----------------------------
# Project scope status (hashes for sync lights)
# ----------------------------
def _hash_scope(base: Path, max_files: int = 5000) -> Dict[str, Any]:
    h = hashlib.sha256()
    files = 0
    bytes_total = 0
    try:
        for p in sorted(base.rglob("*")):
            if p.is_dir():
                continue
            if p.name in (".DS_Store",):
                continue
            try:
                st = p.stat()
            except Exception:
                continue
            rel = str(p.relative_to(base)).replace("\\", "/")
            files += 1
            bytes_total += int(st.st_size)
            h.update(rel.encode("utf-8", errors="ignore"))
            h.update(b"\0")
            h.update(str(int(st.st_size)).encode())
            h.update(b"\0")
            h.update(str(int(st.st_mtime)).encode())
            h.update(b"\n")
            if files >= max_files:
                break
    except Exception:
        pass
    return {"hash": h.hexdigest(), "files": files, "bytes": bytes_total, "truncated": files >= max_files}



# ----------------------------
# File read/write + basic ops
# ----------------------------

_SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"(?i)openai_api_key\s*[:=]\s*['\"]?[A-Za-z0-9\-_]{10,}"),
    re.compile(r"(?i)home_assistant_token\s*[:=]\s*['\"]?[A-Za-z0-9\-_]{10,}"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9\-_.]{20,}"),
]

def _detect_secrets(s: str) -> bool:
    for rx in _SECRET_PATTERNS:
        try:
            if rx.search(s):
                return True
        except Exception:
            continue
    return False

def _safe_rel_path(p: str) -> str:
    p = (p or "").replace("\\", "/").strip()
    p = p.lstrip("/")
    if not p:
        raise HTTPException(status_code=400, detail="path required")
    parts = [seg for seg in p.split("/") if seg]
    for seg in parts:
        if seg in (".", "..") or ".." in seg:
            raise HTTPException(status_code=400, detail="invalid path")
    return "/".join(parts)

@app.get("/projects/{project_id}/file")
def project_file_get(
    project_id: str,
    scope: str = Query("repo"),
    path: str = Query(""),
    mode: str = Query("preview"),
    max_bytes: int = Query(200000),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pr = _project_root(project_id)
    base = _scope_base(pr, scope)
    rel = _safe_rel_path(path)
    fp = (base / rel).resolve()
    if base.resolve() not in fp.parents:
        raise HTTPException(status_code=400, detail="Path escapes scope root")
    if not fp.exists() or not fp.is_file():
        raise HTTPException(status_code=404, detail="File not found")

    try:
        max_bytes_i = max(1024, min(int(max_bytes), 2_000_000))
    except Exception:
        max_bytes_i = 200000

    raw = fp.read_bytes()
    # crude binary detection
    if b"\x00" in raw[:4096]:
        return {"ok": True, "project": project_id, "scope": scope, "path": rel, "binary": True, "content": ""}

    if mode == "preview" and len(raw) > max_bytes_i:
        raw = raw[:max_bytes_i]

    try:
        content = raw.decode("utf-8", errors="replace")
    except Exception:
        content = raw.decode("latin-1", errors="replace")

    if _detect_secrets(content):
        return {"ok": True, "project": project_id, "scope": scope, "path": rel, "redacted": True, "reason": "secret_pattern"}

    return {"ok": True, "project": project_id, "scope": scope, "path": rel, "content": content, "truncated": mode == "preview" and fp.stat().st_size > len(raw)}

@app.post("/projects/{project_id}/write")
def project_file_write(
    project_id: str,
    payload: Dict[str, Any] = Body(default_factory=dict),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    if SERA_SAFE_MODE and not ALLOW_ADMIN_ACTIONS:
        raise HTTPException(status_code=403, detail="SAFE_MODE enabled; writes blocked")
    pr = _project_root(project_id)
    scope = (payload.get("scope") or "repo")
    path_in = payload.get("path") or ""
    content = payload.get("content") or ""
    mode = (payload.get("mode") or "overwrite").lower()

    base = _scope_base(pr, scope)
    rel = _safe_rel_path(str(path_in))
    fp = (base / rel).resolve()
    if base.resolve() not in fp.parents:
        raise HTTPException(status_code=400, detail="Path escapes scope root")
    fp.parent.mkdir(parents=True, exist_ok=True)

    if mode not in ("overwrite", "append"):
        mode = "overwrite"
    data = str(content)
    if _detect_secrets(data):
        raise HTTPException(status_code=400, detail="Refusing to write content containing secret-like patterns")
    if mode == "append" and fp.exists():
        fp.write_text(fp.read_text(encoding="utf-8", errors="ignore") + data, encoding="utf-8")
    else:
        fp.write_text(data, encoding="utf-8")
    return {"ok": True, "project": project_id, "scope": scope, "path": rel}

@app.post("/projects/{project_id}/mkdir")
def project_mkdir(
    project_id: str,
    payload: Dict[str, Any] = Body(default_factory=dict),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    if SERA_SAFE_MODE and not ALLOW_ADMIN_ACTIONS:
        raise HTTPException(status_code=403, detail="SAFE_MODE enabled; mkdir blocked")
    pr = _project_root(project_id)
    scope = (payload.get("scope") or "repo")
    rel = _safe_rel_path(str(payload.get("path") or ""))
    base = _scope_base(pr, scope)
    dp = (base / rel).resolve()
    if base.resolve() not in dp.parents:
        raise HTTPException(status_code=400, detail="Path escapes scope root")
    dp.mkdir(parents=True, exist_ok=True)
    return {"ok": True, "project": project_id, "scope": scope, "path": rel}

@app.post("/projects/{project_id}/rename")
def project_rename(
    project_id: str,
    payload: Dict[str, Any] = Body(default_factory=dict),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    if SERA_SAFE_MODE and not ALLOW_ADMIN_ACTIONS:
        raise HTTPException(status_code=403, detail="SAFE_MODE enabled; rename blocked")
    pr = _project_root(project_id)
    scope = (payload.get("scope") or "repo")
    src = _safe_rel_path(str(payload.get("from") or ""))
    dst = _safe_rel_path(str(payload.get("to") or ""))
    base = _scope_base(pr, scope)
    sp = (base / src).resolve()
    dp = (base / dst).resolve()
    if base.resolve() not in sp.parents or base.resolve() not in dp.parents:
        raise HTTPException(status_code=400, detail="Path escapes scope root")
    dp.parent.mkdir(parents=True, exist_ok=True)
    sp.rename(dp)
    return {"ok": True, "project": project_id, "scope": scope, "from": src, "to": dst}

@app.post("/projects/{project_id}/delete")
def project_delete_path(
    project_id: str,
    payload: Dict[str, Any] = Body(default_factory=dict),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    if SERA_SAFE_MODE and not ALLOW_ADMIN_ACTIONS:
        raise HTTPException(status_code=403, detail="SAFE_MODE enabled; delete blocked")
    pr = _project_root(project_id)
    scope = (payload.get("scope") or "repo")
    rel = _safe_rel_path(str(payload.get("path") or ""))
    base = _scope_base(pr, scope)
    tp = (base / rel).resolve()
    if base.resolve() not in tp.parents:
        raise HTTPException(status_code=400, detail="Path escapes scope root")
    if tp.is_dir():
        # guarded recursive delete
        for child in sorted(tp.rglob("*"), reverse=True):
            try:
                if child.is_file() or child.is_symlink():
                    child.unlink()
                elif child.is_dir():
                    child.rmdir()
            except Exception:
                pass
        try:
            tp.rmdir()
        except Exception:
            pass
    else:
        try:
            tp.unlink()
        except Exception:
            pass
    return {"ok": True, "project": project_id, "scope": scope, "path": rel}

@app.get("/projects/{project_id}/status")
def project_status(
    project_id: str,
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pr = _project_root(project_id)
    scopes = {}
    for sc in ("repo", "dev", "active", "ai"):
        try:
            base = _scope_base(pr, sc)
            scopes[sc] = _hash_scope(base)
        except Exception as e:
            scopes[sc] = {"error": str(e)}
    return {"ok": True, "project": project_id, "scopes": scopes}


@app.get("/projects/{project_id}/threads")
def project_threads_get(
    project_id: str,
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pr = _project_root(project_id)
    tdir = (pr / "threads").resolve()
    tdir.mkdir(parents=True, exist_ok=True)

    items = []
    for p in sorted(tdir.glob("*"), key=lambda x: x.name.lower()):
        if not p.is_file():
            continue
        try:
            st = p.stat()
            items.append({"name": p.name, "size": int(st.st_size), "mtime": int(st.st_mtime)})
        except Exception:
            items.append({"name": p.name})
    return {"ok": True, "project": project_id, "threads": items}


@app.post("/threads/list")
def threads_list(
    payload: Dict[str, Any] = Body(default_factory=dict),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    """
    UI POSTs to /api/threads/list -> tool-gateway receives /threads/list.

    Accepts MANY shapes (to avoid 400):
      { "project":"sera" }
      { "project_id":"sera" }
      { "id":"sera" }
      { "project":"sera", "limit":50 }
    """
    _auth(x_tool_token)

    pid = (
        (payload.get("project") or payload.get("project_id") or payload.get("id") or payload.get("pid") or "default")
        if isinstance(payload, dict)
        else "default"
    )
    pid = str(pid).strip() or "default"
    limit = payload.get("limit", 200) if isinstance(payload, dict) else 200
    try:
        limit = int(limit)
    except Exception:
        limit = 200
    limit = max(1, min(limit, 2000))

    pr = _project_root(pid)
    tdir = (pr / "threads").resolve()
    tdir.mkdir(parents=True, exist_ok=True)

    # Prefer meta-based listing (t_<ts>.meta.json). Fall back to file listing if none exist.
    metas = sorted(tdir.glob("*.meta.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if metas:
        out = []
        for mp in metas[:limit]:
            try:
                meta = json.loads(mp.read_text(encoding="utf-8", errors="ignore") or "{}")
            except Exception:
                meta = {}
            tid = meta.get("id") or mp.name.replace(".meta.json", "")
            title = meta.get("title") or tid
            updated_at = meta.get("updated_at") or int(mp.stat().st_mtime)
            archived = bool(meta.get("archived", False))
            out.append({"thread_id": tid, "id": tid, "title": title, "updated_at": updated_at, "archived": archived})
        return {"ok": True, "project": pid, "threads": out}

    # Back-compat: raw file listing (rare)
    threads = []
    for p in sorted(tdir.glob("*"), key=lambda x: x.name.lower()):
        if not p.is_file():
            continue
        try:
            st = p.stat()
            threads.append({"name": p.name, "size": int(st.st_size), "mtime": int(st.st_mtime)})
        except Exception:
            threads.append({"name": p.name})
        if len(threads) >= limit:
            break

    return {"ok": True, "project": pid, "threads": threads}


def _thread_paths(project: str, thread_id: str) -> Tuple[Path, Path, Path]:
    pid = _safe_project_id(project or "default")
    pr = _project_root(pid)
    tdir = (pr / "threads").resolve()
    tdir.mkdir(parents=True, exist_ok=True)
    tid = str(thread_id or "").strip()
    if not tid:
        raise HTTPException(400, "thread_id required")
    meta_path = (tdir / f"{tid}.meta.json").resolve()
    data_path = (tdir / f"{tid}.jsonl").resolve()
    if tdir not in meta_path.parents or tdir not in data_path.parents:
        raise HTTPException(400, "Invalid thread_id")
    return (tdir, meta_path, data_path)


def _read_thread_meta(meta_path: Path) -> Dict[str, Any]:
    if not meta_path.exists():
        raise HTTPException(404, "Thread not found")
    try:
        return json.loads(meta_path.read_text(encoding="utf-8", errors="ignore") or "{}")
    except Exception:
        return {}


def _write_thread_meta(meta_path: Path, meta: Dict[str, Any]) -> None:
    meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")


@app.post("/threads/read")
def threads_read(
    req: ThreadRefReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _, meta_path, data_path = _thread_paths(req.project, req.thread_id)
    meta = _read_thread_meta(meta_path)

    messages: List[Dict[str, Any]] = []
    if data_path.exists():
        try:
            with data_path.open("r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        m = json.loads(line)
                        messages.append({
                            "role": m.get("role") or "assistant",
                            "content": m.get("content") if m.get("content") is not None else m.get("text", ""),
                            "ts": m.get("ts") or m.get("time") or int(meta.get("updated_at") or time.time()),
                        })
                    except Exception:
                        continue
        except Exception:
            pass
    return {"ok": True, "project": _safe_project_id(req.project), "thread_id": req.thread_id, "meta": meta, "messages": messages}


@app.post("/threads/append")
def threads_append(
    req: ThreadAppendReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _, meta_path, data_path = _thread_paths(req.project, req.thread_id)
    meta = _read_thread_meta(meta_path)

    ts = int(req.ts or time.time())
    role = (req.role or "user").strip() or "user"
    line = {"role": role, "content": str(req.content or ""), "ts": ts}

    data_path.parent.mkdir(parents=True, exist_ok=True)
    with data_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(line, ensure_ascii=False) + "\n")

    meta["updated_at"] = ts
    _write_thread_meta(meta_path, meta)
    return {"ok": True, "project": _safe_project_id(req.project), "thread_id": req.thread_id}


@app.post("/threads/rename")
def threads_rename(
    req: ThreadRenameReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _, meta_path, _ = _thread_paths(req.project, req.thread_id)
    meta = _read_thread_meta(meta_path)
    meta["title"] = (req.title or "").strip() or meta.get("title") or req.thread_id
    meta["updated_at"] = int(time.time())
    _write_thread_meta(meta_path, meta)
    return {"ok": True, "project": _safe_project_id(req.project), "thread_id": req.thread_id, "meta": meta}


@app.post("/threads/archive")
def threads_archive(
    req: ThreadArchiveReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _, meta_path, _ = _thread_paths(req.project, req.thread_id)
    meta = _read_thread_meta(meta_path)
    meta["archived"] = bool(req.archived)
    meta["updated_at"] = int(time.time())
    _write_thread_meta(meta_path, meta)
    return {"ok": True, "project": _safe_project_id(req.project), "thread_id": req.thread_id, "meta": meta}


@app.post("/threads/delete")
def threads_delete(
    req: ThreadDeleteReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _, meta_path, data_path = _thread_paths(req.project, req.thread_id)
    # Soft guard: do not delete outside threads dir (enforced by _thread_paths)
    try:
        if meta_path.exists():
            meta_path.unlink()
        if data_path.exists():
            data_path.unlink()
    except Exception as e:
        raise HTTPException(500, f"Delete failed: {e}")
    return {"ok": True, "project": _safe_project_id(req.project), "thread_id": req.thread_id}


@app.post("/threads/attach")
def threads_attach(
    req: ThreadAttachReq = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    from_project = _safe_project_id(req.project or "default")
    to_project = _safe_project_id((req.to_project or "default") if req.to_project is not None else "default")
    if from_project == to_project:
        return {"ok": True, "project": from_project, "thread_id": req.thread_id, "moved": False}

    _, src_meta, src_data = _thread_paths(from_project, req.thread_id)
    _, dst_meta, dst_data = _thread_paths(to_project, req.thread_id)
    if dst_meta.exists() or dst_data.exists():
        raise HTTPException(409, "Destination already has a thread with this id")

    meta = _read_thread_meta(src_meta)
    meta["project"] = to_project
    meta["updated_at"] = int(time.time())

    # Move files
    dst_meta.parent.mkdir(parents=True, exist_ok=True)
    try:
        src_meta.replace(dst_meta)
        if src_data.exists():
            src_data.replace(dst_data)
    except Exception as e:
        raise HTTPException(500, f"Move failed: {e}")

    # Update meta in-place at destination
    _write_thread_meta(dst_meta, meta)
    return {"ok": True, "from_project": from_project, "to_project": to_project, "thread_id": req.thread_id, "moved": True, "meta": meta}


# ----------------------------
# Thread attachments (base64 upload + download)
# ----------------------------
def _safe_filename(name: str) -> str:
    n = (name or "file").strip().replace("\\", "/")
    n = n.split("/")[-1]
    n = re.sub(r"[^A-Za-z0-9._-]+", "_", n)
    if not n or n in (".", ".."):  # pragma: no cover
        n = "file"
    return n[:180]


def _thread_files_dir(pr: Path, thread_id: str) -> Path:
    tid = str(thread_id or "").strip()
    if not tid or ".." in tid or "/" in tid or "\\" in tid:
        raise HTTPException(400, "Invalid thread_id")
    d = (pr / "threads_files" / tid).resolve()
    prr = pr.resolve()
    if prr not in d.parents:
        raise HTTPException(400, "Invalid thread files dir")
    d.mkdir(parents=True, exist_ok=True)
    return d


@app.post("/threads/upload_b64")
def threads_upload_b64(
    req: ThreadUploadB64Req = Body(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _deny_if_safe_mode("threads_upload_b64")

    pr = _project_root(req.project)
    # Ensure thread exists (best-effort): touching meta file is enough
    _, meta_path, _ = _thread_paths(req.project, req.thread_id)
    if not meta_path.exists():
        meta = {"thread_id": req.thread_id, "project": _safe_project_id(req.project), "title": req.thread_id, "created_at": int(time.time()), "updated_at": int(time.time()), "archived": False}
        _write_thread_meta(meta_path, meta)

    safe_name = _safe_filename(req.filename)
    file_id = uuid.uuid4().hex

    b64s = req.b64 or ""
    if "," in b64s and b64s.strip().lower().startswith("data:"):
        b64s = b64s.split(",", 1)[1]
    try:
        data = base64.b64decode(b64s, validate=True)
    except Exception:
        raise HTTPException(400, "Invalid base64")

    files_dir = _thread_files_dir(pr, req.thread_id)
    out_name = f"{file_id}__{safe_name}"
    out_path = (files_dir / out_name).resolve()
    if files_dir.resolve() not in out_path.parents:
        raise HTTPException(400, "Invalid output")
    out_path.write_bytes(data)

    mime = req.mime or mimetypes.guess_type(safe_name)[0] or "application/octet-stream"
    meta = {
        "file_id": file_id,
        "name": safe_name,
        "stored_name": out_name,
        "size": len(data),
        "mime": mime,
        "uploaded_at": int(time.time()),
        "project": _safe_project_id(req.project),
        "thread_id": req.thread_id,
    }
    (files_dir / f"{file_id}.meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    return {"ok": True, "project": _safe_project_id(req.project), "thread_id": req.thread_id, "file_id": file_id, "name": safe_name, "size": len(data), "mime": mime}


@app.get("/threads/file")
def threads_file(
    project: str = Query("default"),
    thread_id: str = Query(...),
    file_id: str = Query(...),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pr = _project_root(project)
    files_dir = _thread_files_dir(pr, thread_id)
    fid = str(file_id or "").strip()
    if not re.fullmatch(r"[a-fA-F0-9]{16,64}", fid):
        raise HTTPException(400, "Invalid file_id")
    matches = list(files_dir.glob(f"{fid}__*"))
    if not matches:
        raise HTTPException(404, "File not found")
    fp = matches[0]
    meta_path = files_dir / f"{fid}.meta.json"
    download_name = fp.name.split("__", 1)[1] if "__" in fp.name else fp.name
    media_type = "application/octet-stream"
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            media_type = meta.get("mime") or media_type
            download_name = meta.get("name") or download_name
        except Exception:
            pass
    return FileResponse(path=str(fp), media_type=media_type, filename=download_name)

@app.get("/files/list")
async def files_list(
    project: str = "default",
    path: str = "outbox",
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    d = _area_dir(project, path)
    items = []
    for p in sorted(d.glob("*")):
        if p.is_file():
            st = p.stat()
            items.append({"name": p.name, "size": st.st_size, "mtime": int(st.st_mtime)})
    return {"ok": True, "project": _safe_project_id(project), "path": path, "files": items}


@app.get("/files/download")
async def files_download(
    project: str,
    path: str,
    name: str,
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    d = _area_dir(project, path)
    target = (d / name).resolve()
    if d not in target.parents or not target.exists() or not target.is_file():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(str(target), filename=target.name)


@app.post("/files/upload")
async def files_upload(
    project: str = "default",
    path: str = "quarantine",
    file: UploadFile = File(...),
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    _deny_if_safe_mode("files_upload")
    d = _area_dir(project, path)
    fname = Path(file.filename or "upload.bin").name
    target = (d / fname).resolve()
    if d not in target.parents:
        raise HTTPException(status_code=400, detail="Invalid filename")
    with target.open("wb") as f:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            f.write(chunk)
    return {"ok": True, "project": _safe_project_id(project), "path": path, "name": target.name, "bytes": target.stat().st_size}


# ----------------------------
# Backups (tokened)
# UI expects /api/backups/list?project=...
# ----------------------------
@app.get("/backups/list")
def backups_list(
    project: str = "default",
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    d = _area_dir(project, "backups")
    items = []
    for p in sorted(d.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True):
        if p.is_file():
            st = p.stat()
            items.append({"name": p.name, "size": st.st_size, "mtime": int(st.st_mtime)})
    return {"ok": True, "project": _safe_project_id(project), "files": items}


class BackupsCreateReq(BaseModel):
    # Optional label; will be sanitized into filename
    name: str | None = None
    # Optional comma-separated areas (repo is excluded by default)
    areas: str | None = None


@app.post("/backups/create")
def backups_create(
    req: BackupsCreateReq,
    project: str = "default",
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    pid = _safe_project_id(project)
    outdir = _area_dir(pid, "backups")

    label = (req.name or "backup").strip() or "backup"
    label = "".join([c for c in label if c.isalnum() or c in ("-", "_", ".")])[:64] or "backup"
    ts = time.strftime("%Y%m%d_%H%M%S", time.gmtime())
    outname = f"{label}_{ts}.tar.gz"
    outpath = (outdir / outname).resolve()

    # Default minimal/dev-safe set
    areas = req.areas or "docs,logs,configs,manifests,threads"
    wanted = [a.strip() for a in areas.split(",") if a.strip()]
    # Map friendly names -> internal areas
    area_map = {
        "docs": "docs",
        "logs": "logs",
        "configs": "configs",
        "manifests": "manifests",
        "threads": "threads",
        "backups": "backups",
        "uploads": "uploads",
        "outbox": "outbox",
    }

    with tarfile.open(outpath, "w:gz") as tf:
        for a in wanted:
            key = area_map.get(a)
            if not key:
                continue
            src = _area_dir(pid, key)
            if not src.exists():
                continue
            tf.add(src, arcname=f"{pid}/{key}")

    return {"ok": True, "project": pid, "file": outname, "path": str(outpath)}


# ----------------------------
# Threads (tokened)
# UI expects POST /api/threads/list
# ----------------------------
class ThreadsListReq(BaseModel):
    project: str = "default"

# ----------------------------
# IMPORTS (Phase2): stage / inspect / apply (tokened; apply is write)
# ----------------------------
MAX_IMPORT_FILES = int(os.environ.get("SERA_IMPORT_MAX_FILES", "50000"))
MAX_IMPORT_BYTES = int(os.environ.get("SERA_IMPORT_MAX_BYTES", str(2 * 1024 * 1024 * 1024)))  # 2GB


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _tar_safe_rel(name: str) -> str:
    n = (name or "").lstrip("./")
    p = Path(n)
    if p.is_absolute():
        raise HTTPException(400, f"Absolute path not allowed in tar: {name}")
    if ".." in p.parts:
        raise HTTPException(400, f"Traversal not allowed in tar: {name}")
    return str(p)


def _safe_join(root: Path, rel: str) -> Path:
    out = (root / rel).resolve()
    r = root.resolve()
    if r not in out.parents and out != r:
        raise HTTPException(400, f"Escapes root: {rel}")
    return out


class ImportStageReq(BaseModel):
    project: str
    artifact_path: str  # e.g. "uploads/file.tar.gz"


class ImportInspectReq(BaseModel):
    project: str
    import_id: str


class ImportApplyReq(BaseModel):
    project: str
    import_id: str


@app.post("/imports/stage")
def imports_stage(req: ImportStageReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)

    pr = _project_root(req.project)
    uploads = pr / "uploads"
    quarantine = pr / "quarantine"
    imports_dir = pr / "imports"
    for d in (uploads, quarantine, imports_dir, pr / "repo", pr / "reports", pr / "manifests"):
        d.mkdir(parents=True, exist_ok=True)

    if not (req.artifact_path or "").startswith("uploads/"):
        raise HTTPException(400, "artifact_path must start with 'uploads/'")

    src = _safe_join(uploads, req.artifact_path.replace("uploads/", "", 1))
    if not src.exists():
        raise HTTPException(404, f"Artifact not found: {req.artifact_path}")

    import_id = f"imp_{int(time.time())}"
    idir = (imports_dir / import_id)
    idir.mkdir(parents=True, exist_ok=True)

    dst = (quarantine / src.name).resolve()
    if quarantine not in dst.parents:
        raise HTTPException(400, "Invalid destination")
    with src.open("rb") as rf, dst.open("wb") as wf:
        for chunk in iter(lambda: rf.read(1024 * 1024), b""):
            wf.write(chunk)

    meta = {
        "project": req.project,
        "import_id": import_id,
        "artifact_path": req.artifact_path,
        "staged_file": str(dst),
        "sha256": _sha256_file(dst),
        "staged_at": int(time.time()),
        "status": "staged",
    }
    (idir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    return {"ok": True, "import_id": import_id, "staged_path": f"quarantine/{dst.name}", "sha256": meta["sha256"]}


@app.post("/imports/inspect")
def imports_inspect(req: ImportInspectReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)

    pr = _project_root(req.project)
    meta_path = pr / "imports" / req.import_id / "meta.json"
    if not meta_path.exists():
        raise HTTPException(404, "Unknown import_id")

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    tar_path = Path(meta.get("staged_file", ""))
    if not tar_path.exists():
        raise HTTPException(404, "Staged artifact missing")

    total_files = 0
    total_bytes = 0
    preview = []

    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf.getmembers():
            # Block special files + all links (MVP hardening)
            if m.isdev() or m.ischr() or m.isblk() or m.isfifo():
                raise HTTPException(400, f"Blocked special file: {m.name}")
            if m.issym() or m.islnk():
                raise HTTPException(400, f"Blocked link in tar (MVP): {m.name}")

            name = _tar_safe_rel(m.name)

            if m.isfile():
                total_files += 1
                total_bytes += int(m.size or 0)

            if total_files > MAX_IMPORT_FILES:
                raise HTTPException(400, f"Too many files: {total_files} > {MAX_IMPORT_FILES}")
            if total_bytes > MAX_IMPORT_BYTES:
                raise HTTPException(400, f"Too large: {total_bytes} > {MAX_IMPORT_BYTES}")

            if len(preview) < 200:
                preview.append({"name": name, "type": "file" if m.isfile() else "dir", "size": int(m.size or 0)})

    return {"ok": True, "project": req.project, "import_id": req.import_id, "files": total_files, "bytes": total_bytes, "preview": preview}


@app.post("/imports/apply")
def imports_apply(req: ImportApplyReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    _deny_if_safe_mode("imports_apply")  # treat as write op

    pr = _project_root(req.project)
    meta_path = pr / "imports" / req.import_id / "meta.json"
    if not meta_path.exists():
        raise HTTPException(404, "Unknown import_id")

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    tar_path = Path(meta.get("staged_file", ""))
    if not tar_path.exists():
        raise HTTPException(404, "Staged artifact missing")

    repo = pr / "repo"
    repo.mkdir(parents=True, exist_ok=True)

    extracted_files = 0
    extracted_bytes = 0
    manifest = []

    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf.getmembers():
            if m.isdev() or m.ischr() or m.isblk() or m.isfifo() or m.issym() or m.islnk():
                raise HTTPException(400, f"Blocked tar member: {m.name}")

            rel = _tar_safe_rel(m.name)
            dest = _safe_join(repo, rel)

            if m.isdir():
                dest.mkdir(parents=True, exist_ok=True)
                continue

            if m.isfile():
                dest.parent.mkdir(parents=True, exist_ok=True)
                f = tf.extractfile(m)
                if f is None:
                    continue
                data = f.read()
                dest.write_bytes(data)

                extracted_files += 1
                extracted_bytes += len(data)

                if extracted_files > MAX_IMPORT_FILES or extracted_bytes > MAX_IMPORT_BYTES:
                    raise HTTPException(400, "Import exceeded configured limits")

                manifest.append({"path": str(dest.relative_to(repo)), "size": len(data)})

    ts = int(time.time())
    (pr / "manifests").mkdir(exist_ok=True)
    (pr / "manifests" / f"import_{req.import_id}_{ts}.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    audit = {
        "ts": ts,
        "action": "import.apply",
        "project": req.project,
        "import_id": req.import_id,
        "files": extracted_files,
        "bytes": extracted_bytes,
    }
    with (pr / "audit.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(audit) + "\n")

    meta["status"] = "applied"
    meta["applied_at"] = ts
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    return {"ok": True, "project": req.project, "import_id": req.import_id, "files": extracted_files, "bytes": extracted_bytes}


# ----------------------------
# Logs: action log tail (tokened)
# UI expects GET /api/logs/actions/tail?lines=200 (=> /logs/actions/tail)
# ----------------------------
@app.get("/logs/actions/tail")
def logs_actions_tail(
    lines: int = 200,
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    n = max(1, min(int(lines), 2000))
    try:
        content = Path(ACTION_LOG_PATH).read_text(encoding="utf-8", errors="replace")
    except Exception:
        content = ""
    arr = [ln for ln in content.splitlines() if ln.strip()]
    tail = arr[-n:]
    return {"ok": True, "path": ACTION_LOG_PATH, "count": len(tail), "lines": tail}


# ----------------------------
# FS read-only helpers (absolute-path constrained) (tokened)
# ----------------------------
@app.get("/fs/list")
def fs_list(
    path: str = Query(..., description="Absolute path to list"),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    safe_roots = [
        "/home/spartan/sera/sera-ai/incoming",
        "/workspace",
        "/state",
        "/logs",
        "/debug",
        "/incoming",
    ]
    if not any(path.startswith(r) for r in safe_roots):
        raise HTTPException(status_code=403, detail="Path not allowed")
    if not os.path.isdir(path):
        raise HTTPException(status_code=404, detail="Not a directory")
    items = []
    for name in sorted(os.listdir(path)):
        p = os.path.join(path, name)
        try:
            st = os.stat(p)
            items.append(
                {"name": name, "path": p, "is_dir": os.path.isdir(p), "size": st.st_size, "mtime": int(st.st_mtime)}
            )
        except Exception:
            continue
    return {"ok": True, "items": items}


@app.get("/fs/read")
def fs_read(
    path: str = Query(..., description="Absolute path to file to read"),
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    _auth(x_tool_token)
    safe_roots = [
        "/home/spartan/sera/sera-ai/incoming",
        "/workspace",
        "/state",
        "/logs",
        "/debug",
        "/incoming",
    ]
    if not any(path.startswith(r) for r in safe_roots):
        raise HTTPException(status_code=403, detail="Path not allowed")
    if not os.path.isfile(path):
        raise HTTPException(status_code=404, detail="Not a file")
    try:
        st = os.stat(path)
        if st.st_size > 256 * 1024:
            raise HTTPException(status_code=413, detail="File too large")
    except HTTPException:
        raise
    except Exception:
        pass
    try:
        with open(path, "rb") as f:
            data = f.read()
        try:
            content = data.decode("utf-8")
        except Exception:
            content = data.decode("utf-8", errors="replace")
        return {"ok": True, "path": path, "bytes": len(data), "content": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ----------------------------
# Share (read-only) (tokened)
# ----------------------------
@app.get("/share/list")
def share_list(dir: str = "", x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    rel = (dir or "").lstrip("/")
    p = _safe_share_path(rel) if rel else SHARE_DIR
    if not p.exists():
        return {"ok": True, "items": [], "warning": "share dir missing", "dir": str(p)}
    if not p.is_dir():
        raise HTTPException(status_code=400, detail="Not a directory")
    items = []
    for child in sorted(p.iterdir(), key=lambda x: x.name.lower()):
        try:
            st = child.stat()
            items.append(
                {
                    "name": child.name,
                    "rel": str(child.relative_to(SHARE_DIR)),
                    "is_dir": child.is_dir(),
                    "size": st.st_size,
                    "mtime": int(st.st_mtime),
                }
            )
        except Exception:
            continue
    return {"ok": True, "dir": str(p), "items": items}


@app.get("/share/read")
def share_read(path: str, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    rel = (path or "").lstrip("/")
    if not rel:
        raise HTTPException(status_code=400, detail="Missing path")
    p = _safe_share_path(rel)
    if not p.exists() or not p.is_file():
        raise HTTPException(status_code=404, detail="Not found")
    if p.stat().st_size > 1024 * 1024:
        raise HTTPException(status_code=413, detail="File too large (max 1MB)")
    return Response(p.read_bytes(), media_type="application/octet-stream")


# ----------------------------
# Home Assistant (optional) (tokened)
# ----------------------------
def _ha_headers() -> Dict[str, str]:
    if not HOME_ASSISTANT_URL or not HOME_ASSISTANT_TOKEN:
        raise HTTPException(status_code=500, detail="HOME_ASSISTANT_URL or HOME_ASSISTANT_TOKEN not set")
    return {"Authorization": f"Bearer {HOME_ASSISTANT_TOKEN}", "Content-Type": "application/json"}


class HAServiceReq(BaseModel):
    domain: str
    service: str
    data: Dict[str, Any] = {}


class HAEntityReq(BaseModel):
    entity_id: str


@app.post("/ha_call_service")
def ha_call_service(req: HAServiceReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    url = f"{HOME_ASSISTANT_URL}/api/services/{req.domain}/{req.service}"
    r = requests.post(url, headers=_ha_headers(), data=json.dumps(req.data), timeout=20)
    return {
        "ok": r.ok,
        "http": r.status_code,
        "body": (r.json() if r.headers.get("content-type", "").startswith("application/json") else {"text": r.text[:4000]}),
    }


@app.post("/ha_get_state")
def ha_get_state(req: HAEntityReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    url = f"{HOME_ASSISTANT_URL}/api/states/{req.entity_id}"
    r = requests.get(url, headers=_ha_headers(), timeout=20)
    return {
        "ok": r.ok,
        "http": r.status_code,
        "body": (r.json() if r.headers.get("content-type", "").startswith("application/json") else {"text": r.text[:4000]}),
    }


@app.get("/ha_states")
def ha_states(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    url = f"{HOME_ASSISTANT_URL}/api/states"
    r = requests.get(url, headers=_ha_headers(), timeout=30)
    data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {"text": r.text[:4000]}
    if isinstance(data, list):
        data = data[:2000]
    return {"ok": r.ok, "http": r.status_code, "body": data}


# ----------------------------
# /api/* aliases (IMPORTANT)
# This lets you route /api/... to tool-gateway later (or selectively via Caddy).
# ----------------------------
@app.get("/api/config")
def api_config_alias():
    return ui_config()


@app.get("/api/meta")
def api_meta_alias():
    return ui_meta()


@app.get("/api/system/checklist")
def api_system_checklist_alias():
    return system_checklist()


@app.get("/api/tests/quick")
def api_tests_quick_alias():
    return tests_quick()


@app.post("/api/tests/quick")
def api_tests_quick_post_alias():
    return tests_quick()


# ----------------------------
# Chat (minimal local handler)
# ----------------------------
# UI clients (chat.js + voice_client.js) POST to /api/chat.
# Until the full agent/LLM pipeline is wired, provide a stable endpoint that
# returns a deterministic reply.


@app.post("/chat")
def chat_local(payload: Dict[str, Any] = Body(...)):
    text = str(payload.get("user") or payload.get("text") or "").strip()
    if not text:
        raise HTTPException(status_code=422, detail={"error": "missing_user_text"})
    project = str(payload.get("project") or payload.get("project_id") or "default")
    thread_id = payload.get("thread_id")
    reply = f"OK. Received: {text[:400]}"
    return {"ok": True, "reply": reply, "project": project, "thread_id": thread_id or "(auto)"}


@app.post("/api/chat")
def api_chat_local(payload: Dict[str, Any] = Body(...)):
    return chat_local(payload)


@app.get("/api/profiles")
def api_profiles_alias():
    return profiles()


@app.get("/api/sysdiag/last")
def api_sysdiag_last_alias():
    return sysdiag_last()


@app.get("/api/projects/list")
def api_projects_list_alias(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    return projects_list(x_tool_token=x_tool_token)


@app.get("/api/projects/current")
def api_projects_current_alias(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    return projects_current(x_tool_token=x_tool_token)


@app.post("/api/projects/create")
def api_projects_create_alias(req: ProjectCreateReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    return projects_create(req=req, x_tool_token=x_tool_token)


@app.post("/api/projects/set_current")
def api_projects_set_current_alias(req: ProjectSetReq, x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    return projects_set_current(req=req, x_tool_token=x_tool_token)


@app.get("/api/files/list")
async def api_files_list_alias(
    project: str = "default",
    path: str = "outbox",
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    return await files_list(project=project, path=path, x_tool_token=x_tool_token)


@app.get("/api/files/download")
async def api_files_download_alias(
    project: str,
    path: str,
    name: str,
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    return await files_download(project=project, path=path, name=name, x_tool_token=x_tool_token)


@app.post("/api/files/upload")
async def api_files_upload_alias(
    project: str = "default",
    path: str = "quarantine",
    file: UploadFile = File(...),
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    return await files_upload(project=project, path=path, file=file, x_tool_token=x_tool_token)


@app.get("/api/backups/list")
def api_backups_list_alias(
    project: str = "default",
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    return backups_list(project=project, x_tool_token=x_tool_token)


@app.post("/api/backups/create")
def api_backups_create_alias(
    req: BackupsCreateReq,
    project: str = "default",
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    return backups_create(req=req, project=project, x_tool_token=x_tool_token)


@app.post("/api/threads/list")
def api_threads_list_alias(
    req: ThreadsListReq,
    x_tool_token: str | None = Header(default=None, alias="X-Tool-Token"),
):
    return threads_list(req=req, x_tool_token=x_tool_token)


@app.get("/api/logs/actions/tail")
def api_logs_actions_tail_alias(
    lines: int = 200,
    x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token"),
):
    return logs_actions_tail(lines=lines, x_tool_token=x_tool_token)


# ----------------------------
# Static UI (optional)
# ----------------------------
try:
    if os.path.isdir(UI_DIR):
        app.mount("/", StaticFiles(directory=UI_DIR, html=True), name="ui")
except Exception:
    pass

@app.post("/services/restart")
def services_restart(payload: Dict[str, Any] = Body(default_factory=dict),
                     x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    _deny_if_admin_actions_disabled("services.restart")
    username = _active_user(None)
    if not _is_admin_user(username):
        raise HTTPException(status_code=403, detail="admin_required")
    name = str(payload.get("name") or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="missing_name")
    if not shutil.which("docker"):
        raise HTTPException(status_code=500, detail="docker_not_found")
    try:
        out = subprocess.check_output(["docker","restart",name], stderr=subprocess.STDOUT, timeout=25).decode("utf-8", errors="ignore")
        return {"ok": True, "name": name, "output": out}
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=f"restart_failed: {e.output.decode('utf-8',errors='ignore')[:4000]}")


# ----------------------------
# Deploy Profiles DB (SQLite in /config)
# ----------------------------
DEPLOY_PROFILES_DB = Path(os.environ.get("SERA_DB_PATH", str(Path(os.environ.get("CONFIG_DIR","/config")) / "sera.db")))

def _db():
    DEPLOY_PROFILES_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DEPLOY_PROFILES_DB))
    conn.row_factory = sqlite3.Row
    conn.execute("""
      CREATE TABLE IF NOT EXISTS deploy_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner TEXT NOT NULL,
        name TEXT NOT NULL,
        container TEXT NOT NULL,
        path TEXT NOT NULL,
        restart TEXT,
        created_at TEXT NOT NULL
      )
    """)
    conn.commit()
    return conn

def _profiles_seed_for_user(owner: str):
    conn = _db()
    cur = conn.execute("SELECT COUNT(*) AS n FROM deploy_profiles WHERE owner=?", (owner,))
    n = int(cur.fetchone()["n"])
    if n == 0:
        now = datetime.datetime.utcnow().isoformat() + "Z"
        conn.execute("INSERT INTO deploy_profiles(owner,name,container,path,restart,created_at) VALUES(?,?,?,?,?,?)",
                     (owner,"voice-ui","voice-ui","/srv/app.js","voice-ui",now))
        conn.execute("INSERT INTO deploy_profiles(owner,name,container,path,restart,created_at) VALUES(?,?,?,?,?,?)",
                     (owner,"tool-gateway","tool-gateway","/app/server.py","tool-gateway",now))
        conn.commit()
    conn.close()


def _health_urls() -> List[str]:
    return [
      "http://127.0.0.1:8080/__ping",
      "http://127.0.0.1:8080/api/health",
      "http://127.0.0.1:8080/api/meta",
    ]

def _http_ok(url: str, timeout: int = 3) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return 200 <= int(r.status) < 300
    except Exception:
        return False

def _append_action_log(obj: Dict[str, Any]):
    try:
        p = Path(os.environ.get("ACTION_LOG_PATH","/logs/actions.jsonl"))
        p.parent.mkdir(parents=True, exist_ok=True)
        obj = dict(obj)
        obj["ts"] = datetime.datetime.utcnow().isoformat() + "Z"
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")
    except Exception:
        pass

@app.post("/deploy/push_atomic")
def deploy_push_atomic(payload: Dict[str, Any] = Body(default_factory=dict), request: Request = None,
                       x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    """
    Atomic-ish deploy helper:
      pull (optional) -> snapshot (optional) -> push -> restart (optional) -> health -> action log
    """
    _auth(x_tool_token)
    _deny_if_admin_actions_disabled("deploy.push_atomic")
    username = _active_user(request)
    if not _is_admin_user(username):
        raise HTTPException(status_code=403, detail="admin_required")
    if os.environ.get("SERA_SAFE_MODE","1").strip() not in ("0","false","False"):
        raise HTTPException(status_code=403, detail="safe_mode_blocks_write")

    container = str(payload.get("container") or "").strip()
    path = str(payload.get("path") or "").strip()
    text_in = payload.get("text")
    do_snapshot = bool(payload.get("snapshot", False))
    restart_name = str(payload.get("restart") or "").strip()
    do_restart = bool(payload.get("restart_enabled", False)) and bool(restart_name)
    do_health = bool(payload.get("health", True))

    if not container or not path or text_in is None:
        raise HTTPException(status_code=400, detail="missing_container_path_text")
    if not _match_allowlist(path):
        raise HTTPException(status_code=403, detail="path_not_allowed_for_deploy")

    res = {"ok": True, "container": container, "path": path, "snapshot": None, "backup": None, "restart": None, "health": []}

    # snapshot
    if do_snapshot:
        try:
            snap = snapshot_bundle({"mode":"diag", "name": f"prepush_{container}_{int(time.time())}"}, x_tool_token=x_tool_token)  # type: ignore
            res["snapshot"] = snap
        except Exception as e:
            res["snapshot"] = {"ok": False, "error": str(e)}

    # push (reuse existing push_file for backup behavior)
    push = deploy_push_file({"container": container, "path": path, "text": text_in}, request=request, x_tool_token=x_tool_token)  # type: ignore
    res["backup"] = push.get("backup")

    # restart
    if do_restart:
        try:
            out = services_restart({"name": restart_name}, x_tool_token=x_tool_token)  # type: ignore
            res["restart"] = out
        except Exception as e:
            res["restart"] = {"ok": False, "error": str(e)}

    # health
    if do_health:
        checks = []
        for url in _health_urls():
            ok = _http_ok(url, timeout=3)
            checks.append({"url": url, "ok": ok})
        res["health"] = checks

    _append_action_log({
        "action": "deploy.push_atomic",
        "user": username,
        "container": container,
        "path": path,
        "snapshot": bool(do_snapshot),
        "restart": do_restart,
        "health_ok": all([c["ok"] for c in res["health"]]) if res["health"] else None
    })

    return res


# ----------------------------
# File Roots (A/C) abstraction
# ----------------------------
def _targets_path() -> Path:
    return Path(os.environ.get("SERA_TARGETS_PATH", str(Path(os.environ.get("CONFIG_DIR","/config")) / "sera_targets.json")))

def _load_targets() -> Dict[str, Any]:
    p = _targets_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def _root_for(root: str) -> Path:
    """
    root=A stable, root=C workspace. (D is container deploy, handled elsewhere)
    Falls back to environment defaults if no targets file exists.
    """
    t = _load_targets()
    root = (root or "").upper().strip()
    if root == "A":
        v = (t.get("A") or t.get("stable") or {}).get("root") if isinstance(t.get("A"), dict) else (t.get("A") or "")
        if not v:
            v = os.environ.get("SERA_STABLE_ROOT","/workspace/projects/sera")
        return Path(v)
    if root == "C":
        v = (t.get("C") or t.get("workspace") or {}).get("root") if isinstance(t.get("C"), dict) else (t.get("C") or "")
        if not v:
            v = os.environ.get("SERA_WORKSPACE_ROOT","/workspace/projects/sera")
        return Path(v)
    raise HTTPException(status_code=400, detail="invalid_root")

def _safe_join(base: Path, rel: str) -> Path:
    rel = (rel or "").lstrip("/")
    p = (base / rel).resolve()
    base_r = base.resolve()
    if not str(p).startswith(str(base_r)):
        raise HTTPException(status_code=400, detail="path_escape")
    return p

@app.get("/files/read")
def files_read(root: str, path: str, request: Request,
               x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    user = _active_user(request)
    _require_role(user, "user")
    base = _root_for(root)
    fp = _safe_join(base, path)
    if not fp.exists() or not fp.is_file():
        raise HTTPException(status_code=404, detail="not_found")
    try:
        return {"ok": True, "root": root.upper(), "path": path, "text": fp.read_text(encoding="utf-8", errors="ignore")}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"read_failed: {e}")

@app.post("/files/write")
def files_write(payload: Dict[str, Any] = Body(default_factory=dict), request: Request = None,
                x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    _deny_if_admin_actions_disabled("files.write")
    user = _active_user(request)
    _require_role(user, "privileged")
    root = str(payload.get("root") or "").upper().strip()
    path = str(payload.get("path") or "")
    text_in = payload.get("text")
    if text_in is None:
        raise HTTPException(status_code=400, detail="missing_text")
    # Only allow writes to C (workspace) in Phase 8
    if root != "C":
        raise HTTPException(status_code=403, detail="write_only_allowed_to_C")
    base = _root_for(root)
    fp = _safe_join(base, path)
    fp.parent.mkdir(parents=True, exist_ok=True)
    try:
        fp.write_text(str(text_in), encoding="utf-8")
        _append_action_log({"action":"files.write","user":user,"root":root,"path":path})
        return {"ok": True, "root": root, "path": path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"write_failed: {e}")


@app.get("/rbac/me")
def rbac_me(request: Request,
            x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    user = _active_user(request)
    role = "guest"
    try:
        if _is_admin_user(user): role = "admin"
        elif _is_privileged_user(user): role = "privileged"
        elif user: role = "user"
    except Exception:
        pass
    return {"ok": True, "user": user, "role": role}


def _docker_ps() -> List[Dict[str, Any]]:
    if not shutil.which("docker"):
        return []
    try:
        out = subprocess.check_output(
            ["docker","ps","--format","{{.Names}}|{{.Status}}|{{.Image}}|{{.Ports}}"],
            stderr=subprocess.STDOUT, timeout=10
        ).decode("utf-8", errors="ignore")
        res = []
        for ln in out.splitlines():
            if not ln.strip(): continue
            parts = ln.split("|")
            while len(parts)<4: parts.append("")
            res.append({"name":parts[0], "status":parts[1], "image":parts[2], "ports":parts[3]})
        return res
    except Exception:
        return []

def _compose_services_from_file() -> Dict[str, Any]:
    # Minimal parse: look for 'services:' then top-level service keys.
    compose_path = Path(os.environ.get("SERA_COMPOSE_PATH", str(Path(__file__).resolve().parent.parent / "docker-compose.yml")))
    if not compose_path.exists():
        return {"path": str(compose_path), "services": []}
    txtc = compose_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    services=[]
    in_services=False
    for ln in txtc:
        if re.match(r'^services\s*:\s*$', ln):
            in_services=True
            continue
        if in_services:
            m = re.match(r'^\s{2}([A-Za-z0-9_-]+)\s*:\s*$', ln)
            if m:
                services.append(m.group(1))
            # stop at top-level block
            if re.match(r'^[A-Za-z0-9_-]+\s*:\s*$', ln):
                break
    return {"path": str(compose_path), "services": services}

@app.get("/services/list")
def services_list(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    ps = _docker_ps()
    comp = _compose_services_from_file()
    return {"ok": True, "containers": ps, "compose": comp}

@app.get("/sys/health_matrix")
def sys_health_matrix(x_tool_token: Optional[str] = Header(default=None, alias="X-Tool-Token")):
    _auth(x_tool_token)
    urls = _health_urls()
    checks = [{"url":u, "ok": _http_ok(u, timeout=3)} for u in urls]
    # also basic port check for 3000/3100/3200/8080
    ports = [3000,3100,3200,8080]
    port_rows=[]
    for p in ports:
        s=socket.socket()
        s.settimeout(0.5)
        try:
            s.connect(("127.0.0.1", p))
            ok=True
        except Exception:
            ok=False
        finally:
            try: s.close()
            except Exception: pass
        port_rows.append({"port": p, "ok": ok})
    return {"ok": True, "http": checks, "ports": port_rows}
