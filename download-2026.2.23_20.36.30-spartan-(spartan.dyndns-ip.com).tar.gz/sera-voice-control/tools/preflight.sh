#!/usr/bin/env bash
set -euo pipefail

log(){ printf '%s\n' "$*"; }
warn(){ printf 'WARN: %s\n' "$*" >&2; }
fail(){ printf '\n=== PREFLIGHT FAILED ===\n%s\n' "$*" >&2; exit 2; }

APP_DIR_DEFAULT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${SERA_APP_DIR:-$APP_DIR_DEFAULT}"

ROOT_DEFAULT="/home/spartan/sera/sera-ai"
ROOT="${SERA_ROOT:-$ROOT_DEFAULT}"

PROJECT_DEFAULT="sera-voice-control"
PROJECT="${SERA_PROJECT:-$PROJECT_DEFAULT}"

INCOMING_DIR="${INCOMING_DIR:-$ROOT/incoming}"
LOG_DIR="${LOG_DIR:-$ROOT/logs/$PROJECT}"
CONFIG_DIR="${CONFIG_DIR:-$ROOT/config}"
WORKSPACE_DIR="${WORKSPACE_DIR:-$ROOT/workspaces}"
SHARE_DIR="${SHARE_DIR:-$ROOT/share}"
DEBUG_DIR="${DEBUG_DIR:-$ROOT/debug}"

# Ensure dirs exist
mkdir -p "$INCOMING_DIR" "$LOG_DIR" "$CONFIG_DIR" "$WORKSPACE_DIR" "$SHARE_DIR" "$DEBUG_DIR" || true

# Ensure .env exists
if [[ ! -f "$APP_DIR/.env" ]]; then
  if [[ -f "$APP_DIR/.env.example" ]]; then
    log "Seeding .env from .env.example"
    cp -a "$APP_DIR/.env.example" "$APP_DIR/.env"
  else
    fail "Missing $APP_DIR/.env and no .env.example to seed from."
  fi
fi

# Tooling checks
command -v docker >/dev/null 2>&1 || fail "docker not found in PATH"
docker version >/dev/null 2>&1 || fail "docker is not usable (permission/daemon issue)"
docker compose version >/dev/null 2>&1 || fail "docker compose not available (need docker compose v2 plugin)"

# Required files
[[ -f "$APP_DIR/docker-compose.yml" ]] || fail "docker-compose.yml missing in $APP_DIR"
[[ -f "$APP_DIR/BUNDLE_MANIFEST.json" ]] || warn "BUNDLE_MANIFEST.json missing (recommended)"

# Disk space check (need at least 1GB free on ROOT filesystem)
avail_kb="$(df -Pk "$ROOT" | awk 'NR==2{print $4}')"
if [[ -n "${avail_kb:-}" ]] && [[ "$avail_kb" -lt 1048576 ]]; then
  fail "Low disk space under $ROOT: available ${avail_kb}KB (< 1GB)."
fi

# Port checks (host networking: avoid collisions)
check_port_free(){
  local p="$1"
  if ss -tuln 2>/dev/null | awk '{print $5}' | grep -qE "[:\.]${p}$"; then
    warn "Port ${p} appears in use. If SERA fails to start, free this port or change config."
  fi
}
command -v ss >/dev/null 2>&1 || warn "ss not found; skipping port checks"
if command -v ss >/dev/null 2>&1; then
  for p in 3000 8080 3100 3200; do check_port_free "$p"; done
fi

# Writable workspace mount expectation (agent DB defaults to /workspace inside container)
if [[ ! -w "$WORKSPACE_DIR" ]]; then
  warn "WORKSPACE_DIR not writable: $WORKSPACE_DIR (agent DB may fail if mapped here)"
fi

log "PREFLIGHT OK"
