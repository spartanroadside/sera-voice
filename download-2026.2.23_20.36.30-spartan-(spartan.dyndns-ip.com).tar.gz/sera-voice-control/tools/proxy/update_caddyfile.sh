#!/usr/bin/env bash
set -euo pipefail

# update_caddyfile.sh (1.070 stable)
# Safe Caddyfile update with validation + automatic rollback.
#
# Usage:
#   tools/proxy/update_caddyfile.sh caddy/Caddyfile.devstable
#
# What it does:
# - Copies candidate Caddyfile into the running voice-ui container (/tmp/Caddyfile.next)
# - Validates with: caddy validate --adapter caddyfile
# - Backs up current Caddyfile with timestamp
# - Swaps in candidate
# - Restarts voice-ui
# - Gates success on: curl http://127.0.0.1:8080/__ping
# - Rolls back automatically on failure

NEW_FILE="${1:-}"
if [[ -z "${NEW_FILE}" || ! -f "${NEW_FILE}" ]]; then
  echo "ERROR: Provide path to new Caddyfile. Example: $0 caddy/Caddyfile.devstable" >&2
  exit 2
fi

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${PROJECT_ROOT}"

SERVICE="voice-ui"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP_HOST="${PROJECT_ROOT}/caddy/Caddyfile.bak.${TS}"

echo "== Copying candidate into container (/tmp/Caddyfile.next) for validation..."
docker compose exec -T "${SERVICE}" sh -lc 'cat > /tmp/Caddyfile.next' < "${NEW_FILE}"

echo "== Validating candidate Caddyfile inside container..."
docker compose exec -T "${SERVICE}" sh -lc 'caddy validate --config /tmp/Caddyfile.next --adapter caddyfile'

echo "== Backing up current Caddyfile -> ${BACKUP_HOST}"
cp -f "${PROJECT_ROOT}/caddy/Caddyfile" "${BACKUP_HOST}"

echo "== Swapping in candidate Caddyfile"
cp -f "${NEW_FILE}" "${PROJECT_ROOT}/caddy/Caddyfile"

echo "== Restarting ${SERVICE}"
docker compose restart "${SERVICE}"

echo "== Smoke test: http://127.0.0.1:8080/__ping"
if ! curl -fsS "http://127.0.0.1:8080/__ping" >/dev/null; then
  echo "!! Smoke test failed. Rolling back Caddyfile..."
  cp -f "${BACKUP_HOST}" "${PROJECT_ROOT}/caddy/Caddyfile"
  docker compose restart "${SERVICE}"
  echo "Rolled back to ${BACKUP_HOST}"
  exit 1
fi

echo "OK: Caddyfile applied and UI ping is healthy."
