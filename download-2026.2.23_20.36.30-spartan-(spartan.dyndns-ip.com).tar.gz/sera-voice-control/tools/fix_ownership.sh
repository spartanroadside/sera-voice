#!/usr/bin/env bash
set -euo pipefail
# DEPRECATED: use ./scripts/fix_ownership.sh
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/../scripts/fix_ownership.sh" "$@"
