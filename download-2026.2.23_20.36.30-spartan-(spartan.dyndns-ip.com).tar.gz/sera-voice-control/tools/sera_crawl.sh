#!/usr/bin/env bash
set -euo pipefail
# DEPRECATED: use ./scripts/sera_crawl.sh
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/../scripts/sera_crawl.sh" "$@"
