#!/usr/bin/env bash
set -euo pipefail

log(){ printf '%s\n' "$*"; }
warn(){ printf 'WARN: %s\n' "$*" >&2; }
fail(){ printf '\n=== POSTFLIGHT FAILED ===\n%s\n' "$*" >&2; exit 3; }

APP_DIR_DEFAULT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${SERA_APP_DIR:-$APP_DIR_DEFAULT}"

cd "$APP_DIR"

# Wait for services
timeout_s="${SERA_POSTFLIGHT_TIMEOUT:-60}"
end=$((SECONDS + timeout_s))

have_curl=0
command -v curl >/dev/null 2>&1 && have_curl=1

check_url(){
  local url="$1"
  if [[ "$have_curl" -eq 1 ]]; then
    curl -fsS --max-time 2 "$url" >/dev/null 2>&1
  else
    python3 - <<PY >/dev/null 2>&1
import urllib.request
urllib.request.urlopen("${url}", timeout=2).read()
PY
  fi
}

log "Postflight: waiting for containers..."
while [[ $SECONDS -lt $end ]]; do
  if docker compose ps --status running >/dev/null 2>&1; then
    # ensure at least tool-gateway is running
    if docker compose ps 2>/dev/null | grep -q "tool-gateway" ; then
      break
    fi
  fi
  sleep 2
done

docker compose ps || true

log "Postflight: checking /health endpoints..."
# tool-gateway required
if ! check_url "http://127.0.0.1:3100/health"; then
  warn "tool-gateway /health not responding"
  docker logs --tail=200 tool-gateway 2>/dev/null || true
  fail "tool-gateway failed health check"
fi

# agent-runner optional but expected
if ! check_url "http://127.0.0.1:3200/health"; then
  warn "agent-runner /health not responding"
  docker logs --tail=200 agent-runner 2>/dev/null || true
  fail "agent-runner failed health check"
fi

# voice-gateway expected on 3000
if ! check_url "http://127.0.0.1:3000/health"; then
  warn "voice-gateway /health not responding"
  docker logs --tail=200 voice-gateway 2>/dev/null || true
  fail "voice-gateway failed health check"
fi

log "POSTFLIGHT OK"
