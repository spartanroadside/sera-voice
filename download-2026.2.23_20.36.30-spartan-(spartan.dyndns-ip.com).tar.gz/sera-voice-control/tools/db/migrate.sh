#!/usr/bin/env bash
set -euo pipefail

# Run DB migrations using the agent container python environment.
# This script is safe to run multiple times.

python -m agent.db.migrate
