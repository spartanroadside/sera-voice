from __future__ import annotations

import os, json, time, tarfile, hashlib
from pathlib import Path
from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel

router = APIRouter(prefix="/imports", tags=["imports"])

MAX_FILES = int(os.environ.get("SERA_IMPORT_MAX_FILES", "50000"))
MAX_BYTES = int(os.environ.get("SERA_IMPORT_MAX_BYTES", str(2 * 1024 * 1024 * 1024)))  # 2GB

# Injected by tools/server.py at runtime
AUTH_FUNC = None          # set to _auth
AREA_DIR_FUNC = None      # set to _area_dir (project, area)->Path
PROJECT_ROOT_FUNC = None  # set to _project_root (project)->Path


def _require(x_tool_token: str | None):
    if AUTH_FUNC is None:
        raise HTTPException(500, "imports router not wired: AUTH_FUNC missing")
    return AUTH_FUNC(x_tool_token)


def _area(project: str, area: str) -> Path:
    if AREA_DIR_FUNC is None:
        raise HTTPException(500, "imports router not wired: AREA_DIR_FUNC missing")
    return AREA_DIR_FUNC(project, area)


def _proj_root(project: str) -> Path:
    if PROJECT_ROOT_FUNC is None:
        raise HTTPException(500, "imports router not wired: PROJECT_ROOT_FUNC missing")
    return PROJECT_ROOT_FUNC(project)


def _safe_rel(name: str) -> str:
    n = name.lstrip("./")
    p = Path(n)
    if p.is_absolute():
        raise HTTPException(400, f"Absolute path not allowed: {name}")
    if ".." in p.parts:
        raise HTTPException(400, f"Traversal not allowed: {name}")
    return str(p)


def _safe_join(root: Path, rel: str) -> Path:
    out = (root / rel).resolve()
    if not str(out).startswith(str(root.resolve())):
        raise HTTPException(400, f"Escapes root: {rel}")
    return out


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class StageReq(BaseModel):
    project: str
    artifact_path: str  # "uploads/<file.tar.gz>"


@router.post("/stage")
def stage(req: StageReq, x_tool_token: str | None = Header(default=None, alias="X-Tool-Token")):
    _require(x_tool_token)

    # Only allow artifacts from uploads/
    if not req.artifact_path.startswith("uploads/"):
        raise HTTPException(400, "artifact_path must start with 'uploads/'")

    pr = _proj_root(req.project)
    uploads = _area(req.project, "uploads")
    quarantine = _area(req.project, "quarantine")
    imports_dir = (pr / "imports")
    for d in (imports_dir, pr / "repo", pr / "reports", pr / "manifests"):
        d.mkdir(parents=True, exist_ok=True)

    src = _safe_join(uploads, req.artifact_path.replace("uploads/", "", 1))
    if not src.exists():
        raise HTTPException(404, f"Artifact not found: {req.artifact_path}")

    import_id = f"imp_{int(time.time())}"
    idir = (imports_dir / import_id)
    idir.mkdir(parents=True, exist_ok=True)

    dst = (quarantine / src.name)
    with src.open("rb") as rf, dst.open("wb") as wf:
        for chunk in iter(lambda: rf.read(1024 * 1024), b""):
            wf.write(chunk)

    meta = {
        "project": req.project,
        "import_id": import_id,
        "artifact_path": req.artifact_path,
        "staged_file": str(dst),
        "sha256": _sha256(dst),
        "staged_at": int(time.time()),
        "status": "staged",
    }
    (idir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return {"ok": True, "import_id": import_id, "staged_path": f"quarantine/{dst.name}", "sha256": meta["sha256"]}


class InspectReq(BaseModel):
    project: str
    import_id: str


@router.post("/inspect")
def inspect(req: InspectReq, x_tool_token: str | None = Header(default=None, alias="X-Tool-Token")):
    _require(x_tool_token)

    pr = _proj_root(req.project)
    meta_path = pr / "imports" / req.import_id / "meta.json"
    if not meta_path.exists():
        raise HTTPException(404, "Unknown import_id")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    tar_path = Path(meta["staged_file"])
    if not tar_path.exists():
        raise HTTPException(404, "Staged artifact missing")

    total_files = 0
    total_bytes = 0
    preview = []

    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf.getmembers():
            # Block special files + links
            if m.isdev() or m.ischr() or m.isblk() or m.isfifo():
                raise HTTPException(400, f"Blocked special file: {m.name}")
            if m.issym() or m.islnk():
                raise HTTPException(400, f"Blocked link in tar (MVP): {m.name}")

            name = _safe_rel(m.name)
            if m.isfile():
                total_files += 1
                total_bytes += int(m.size or 0)

            if total_files > MAX_FILES:
                raise HTTPException(400, f"Too many files: {total_files} > {MAX_FILES}")
            if total_bytes > MAX_BYTES:
                raise HTTPException(400, f"Too large: {total_bytes} > {MAX_BYTES}")

            if len(preview) < 200:
                preview.append({"name": name, "type": "file" if m.isfile() else "dir", "size": int(m.size or 0)})

    return {"ok": True, "project": req.project, "import_id": req.import_id, "files": total_files, "bytes": total_bytes, "preview": preview}


class ApplyReq(BaseModel):
    project: str
    import_id: str


@router.post("/apply")
def apply(req: ApplyReq, x_tool_token: str | None = Header(default=None, alias="X-Tool-Token")):
    _require(x_tool_token)

    pr = _proj_root(req.project)
    meta_path = pr / "imports" / req.import_id / "meta.json"
    if not meta_path.exists():
        raise HTTPException(404, "Unknown import_id")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    tar_path = Path(meta["staged_file"])
    if not tar_path.exists():
        raise HTTPException(404, "Staged artifact missing")

    repo = (pr / "repo")
    repo.mkdir(parents=True, exist_ok=True)

    extracted_files = 0
    extracted_bytes = 0
    manifest = []

    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf.getmembers():
            if m.isdev() or m.ischr() or m.isblk() or m.isfifo() or m.issym() or m.islnk():
                raise HTTPException(400, f"Blocked tar member: {m.name}")

            rel = _safe_rel(m.name)
            dest = _safe_join(repo, rel)

            if m.isdir():
                dest.mkdir(parents=True, exist_ok=True)
                continue

            if m.isfile():
                dest.parent.mkdir(parents=True, exist_ok=True)
                f = tf.extractfile(m)
                if f is None:
                    continue
                data = f.read()
                dest.write_bytes(data)

                extracted_files += 1
                extracted_bytes += len(data)

                if extracted_files > MAX_FILES or extracted_bytes > MAX_BYTES:
                    raise HTTPException(400, "Import exceeded configured limits")

                manifest.append({"path": str(dest.relative_to(repo)), "size": len(data)})

    ts = int(time.time())
    (pr / "manifests").mkdir(exist_ok=True)
    (pr / "manifests" / f"import_{req.import_id}_{ts}.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    audit = {"ts": ts, "action": "import.apply", "project": req.project, "import_id": req.import_id, "files": extracted_files, "bytes": extracted_bytes}
    with (pr / "audit.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(audit) + "\n")

    meta["status"] = "applied"
    meta["applied_at"] = ts
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    return {"ok": True, "project": req.project, "import_id": req.import_id, "files": extracted_files, "bytes": extracted_bytes}