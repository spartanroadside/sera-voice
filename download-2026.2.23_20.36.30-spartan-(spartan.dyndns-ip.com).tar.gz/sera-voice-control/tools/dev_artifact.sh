#!/usr/bin/env bash
set -euo pipefail

ROOT="${SERA_ROOT:-/home/spartan/sera}"
OUT_DIR="${SERA_ARTIFACT_DIR:-$ROOT/dev/artifacts}"
TS="$(date +%Y%m%d_%H%M%S)"
OUT="$OUT_DIR/sera_dev_artifact_${TS}.tar.gz"

mkdir -p "$OUT_DIR"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP" >/dev/null 2>&1 || true' EXIT

for p in "$ROOT/logs" "$ROOT/debug" "$ROOT/snapshots" "$ROOT/outgoing/snapshots"; do
  if [[ -d "$p" ]]; then
    mkdir -p "$TMP/$(basename "$p")"
    cp -a "$p/." "$TMP/$(basename "$p")/" 2>/dev/null || true
  fi
done

tar -czf "$OUT" -C "$TMP" .
echo "$OUT"
