#!/usr/bin/env bash
set -euo pipefail

# Create symlinks so install.sh works from either location:
# - /home/spartan/sera/sera-ai/tools/install.sh (canonical)
# - /home/spartan/sera/sera-ai/incoming/install.sh (convenience wrapper)
# Adjust BASE if your layout differs.

BASE="${SERA_BASE_DIR:-/home/spartan/sera}"
TOOLS="$BASE/tools"
INCOMING="$BASE/incoming"

mkdir -p "$TOOLS" "$INCOMING"

CANON="$TOOLS/install.sh"
ALT="$INCOMING/install.sh"

if [ ! -f "$CANON" ] && [ -f "$ALT" ]; then
  echo "[link_installers] Promoting incoming/install.sh to canonical tools/install.sh"
  cp -av "$ALT" "$CANON"
fi

if [ -f "$CANON" ]; then
  echo "[link_installers] Linking $ALT -> $CANON"
  ln -sfn "$CANON" "$ALT"
else
  echo "[link_installers] WARN: $CANON not found; cannot link."
fi

echo "[link_installers] Done."
