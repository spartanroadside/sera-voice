#!/usr/bin/env bash
set -euo pipefail

# SERA smoke tests
# - Designed to be run on the host from the project root (or anywhere)
# - Minimal dependencies: bash + curl

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

pass(){ echo "[PASS] $*"; }
warn(){ echo "[WARN] $*"; }
fail(){ echo "[FAIL] $*"; exit 1; }

check(){
  local name="$1"; shift
  if "$@"; then pass "$name"; else fail "$name"; fi
}

echo "== SERA Smoke Tests =="

# 0) Ownership sanity (warn only; ignore permission errors)
if find . -xdev -uid 0 -print -quit 2>/dev/null | grep -q .; then
  warn "Found files owned by root inside project tree. Fix: sudo chown -R spartan:spartan $ROOT_DIR"
fi

GW_URL="${GW_URL:-http://127.0.0.1:3000}"

echo "Using GW_URL=$GW_URL"

# 1) Basic HTTP endpoints
check "Gateway health" bash -lc "curl -fsS '$GW_URL/health' >/dev/null"
check "Gateway networking selftest" bash -lc "curl -fsS '$GW_URL/api/net/selftest' | grep -q '\"ok\":true'"
check "Voice status endpoint" bash -lc "curl -fsS '$GW_URL/api/voice/status' | grep -q '\"ok\":true'"
echo "-- Updates list --"
r=$(curl -sS -w "\n%{http_code}" "$GW_URL/api/updates/list" || true)
body=$(echo "$r" | sed '$d')
code=$(echo "$r" | tail -n1)
if [[ "$code" != "200" || ! "$body" =~ \"ok\":true ]]; then
  echo "Updates list returned HTTP $code: $body"
  fail "Updates list endpoint"
else
  pass "Updates list endpoint"
fi

# 2) LLM test (optional)
OPENAI_API_KEY="${OPENAI_API_KEY:-}"
AGENT_MODEL="${AGENT_MODEL:-}"
if [[ -z "$OPENAI_API_KEY" || -z "$AGENT_MODEL" ]]; then
  echo "SKIP: LLM test (missing OPENAI_API_KEY or AGENT_MODEL)"
else
  echo "-- LLM test --"
  r=$(curl -sS -w "\n%{http_code}" -X POST "$GW_URL/api/llm/test" \
        -H 'Content-Type: application/json' \
        -d '{"text":"SERA operational test"}' || true)
  body=$(echo "$r" | sed '$d')
  code=$(echo "$r" | tail -n1)

  if ! [[ "$code" =~ ^[0-9]{3}$ ]]; then
    fail "LLM test (gateway unreachable)"
  fi

  if [[ "$code" == "200" ]]; then
    pass "LLM test"
  else
    echo "LLM returned HTTP $code: $body"
    # Any structured JSON response proves the wiring works.
    if echo "$body" | grep -qE '"error"|"ok"'; then
      pass "LLM reachable (quota/model/billing may still be needed)"
    else
      fail "LLM response not JSON"
    fi
  fi
fi

echo "All smoke tests completed."
