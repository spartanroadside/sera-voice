#!/usr/bin/env bash
set -euo pipefail

# Export Caddy 'tls internal' CA material in a way that is robust across
# container storage layouts.
#
# Strategy:
#   1) Export the TRUE ROOT CA from inside the running Caddy container
#      (this is what Windows wants in Trusted Root).
#   2) Pull the live certificate chain from the HTTPS endpoint (8443)
#      using openssl s_client to export the intermediate reliably.
#   3) Write:
#        ui/caddy-root.crt        (PEM root)
#        ui/caddy-root.cer        (DER root for Windows)
#        ui/caddy-root.pem        (PEM root, explicit)
#        ui/caddy-intermediate.crt
#        ui/caddy-ca-bundle.crt   (root + intermediate)
#
# Notes:
# - Browsers typically need the ROOT installed in the trust store.
# - Serving the bundle helps admins if only the intermediate is available.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT_DIR="$ROOT_DIR/ui"
ROOT_OUT="$OUT_DIR/caddy-root.crt"
ROOT_PEM_OUT="$OUT_DIR/caddy-root.pem"
ROOT_DER_OUT="$OUT_DIR/caddy-root.cer"
INT_OUT="$OUT_DIR/caddy-intermediate.crt"
INT_PEM_OUT="$OUT_DIR/caddy-intermediate.pem"
INT_DER_OUT="$OUT_DIR/caddy-intermediate.cer"
BUNDLE_OUT="$OUT_DIR/caddy-ca-bundle.crt"

SERVER_HOST="${SERA_TLS_SNI:-sera.lan}"
SERVER_ADDR="${SERA_TLS_ADDR:-127.0.0.1:8443}"

# Caddy root CA path inside the caddy container (caddy:2-alpine default volume)
CADDY_CONTAINER="${SERA_CADDY_CONTAINER:-voice-ui}"
CADDY_ROOT_PATH="${SERA_CADDY_ROOT_PATH:-/data/caddy/pki/authorities/local/root.crt}"

mkdir -p "$OUT_DIR"

TMPDIR="$(mktemp -d /tmp/sera-caddy-ca.XXXXXX)"
cleanup(){ rm -rf "$TMPDIR"; }
trap cleanup EXIT

write_atomic() {
  local src="$1" dst="$2" mode="$3"
  local tmp="$TMPDIR/.out.$(basename "$dst").$$"
  cp -f "$src" "$tmp"
  chmod "$mode" "$tmp"
  mv -f "$tmp" "$dst"
}

root_export() {
  local tmp_root="$TMPDIR/root_from_container.crt"

  # Copy root out of container
  if ! docker cp "${CADDY_CONTAINER}:${CADDY_ROOT_PATH}" "$tmp_root" >/dev/null 2>&1; then
    echo "ERROR: Could not docker cp root CA from container '$CADDY_CONTAINER' at '$CADDY_ROOT_PATH'." >&2
    echo "Tip: docker exec -it $CADDY_CONTAINER ls -lah $(dirname "$CADDY_ROOT_PATH")" >&2
    exit 1
  fi

  local bytes
  bytes="$(wc -c < "$tmp_root" 2>/dev/null || echo 0)"
  if [[ "$bytes" -lt 200 ]]; then
    echo "ERROR: Export failed; copied root.crt is too small (${bytes} bytes)." >&2
    echo "Container: $CADDY_CONTAINER" >&2
    echo "Path:      $CADDY_ROOT_PATH" >&2
    exit 1
  fi

  # Ensure PEM (some envs store DER). Use OpenSSL 3 provider default to avoid provider issues.
  if openssl x509 -provider default -inform PEM -in "$tmp_root" -noout >/dev/null 2>&1; then
    write_atomic "$tmp_root" "$ROOT_PEM_OUT" 0644
  else
    openssl x509 -provider default -inform DER -in "$tmp_root" -out "$TMPDIR/root.pem"
    write_atomic "$TMPDIR/root.pem" "$ROOT_PEM_OUT" 0644
  fi

  # Root CRT served should be PEM
  write_atomic "$ROOT_PEM_OUT" "$ROOT_OUT" 0644

  # Windows-friendly DER
  openssl x509 -provider default -in "$ROOT_PEM_OUT" -outform DER -out "$TMPDIR/root.cer"
  write_atomic "$TMPDIR/root.cer" "$ROOT_DER_OUT" 0644

  # Sanity
  if ! grep -q "BEGIN CERTIFICATE" "$ROOT_OUT"; then
    echo "ERROR: Root export did not produce a PEM certificate." >&2
    exit 1
  fi
}

root_export

# Pull chain (for intermediate)
CHAIN_RAW="$TMPDIR/chain.txt"
echo | openssl s_client -connect "$SERVER_ADDR" -servername "$SERVER_HOST" -showcerts 2>/dev/null > "$CHAIN_RAW" || true

if ! grep -q "BEGIN CERTIFICATE" "$CHAIN_RAW"; then
  echo "ERROR: Could not retrieve certificate chain from $SERVER_ADDR (SNI $SERVER_HOST)." >&2
  echo "Tip: curl -kI https://$SERVER_HOST:8443/ (should return 200 with -k)." >&2
  exit 1
fi

# Split certs into pem files
awk -v out="$TMPDIR" '
  /BEGIN CERTIFICATE/ {n+=1; fn=sprintf("%s/cert_%02d.pem", out, n)}
  { if (fn) print > fn }
' "$CHAIN_RAW"

mapfile -t CERTS < <(ls -1 "$TMPDIR"/cert_*.pem 2>/dev/null || true)
if [[ ${#CERTS[@]} -eq 0 ]]; then
  echo "ERROR: No cert PEMs extracted from chain." >&2
  exit 1
fi

# Identify intermediate (non-self-signed). Root comes from container.
INT_CAND=""
for f in "${CERTS[@]}"; do
  subj="$(openssl x509 -noout -subject -in "$f" 2>/dev/null | sed 's/^subject=//')"
  issr="$(openssl x509 -noout -issuer  -in "$f" 2>/dev/null | sed 's/^issuer=//')"
  # keep the last non-self-signed as intermediate candidate
  if [[ -n "$subj" && "$subj" != "$issr" ]]; then
    INT_CAND="$f"
  fi
done

BYTES_INT=0
BYTES_ROOT="$(wc -c < "$ROOT_OUT" 2>/dev/null || echo 0)"

if [[ -n "$INT_CAND" ]]; then
  BYTES_INT="$(wc -c < "$INT_CAND")"
  if [[ "$BYTES_INT" -lt 500 ]]; then
    echo "ERROR: Intermediate cert too small ($BYTES_INT bytes): $INT_CAND" >&2
    exit 1
  fi
  write_atomic "$INT_CAND" "$INT_OUT" 0644
	# Convenience formats for clients
	write_atomic "$INT_CAND" "$INT_PEM_OUT" 0644
	openssl x509 -in "$INT_CAND" -outform DER -out "$INT_DER_OUT" >/dev/null 2>&1 || true
fi

# Build bundle (root then intermediate when available)
: > "$BUNDLE_OUT"
chmod 0644 "$BUNDLE_OUT"
cat "$ROOT_OUT" >> "$BUNDLE_OUT"; echo >> "$BUNDLE_OUT"
if [[ -n "$INT_CAND" ]]; then cat "$INT_OUT" >> "$BUNDLE_OUT"; echo >> "$BUNDLE_OUT"; fi

BUNDLE_BYTES="$(wc -c < "$BUNDLE_OUT")"
if [[ "$BUNDLE_BYTES" -lt 500 ]]; then
  echo "ERROR: CA bundle unexpectedly small ($BUNDLE_BYTES bytes)." >&2
  exit 1
fi

echo "OK: exported CA material to ui/"
echo " - caddy-root.crt ($BYTES_ROOT bytes)"
echo " - caddy-root.cer ($(wc -c < "$ROOT_DER_OUT" 2>/dev/null || echo 0) bytes)"
echo " - caddy-root.pem ($(wc -c < "$ROOT_PEM_OUT" 2>/dev/null || echo 0) bytes)"
echo " - caddy-intermediate.crt ($BYTES_INT bytes)"
echo " - caddy-intermediate.pem ($(wc -c < "$INT_PEM_OUT" 2>/dev/null || echo 0) bytes)"
echo " - caddy-intermediate.cer ($(wc -c < "$INT_DER_OUT" 2>/dev/null || echo 0) bytes)"
echo " - caddy-ca-bundle.crt ($BUNDLE_BYTES bytes)"
echo
echo "HTTP:  http://127.0.0.1:8080/caddy-root.crt"
echo "HTTP:  http://127.0.0.1:8080/caddy-root.cer"
echo "HTTP:  http://127.0.0.1:8080/caddy-root.pem"
echo "HTTP:  http://127.0.0.1:8080/caddy-intermediate.crt"
echo "HTTP:  http://127.0.0.1:8080/caddy-intermediate.cer"
echo "HTTP:  http://127.0.0.1:8080/caddy-intermediate.pem"
echo "HTTP:  http://127.0.0.1:8080/caddy-ca-bundle.crt"
echo "HTTPS: https://${SERVER_HOST}:8443/caddy-root.crt"
echo "HTTPS: https://${SERVER_HOST}:8443/caddy-root.cer"
echo "HTTPS: https://${SERVER_HOST}:8443/caddy-root.pem"
echo "HTTPS: https://${SERVER_HOST}:8443/caddy-intermediate.crt"
echo "HTTPS: https://${SERVER_HOST}:8443/caddy-intermediate.cer"
echo "HTTPS: https://${SERVER_HOST}:8443/caddy-intermediate.pem"
echo "HTTPS: https://${SERVER_HOST}:8443/caddy-ca-bundle.crt"
