#!/usr/bin/env bash
set -euo pipefail
# DEPRECATED: use ./scripts/force_rebuild_tool_gateway.sh
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/../scripts/force_rebuild_tool_gateway.sh" "$@"
