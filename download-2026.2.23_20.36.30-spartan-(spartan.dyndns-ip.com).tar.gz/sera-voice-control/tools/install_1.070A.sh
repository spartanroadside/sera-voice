#!/usr/bin/env bash
set -euo pipefail
# DEPRECATED: use ./scripts/install_1.070A.sh
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/../scripts/install_1.070A.sh" "$@"
